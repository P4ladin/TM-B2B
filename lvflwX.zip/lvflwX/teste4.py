from os import abort, replace
import sys
import time
from py3270 import Emulator
from modulos.conexao import *

class cnt(Emulator):
    def __init__(sf, visible=False, host='10.31.9.100'):
        Emulator.__init__(sf, visible)
        sf.connect(host)
        sf.wait_for_field()
        
def gtf(ct, vU='F83241', vP='cru010mg', vC='CA'):
    ct.wait_for_field()
    ct.fill_field(3, 15, 'chr', 3)
    ete(ct)
    ct.fill_field(25, 23, vU, 6)
    ct.fill_field(26, 23, vP, 8)
    ete(ct)
    if ct.string_get(13, 22, 6) != vU:
        a = input('entender o que aonteceu pra chegar aqui')
    else:
        while not ct.string_get(2, 73, 8) == 'MAN0PFT1':
            ete(ct)
        ct.fill_field(18, 29, '113', 3)
        ete(ct)
        while not ct.string_get(4, 72, 8) == 'CG00000A':
            ete(ct)
        ct.fill_field(24, 6, vC, 3)
        ete(ct)

def teste(ct):
    wq = 0
    while ct.string_found(8, 14, 'Atencao !!!  Este  circuito  esta') or ct.string_found(8, 14, 'Atencao !!!  Este  circuito  foi'):
        wq += 1
        et(ct)
        time.sleep(10)
        if wq > 1:
            et(ct)
            pf(ct, 3)
            cnx.sqlcmd(cnx(), 'insert ignore into tmi_circp(cir) values("' + cir + '")')
            return True
        else:
            if ct.string_found(8, 14, 'Atencao !!!  Este  circuito  esta') or ct.string_found(8, 14, 'Atencao !!!  Este  circuito  foi'):
                et(ct)
                pf(ct, 3)
            ff(ct, l, 3, 'k', 3, 70, 'CGCBB00B')
            if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                et(ct)
    if ct.string_found(4, 73, 'CGSCT05A') or ct.string_found(3, 71, 'CGCBB00B'):
        cnx.sqlcmd(cnx(), 'insert ignore into tmi_circp(cir) values("' + cir + '")')
        if ct.string_found(4, 73, 'CGSCT05A'):
            pf(ct, 3)
        elif ct.string_found(3, 71, 'CGCBB00B') and ct.string_found(l, 3, 'k'):
            ff(ct, l, 3, '', 3, 71, 'CGCBB00B')
        return True
    return False

def ete(ct):
    ct.wait_for_field()
    ct.send_enter()
    ct.wait_for_field()

def et(ct):
    ct.wait_for_field()
    ct.send_enter()
    ct.wait_for_field()
    vercp(ct)
    ct.wait_for_field()

def vercp(ct):
    ct.wait_for_field()
    if ct.string_found(15, 47,'CANCELAMENTO DE PROGRAMA'):
        print('verificar o que ocasionou o cancelamento de programa')

def ff(ct, a, b, c, d, e, f):
    if not ct.string_get(d, e, 11).strip() == f:
        print('verificar o que ocasionou não estar nesta tela')
    ct.fill_field(a, b, c, len(c))
    et(ct)

def pf(ct, p):
    ct.wait_for_field()
    ct.send_pf(p)
    ct.wait_for_field()
    vercp(ct)
    ct.wait_for_field()

def buscacbb_pd(ct, pd, pl, bl, pde):
    try:
        gtf(ct, vC='cbb')
        global em, vF, vR
        for i in pd:
            if i not in pde:
                if not ct.string_found(4, 72, 'CGCBB00A'):
                    print('por qual motivo não está na tela cbb')
                ct.fill_field(14, 15, 'MG', 2)
                ct.fill_field(14, 39, i, 4)
                ct.fill_field(14, 46, i, 4)
                pda = i
                et(ct)
                if ct.string_found(3, 71, 'CGCBB00B'):
                    l = 7
                    p = 1
                    while not ct.string_found(l, 5, ' '):
                        loc = ct.string_get(l, 7, 4).strip()
                        nr =  ct.string_get(l, 20, 7)
                        cir = loc + '-' + nr
                        ff(ct, l, 3, 'c', 3, 70, 'CGCBB00B')
                        if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                            et(ct)
                        teste(ct)
                        ptc = ct.string_get(4, 18, 22)
                        ptc = ptc[ptc.find('.') + 2:ptc.find('/') - 1]
            l += 2
            if l == 21:
                l = 7
                pf(ct, 8)
                if ct.string_get(1, 1, 15).strip() == 'ULTIMA PAGINA':
                    break
                else:
                    p += 1
            pf(ct, 3)
            print(i)
            pde.append(i)
        vF = False
    except (Exception, IOError) as e:
        try:
            print(str(cir) + '/' + str(pda) + '/' + str(l) + '/' + str(p) + '/' + str(lid) + '/' + str(pd))
        except:
            pass
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        try:
            if ct.is_connected():
                ct.terminate()
        except:
            pass
        em = cnt(visible=True)
        vR, vF = True, True
"""
                        if ct.string_get(4, 72, 8) != 'CGSCT13A':
                            et(ct)
                            if ct.string_get(4, 71, 8) == 'CGSDTS6A':
                                pf(ct, 4)
                        ct.wait_for_field()        
def buscacbb_cc(ct, cc, cct, v):
    ln = 13
                            pg = 1
                            ct.fill_field(l, 3, 't', 1)
                            while ct.string_get(ln, 5, 1) != ' ':
                                ct.fill_field(ln, 3, 'x', 1)
                                pst = ct.string_get(ln, 13, 5).strip()
                                pta = ct.string_get(ln, 51, 1).replace(' ', 'A')
                                et(ct)
                                if ct.string_found(4, 72, 'CGSCT80B'):
                                    tp = ct.string_get(19, 22, 5).strip()
                                    pnd = ct.string_get(17, 22, 4).replace('    ', '0')
                                    ent = ct.string_get(9, 59, 10) + ' ' + ct.string_get(9, 71, 5)
                                    sai = (ct.string_get(10, 59, 10) + ' ' + ct.string_get(10, 71, 5)).strip()
                                elif ct.string_found(4, 72, 'CGSCT96A'):
                                    tp = ct.string_get(19, 28, 5).strip()
                                    pnd = ct.string_get(17, 28, 4).replace('    ', '0')
                                    ent = ct.string_get(10, 28, 14).replace(' ', '') + ' ' + ct.string_get(10, 44, 7).replace(' ', '')
                                    sai = (ct.string_get(12, 28, 14).replace(' ', '') + ' ' + ct.string_get(12, 44, 7).replace(' ', '')).strip()
                                else:
                                    a = input('descobrir pq parou aqui - ' + (str(cir) + '/' + str(pda) + '/' + str(l) + '/' + str(p) + '/' + str(ln) + '/' + str(pg) + '/' + str(lid) + '/' + str(lidt) + '/' + str(pd)))
                                dif = '1' if srv[:3] == 'INS' and pnd in tm else '0'
                                if tp != 'PLJ':
                                    lidt = cnx.sqlcmdid(cnx(), 'insert into tmi_tramit(`or`, pd, pst, pt, ent, sai, dif, tp) values(' + str(lid) + ', "' + pnd + '", "' + pst + '", "' + pta + '", str_to_date("' + ent + '","%d/%m/%Y %H:%i"), str_to_date("' + sai + '","%d/%m/%Y %H:%i"), "' + dif + '", "' + tp + '")')
                                while not ct.string_found(4, 72, 'CGSCT13A'):
                                    pf(ct, 3)
                                ct.fill_field(ln, 3, '', 1)
                                ln += 1
                                if ln == 21:
                                    ln = 13
                                    pf(ct, 8)
                                    if ct.string_get(1, 1, 15).strip() == 'ULTIMA TELA':
                                        break
                                    else:
                                        pg += 1
                            cnx.sqlcmd(cnx(), 'update tmi set at = now(), pg = ' + str(pg) + ', ln = ' + str(ln) + ', `uid` = ' + str(lidt) + ' where id = ' + str(lid))
    try:
        global vF2, vR2
        for i in list(cc.keys()):
            if i not in cct:
                while ct.string_get(4, 72, 8) != 'CGCBB00A':
                    pf(ct, 3)
                ct.fill_field(6, 21, 'bhe', 3)
                ct.fill_field(6, 26, 'tne', 3)
                a = i[:i.find(' ')]
                ct.fill_field(16, 65, a, len(a))
                b = i[i.find(' ') + 1:]
                ct.fill_field(16, 70, b, 7)
                pda = i
                et(ct)
                if ct.string_get(3, 71, 8) == 'CGCBB00B':
                    if not v:
                        l = 7
                        p = 1
                    else:
                        q = 1
                        while q < p:
                            pf(ct, 8)
                            q += 1
                    while ct.string_get(l, 5, 1) != ' ':
                        cir = ct.string_get(l, 7, 4).strip() + ' ' + ct.string_get(l, 20, 7)
                        srv = ct.string_get(l, 29, 7)
                        ct.fill_field(l, 3, 't', 1)
                        et(ct)
                        if ct.string_get(4, 72, 8) != 'CGSCT13A':
                            et(ct)
                            if ct.string_get(4, 71, 8) == 'CGSDTS6A':
                                pf(ct, 4)
                        ct.wait_for_field()
                        ptc = ct.string_get(4, 18, 22)
                        ptc = ptc[ptc.find('.') + 2:ptc.find('/') - 1]
                        if str(cir + ptc + srv) not in bl:
                            bl.append(str(cir + ptc + srv))
                            lid = cnx.sqlcmdid(cnx(), 'insert into tmi(cir, ptc, srv, `in`) values("' + cir + '", "' + ptc + '", "' + srv + '", now())')
                            ln = 13
                            pg = 1
                            while ct.string_get(ln, 5, 1) != ' ':
                                ct.fill_field(ln, 3, 'x', 1)
                                pst = ct.string_get(ln, 13, 5).strip()
                                pta = ct.string_get(ln, 51, 1).replace(' ', 'A')
                                et(ct)
                                if ct.string_get(4, 72, 8) == 'CGSCT80B':
                                    tp = ct.string_get(19, 22, 5).strip()
                                    pnd = ct.string_get(17, 22, 4).replace('    ', '0')
                                    ent = ct.string_get(9, 59, 10) + ' ' + ct.string_get(9, 71, 5)
                                    sai = ct.string_get(10, 59, 10) + ' ' + ct.string_get(10, 71, 5)
                                    dif = '1' if srv[:3] == 'INS' and pnd in pd else '0'
                                    if tp != 'PLJ':
                                        lidt = cnx.sqlcmdid(cnx(), 'insert into tmi_tramit(`or`, pd, pst, pt, ent, sai, dif, tp) values(' + str(lid) + ', "' + pnd + '", "' + pst + '", "' + pta + '", str_to_date("' + ent + '","%d/%m/%Y %H:%i"), str_to_date("' + sai + '","%d/%m/%Y %H:%i"), "' + dif + '", "' + tp + '")')
                                    pf(ct, 3)
                                    ct.fill_field(ln, 3, '', 1)
                                    ln += 1
                                    if ln == 21:
                                        ln = 13
                                        pf(ct, 8)
                                        if ct.string_get(1, 1, 15).strip() == 'ULTIMA TELA':
                                            break
                                        else:
                                            pg += 1
                            cnx.sqlcmd(cnx(), 'update tmi set at = now(), pg = ' + str(pg) + ', ln = ' + str(ln) + ', `uid` = ' + str(lidt) + ' where id = ' + str(lid))
                        l += 2
                        pf(ct, 3)
                        if l == 21:
                            l = 7
                            pf(ct, 8)
                            if ct.string_get(1, 1, 15).strip() == 'ULTIMA PAGINA':
                                break
                            else:
                                p +=1
                print(i)
                pde.append(i)
        vF = False
    except Exception as e:
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        print(str(cir) + '/' + str(pda) + '/' + str(l) + '/' + str(p) + '/' + str(ln) + '/' + str(pg) + '/' + str(lid) + '/' + str(lidt) + '/' + str(pd))
        vR, vF = True, True
        global em
        em = cnt(vC='CBB')
"""
global pde, cct, tm
em = cnt(visible=True)
pd = cnx.sqllist1(cnx(), 'select pd from tmi_pend where nv = 1 order by 1')
#tm = cnx.sqllist1(cnx(), 'select pd from tmi_pend where s is not null')
pl = cnx.sqllist1(cnx(), 'select idx from planta')
bl = cnx.sqllist1(cnx(), 'select ptc from tmi where enc = 0')
pde = []
cct = []
vF, vF2 = True, True

while 1:
    while vF:
        buscacbb_pd(em, pd, pl, bl, pde)
    #while vF2:
        #cc = cnx.sqldict(cnx(), 'select cir, id, pg, ln, uid from tmi where at is null', 5)
        #buscacbb_cc(em, cc, cct, vR2)
    break