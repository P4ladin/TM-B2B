from os import replace
from py3270 import Emulator
from modulos.conexao import *

def b2bp();


def __init__(sf, visible=False, timeout=3):
     Emulator()
     sf.em.connect('10.31.9.100')
     sf.em.wait_for_field()
     if not sf.em.is_connected:
        sf.em.terminate()
        print('Não foi possível conectar')
        exit()

        def cntprc(vU, vP, vC):



pd = cnx.csql(cnx(), 'select pd from tmi_pend where nv = 1')
bl = cnx.sqllist1(cnx(), 'select concat(cir, ptc, srv) from tmi')



print('fim')






em.fill_field(5, 12, 'BCA', 3)
em.fill_field(5, 17, '5052662', 7)
em.send_enter()
em.wait_for_field()

while not em.string_get(4, 72, 8) == 'CGCD001Z':
    em.send_pf(9)
    em.wait_for_field()

while not em.string_get(3, 32, 27) == 'Consulta Cadastral Circuito':
    em.send_pf4()
    em.wait_for_field()

em.fill_field(16, 16, 'X', 1)
em.send_enter()
em.wait_for_field()

print(em.string_get(11, 16, 3))

em.terminate()