for i in range(10):
    print(1)
