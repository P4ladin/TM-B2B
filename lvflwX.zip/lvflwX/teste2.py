from modulos.janelas import *
import modulos.janelas

modulos.janelas.vNm_r = 'Rodrigo'
modulos.janelas.vId = 1
modulos.janelas.vPs = 420

app = Tk()
app1 = Toplevel(app)
b2b(app1, app)

app1.mainloop()