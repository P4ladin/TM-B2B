from os import abort, replace
import sys
import time
from py3270 import Emulator
from modulos.conexao import *

class cnt(Emulator):
    def __init__(sf, visible=False, host='10.31.9.100'):
        Emulator.__init__(sf, visible)
        sf.connect(host)
        sf.wait_for_field()
        
def gtf(ct, vU='F83241', vP='cru010mg'):
    ct.wait_for_field()
    ct.fill_field(3, 15, 'chr', 3)
    ete(ct)
    ct.fill_field(25, 23, vU, 6)
    ct.fill_field(26, 23, vP, 8)
    ete(ct)
    if ct.string_get(13, 22, 6) != vU:
        a = input('entender o que aonteceu pra chegar aqui')
    else:
        while not ct.string_get(2, 73, 8) == 'MAN0PFT1':
            ete(ct)
        ct.fill_field(18, 29, '1', 3)
        ete(ct)
        while not ct.string_get(3, 70, 8) == 'VAB0M900':
            ete(ct)
        ct.fill_field(21, 27, '2', 3)
        ete(ct)
        while not ct.string_get(3, 73, 8) == 'VAB082M0':
            ete(ct)
        ct.fill_field(21, 27, '1', 3)
        ete(ct)
        while not ct.string_get(3, 69, 8) == 'VAB082M1':
            ete(ct)

def ete(ct):
    ct.wait_for_field()
    ct.send_enter()
    ct.wait_for_field()

def et(ct):
    ct.wait_for_field()
    ct.send_enter()
    ct.wait_for_field()
    vercp(ct)
    ct.wait_for_field()

def vercp(ct):
    ct.wait_for_field()
    if ct.string_found(15, 47,'CANCELAMENTO DE PROGRAMA'):
        print('verificar o que ocasionou o cancelamento de programa')

def ff(ct, a, b, c, d, e, f):
    if not ct.string_get(d, e, 11).strip() == f:
        print('verificar o que ocasionou não estar nesta tela')
    ct.fill_field(a, b, c, len(c))
    et(ct)

def pf(ct, p):
    ct.wait_for_field()
    ct.send_pf(p)
    ct.wait_for_field()
    vercp(ct)
    ct.wait_for_field()

def buscaest(em):
    gtf(em)    

em = cnt(visible=True)

time.sleep(1000)