import mysql.connector

def write_file(data, filename):
    with open(filename, 'wb') as file:
        file.write(data)

def readBLOB(nm, arq):
    print("Reading BLOB data from python_employee table")

    try:
        connection = mysql.connector.connect(host='192.168.5.31',
                                             database='sistema',
                                             user='root',
                                             password='pnxeusmb@017')

        cursor = connection.cursor()
        sql_fetch_blob_query = """SELECT arq from arquives where nm = %s"""

        cursor.execute(sql_fetch_blob_query, (nm,))
        record = cursor.fetchall()
        for row in record:
            file = row[0]
            print("Storing employee image and bio-data on disk \n")
            write_file(file, arq)

    except mysql.connector.Error as error:
        print("Failed to read BLOB data from MySQL table {}".format(error))

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

readBLOB('lvw.json', 'C:/Projects/lvflwX/divs/lvw.json')