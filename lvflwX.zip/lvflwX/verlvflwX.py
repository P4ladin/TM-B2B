#VERSÃO: 1
#DATA: 10/01/2021
import json
import os
import sys
import time
import subprocess
import tkinter as tk
import zipfile as zp
import socket
import getpass
import mysql.connector
from tkinter import *
from tkinter import messagebox
from cryptography.fernet import Fernet

def dec(txt):
    k = 'UqFSyNZKimlsXaKNK2TaS-xRZjAW5CP4fS2D0dLRKc0='
    k = k.encode()
    f = Fernet(k)
    return f.decrypt(txt.encode()).decode()

def getarq(nm, de): #nm=nome do arquivo / de=nome do destino
    while chksrv(vHost, 3306) == False:
        msgbox = messagebox.askretrycancel('Sistema', 'Servidor não encontrado, certifique se está conectado à rede Telemont!')
        if msgbox:
            pass
        else:
            messagebox.showinfo('Sistema', 'O Sistema será finalizado!', icon='info')
            quit()
    con = mysql.connector.connect(
        host=vHost,
        user=vUser,
        passwd=vPass,
        database=vData
    )
    cur = con.cursor()
    cur.execute(f'select arq from arquives where nm = "{nm}"')
    rec = cur.fetchone()
    with open(de + nm, 'wb') as arq:
        arq.write(rec[0])

def chksrv(srv, prt):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.connect((srv, prt))
        s.close()
        return True
    except:
        return False

class cnx():
    def __init__(sf):
        while chksrv(vHost, 3306) == False:
            msgbox = messagebox.askretrycancel('Sistema', 'Servidor não encontrado, certifique se está conectado à rede Telemont!')
            if msgbox:
                pass
            else:
                messagebox.showinfo('Sistema', 'O Sistema será finalizado!', icon='info')
                quit()
        sf.con = mysql.connector.connect(
            host=vHost,
            user=vUser,
            passwd=vPass,
            database=vData
        )
        sf.cur = sf.con.cursor()

    def sqlexist(sf, campo, tabela, ccond, cond):
        cons = 'select ' + campo + ' from ' + tabela + ' where ' + ccond + ' = "' + cond + '"'
        sf.cur.execute(cons)
        rs = sf.cur.fetchone()
        if rs is None:
            return 0
        else:
            return int(rs[0])

    def sqlexist2(sf, campo, tabela, ccond, cond):
        cons = 'select ' + campo + ' from ' + tabela + ' where ' + ccond + ' = "' + cond + '"'
        sf.cur.execute(cons)
        rs = sf.cur.fetchone()
        return rs

    def csql(sf, sql):
        sf.cur.execute(sql)
        res = sf.cur.fetchall()
        return res

    def sqlcmd(sf, sql):
        sf.cur.execute(sql)
        rs = sf.cur.rowcount
        sf.con.commit()
        return rs

class ver():
    def __init__(sf, master):
        cor_f = 'azure2'
        sep = ('', 6)
        font1 = ('Verdana', 14, 'bold')
        font2 = ('Verdana', 10)
        font3 = ('Verdana', 10, 'bold')
        font4 = ('Verdana', 7)
        font5 = ('Verdana', 7, 'bold')
        sf.master = master
        sf.wv = BooleanVar()
        sf.ss = StringVar()
        sf.dss = StringVar()
        sf.master['bg'] = cor_f
        l_tela = sf.master.winfo_screenwidth()
        a_tela = sf.master.winfo_screenheight()
        l_ws = 400  # sf.master.winfo_width()
        a_ws = 150  # sf.master.winfo_height()
        posx = l_tela / 2 - l_ws / 2
        posy = a_tela / 2 - a_ws / 1.85
        sf.master.resizable(width=0, height=0)
        sf.master.focus_force()
        sf.master.grab_set()
        sf.master.geometry("%dx%d+%d+%d" % (l_ws, a_ws, posx, posy))
        try:
            sf.master.iconphoto(False, tk.PhotoImage(file='C:/Sistema/lvflwX/divs/icon.png'))
        except:
            pass
        sf.master.title('CheckVer | lvflwX')
        sf.fr1 = Frame(sf.master, bg=cor_f)
        sf.lb1 = Label(sf.fr1, width=41, bg=cor_f, font=sep)
        sf.lb1.grid(row=0, column=0)
        sf.lb2 = Label(sf.fr1, width=41, wraplength=380, textvariable=sf.dss, justify=LEFT, anchor=W, bg=cor_f, font=font3)
        sf.lb2.grid(row=1, column=0, sticky=W, rowspan=2, columnspan=2)
        sf.lb3 = Label(sf.fr1, bg=cor_f, height=2)
        sf.lb3.grid(row=2, column=1, sticky='we')
        sf.lb4 = Label(sf.fr1, width=29, textvariable=sf.ss, justify=CENTER, anchor=W, bg='azure3', font=font1)
        sf.lb4.grid(row=3, column=0, sticky='we')
        sf.lb5 = Label(sf.fr1, width=41, bg=cor_f, font=sep)
        sf.lb5.grid(row=4, column=0)
        sf.lb6 = Label(sf.fr1, width=41, bg=cor_f, font=sep)
        sf.lb6.grid(row=6, column=0)
        sf.fr1.grid(row=0, column=0, ipadx=2, ipady=2, padx=10, pady=10)
        sf.upd(sf.dss, sf.lb2, 'Verificando atualizações do sistema\nAguarde...')
        global vAtlz
        if os.path.isfile('c:/Sistema/lvflwX/verlvflwX.exe') and os.path.isfile('c:/Sistema/lvflwX/lvflwX.exe') and os.path.isfile('c:/Sistema/lvflwX/divs/lvw.json') and os.path.isfile('c:/Sistema/lvflwX/divs/icon.png'):
            vAtlz = True
        else:
            vAtlz = False
        if not vAtlz:
            if not os.path.isdir('c:/Sistema/lvflwX/divs'):
                sp1 = subprocess.Popen('md c:\\Sistema\\lvflwX\\divs > null', shell=True)
                sp1.wait()
            getarq('lvw.json', 'C:/Sistema/lvflwX/divs/')
            getarq('icon.png', 'C:/Sistema/lvflwX/divs/')
            getarq('verlvflwX.exe', 'C:/Sistema/lvflwX/')
        global vVer1, vVer2
        arq = 'C:/Sistema/lvflwX/divs/lvw.json'
        if os.path.isfile(arq):
            with open(arq) as j:
                jf = json.load(j)
            vVer1 = jf['system']['ver1']
            vVer2 = jf['system']['ver2']
        sf.upd(sf.ss, sf.lb4, '█')
        test = cnx.sqlexist(cnx(), 'ss', 'sistema_usrlcl', 'lcl', vMacLocal)
        sf.upd(sf.ss, sf.lb4, '███')
        if test == 0:
            cnx.sqlcmd(cnx(), f'insert into sistema_usrlcl (lcl, usr) values ("{vMacLocal}", "{vUserLocal}")')
            sf.upd(sf.dss, sf.lb2, 'Este é o primeiro acesso deste computador, aguarde a liberação de execução!')
            sf.fechar()
        elif test == 1:
            sf.upd(sf.dss, sf.lb2, 'A liberação de execução por este computador ainda não foi avaliada!')
            sf.fechar()
        elif test == 2:
            if not cnx.sqlexist2(cnx(), 'usr', 'sistema_usrlcl', 'lcl', vMacLocal)[0] == vUserLocal:
                sf.upd(sf.dss, sf.lb2, 'Instalação não autorizada!\nUsuário ou computador sem permissão.')
                sf.fechar()
        elif test == 3:
            sf.upd(sf.dss, sf.lb2, 'Instalação não autorizada!\nUsuário ou computador bloqueado.')
            sf.fechar()
        sf.upd(sf.ss, sf.lb4, '████████')
        verSys = cnx.csql(cnx(), 'select nr from sistema_versao')[0][0]
        if vVer1 != verSys or not vAtlz:
            if vAtlz:
                msg = f'O sistema será atualizado da versão {str(vVer1)} para a versão {str(verSys)}!'
                with open('C:/Sistema/lvflwX/divs/lvw.json') as j:
                    jf = json.load(j)
                jf['system']['ver1'] = str(verSys)
                with open('C:/Sistema/lvflwX/divs/lvw.json', 'w') as j:
                    json.dump(jf, j)
                vAbr = True
            else:
                msg = f'O sistema será atualizado pela primeira vez para a versão {str(verSys)}!'
                vAbr = False
            sf.upd(sf.dss, sf.lb4, msg)
            getarq('lvflwX.zip', 'C:/Sistema/')
            sf.upd(sf.ss, sf.lb4, '██████████')
            with zp.ZipFile('c:/Sistema/lvflwX.zip') as file:
                file.extractall('c:/Sistema')
            sf.upd(sf.ss, sf.lb4, '████████████████')
            sp1 = subprocess.Popen('del c:\\Sistema\\lvflwX.zip > null', shell=True)
            sp1.wait()
            sf.upd(sf.ss, sf.lb4, '█████████████████')
            lnk = 'c:' + os.environ["HOMEPATH"] + '/Desktop/'
            if not os.path.isfile(lnk + '/lvflwX.lnk'):
                getarq('lvflwX.lnk', lnk)
        else:
            vAbr = True
        if vAtlz:
            sf.upd(sf.dss, sf.lb4, 'Sistema atualizado!\nClique em Ok para iniciar...')
            sf.upd(sf.ss, sf.lb4, '███████████████████')
        else:
            sf.upd(sf.dss, sf.lb4, 'Sistema instalado!\nPara abrir, localize lvflwX na área de trabalho.')
            sf.upd(sf.ss, sf.lb4, '███████████████████')
        if vAbr:
            sf.fechar(1)
        else:
            sf.fechar()
    
    def fechar(sf, op=0):
        if op == 1:
            os.startfile('c:/Sistema/lvflwX/lvflwX.exe')
            sys.exit()
        elif op == 0:
            sf.bt1 = Button(sf.fr1, text='Ok', font=('Verdana', 12), command=lambda a=1: sf.wv.set(a))
            sf.bt1.grid(row=5, column=0, sticky=E)
            sf.master.waitvar(sf.wv)
            sys.exit()

    def upd(sf, var, ctrl, msg):
        var.set(msg)
        ctrl.update()

global vUserLocal, vMacLocal, vVer1, vVer2, vHost, vUser, vPass, vData

vUserLocal = getpass.getuser()
vMacLocal = os.environ['COMPUTERNAME']

arq = 'C:/Sistema/lvflwX/divs/lvw.json'

if os.path.isfile(arq):
    with open(arq) as j:
        jf = json.load(j)
    vVer1 = jf['system']['ver1']
    vVer2 = jf['system']['ver2']
    vHost = dec(jf['system']['host'])
    vUser = dec(jf['system']['user'])
    vPass = dec(jf['system']['pass'])
    vData = dec(jf['system']['data'])
else:
    vHost = dec('gAAAAABh3H6SUYl_we490LBAhByEGZEE9veP4Xp5rM0lX1VrBRGdIMha4KEtyDCZavEl-SsLoMFoF_GLB2ZpfTENJbcmiaDRww==')
    vUser = dec('gAAAAABh3H6SQoB6sRQxCoXSGwO3H1kYyIV4H9jIL1Rj6Xm8gvKoiRJRQ8zDZr1EjyALw24dymrXMBAkca1_MEpGR6Q09f7Huw==')
    vPass = dec('gAAAAABh3H6SlWejGWHhkXYyICdxxCxaGl4bxTrexcFxzlRWEZx3RXvCp3iyMSkNeH-CLEgQ0jocx-eyhE_0My2A8dug6-y5k1HE3WvQy4BkSAPeRcJa82U=')
    vData = dec('gAAAAABh3H6SW0ofSp0v9Gmy9CmYjwyzrARIPnpid9V6mcXeOyzQ9pSZNz-wbafY_6APuX7CtEtfiuFb9rI0v_k5KMoHKnRoFA==')

app = Tk()
ver(app)