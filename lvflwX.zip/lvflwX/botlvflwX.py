import time
import sys
import telepot
import json
from telepot.loop import MessageLoop
from telepot.namedtuple import InlineKeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup, ForceReply, \
    ReplyKeyboardMarkup, KeyboardButton
import sqlite3
from pprint import pprint


def mensagens_recebidas(msg):
    content_type, chat_type, chat_id = telepot.glance(msg)

    if msg['from']['is_bot']:
        print("Permissao negada para: ", chat_id)
    else:
        mensagens_comando(msg, chat_id)


def mensagens_comando(msg, chat_id):
    if msg['text'] == '/cadastrar':

        if existUser(chat_id):
            markup = ForceReply()
            bot.sendMessage(chat_id, 'Informe o seu codigo de pessoa:', reply_markup=markup)
        else:
            markup = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text='Sim', callback_data='xSim'),
                 InlineKeyboardButton(text='Nao', callback_data='xNao')],
            ])
            nome = msg['chat']['first_name'] + ' ' + msg['chat']['last_name']
            bot.sendMessage(171189331, nome + ' solicita cadastro no Bot Dados/Fibra, esta pessoa esta autorizada?',
                            reply_markup=markup)

        if msg['text'] == '/recursos':
            print('Foi enviado mensagem /recursos')


def on_callback_query(msg):
    query_id, from_id, query_data = telepot.glance(msg, flavor='callback_query')

    print('Callback Query:', query_id, from_id, query_data)

    bot.answerCallbackQuery(query_id, text='Got it')


def insNovoUsr(chat_id, cdp):
    cur.execute('insert into users (chatid, cdp) values(?, ?)', (chat_id, cdp))
    con.commit()


def existUser(chat_id):
    test = cur.execute('select * from users where chatid=?', (chat_id,))
    for chat_id in test:
        return True


bot = telepot.Bot('1002220924:AAH07BdoL1s_xHkk4eVQuHE8Vl8PyK2xRoo')

con = sqlite3.connect('C:/Projects/Bot/botbd.db', check_same_thread=False)
cur = con.cursor()

MessageLoop(bot, {'chat': mensagens_recebidas, 'callback_query': on_callback_query}).run_as_thread()

while 1:
    time.sleep(10)
