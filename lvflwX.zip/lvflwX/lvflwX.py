from modulos.janelas import *

app = Tk()
login(app)
