import csv
import itertools
import unicodedata
import re
from logging import root
from string import ascii_uppercase
import string
import os
import tkinter as tk
import tkinter.ttk as ttk
from tkinter import *
from tkinter import filedialog
from modulos.janelas import *
import modulos.janelas

import win32com.client as win32

from modulos.conexao import *

cor_f = 'azure2'
sep = ('', 6)
sep1 = ('', 1)
font1 = ('Verdana', 14, 'bold')
font2 = ('Verdana', 10)
font3 = ('Verdana', 10, 'bold')
font4 = ('Verdana', 7)
font5 = ('Verdana', 7, 'bold')
font6 = ('Verdana', 8)
font7 = ('Verdana', 8, 'bold')
vpx=(2, 0)
vpy=(2, 0)

def lmpchar(txt):
    a = unicodedata.normalize('NFD', txt)
    b = a.encode('ascii', 'ignore')
    c = b.decode('utf-8')
    d = ''.join([i for i in c if i not in string.punctuation])
    return d

def par(num):
    if num % 2 == 0:
        return True
    else:
        return False

def rangestring0():
    for size in itertools.count(1):
        for s in itertools.product(ascii_uppercase, repeat=size):
            yield ''.join(s)

def rangestring(vqt):
    qt = 0
    for v in rangestring0():
        qt += 1
        if qt == vqt:
            return v

def rangestringX(vx):
    qt = 0
    for v in rangestring0():
        qt += 1
        if v == vx:
            return qt

def carrega_heads(idx, arq):
    xl = win32.DispatchEx('Excel.Application')
    wb = xl.Workbooks.Open(arq)
    ws = xl.ActiveWorkbook.Sheets(1)

    cnx.sqlcmd(cnx(), 'delete from importacoes_cadastros_detalhes where id_ic = ' + str(idx))
    cons = cnx.sqllist1(cnx(),
                        'select head_col, head_lin, head_tam from importacoes_cadastros where id = ' + str(idx))
    ran1 = str(cons[0]) + str(cons[1]) + ':' + str(rangestring(cons[2])) + str(cons[1])
    ran = ws.Range(ran1).Value[0]
    r = 1
    for i in ran:
        cnx.sqlcmd(cnx(),
                   'insert into importacoes_cadastros_detalhes(id_ic, cp_e, pos) values (' + str(idx) + ', "' + str(
                       i) + '", ' + str(r) + ')')
        r += 1

    wb.Close()
    xl.Application.Quit()

def lista_heads(arq):
    excel = win32.gencache.EnsureDispatch('Excel.Application')
    wb = excel.Workbooks.Open(arq)
    ws = excel.ActiveWorkbook.Sheets(1)

    # for i in ws.Range("A1:A2000").Value

def importa_xl(idx):
    lst = cnx.sqllist1(cnx(), 'select concat(id, " - ", tab) from importacoes_cadastros where id = ' + str(idx))
    lst1 = cnx.sqllist1(cnx(), 'select concat(id, " - ", tab) from importacoes_cadastros where sub = ' + str(idx))
    for i in lst1:
        lst.append(i)
    qt = cnx.sqlquery(cnx(), 'select count(cp_e) from importacoes_cadastros_detalhes where id_ic = ' + str(idx))
    return lst

def nomes_abas(arq):
    xl = win32.DispatchEx('Excel.Application')
    wb = xl.Workbooks.Open(arq)
    resp = []
    for i in range(1, wb.Worksheets.Count + 1):
        resp.append(wb.Worksheets.Item(i).Name)
    wb.Close()
    xl.Application.Quit()
    return resp

def abre_arquivo_xl(arq):
    global xl
    global wb
    xl = win32.DispatchEx('Excel.Application')
    wb = xl.Workbooks.Open(arq)
    resp = []
    for i in range(1, wb.Worksheets.Count + 1):
        resp.append(wb.Worksheets.Item(i).Name)
    return resp

def verifica_layout_xl(aba, idx):
    global ws
    ws = wb.Sheets(aba)
    ran = str(cnx.sqllist1(cnx(), 'select r_head from importacoes_cadastros where id = ' + str(idx))[0])
    ext = list(ws.Range(ran).Value[0])
    int = cnx.sqllist1(cnx(), 'select cp_e from importacoes_cadastros_detalhes where id_ic = ' + str(idx))
    if ext == int:
        return True
    else:
        return False

def importa_arquivo_xl(idx, dti, dtf):
    cons = cnx.sqllist1(cnx(),
                        'select pri, r_imp, head_col, tab from importacoes_cadastros where id = ' + str(idx))
    ran = cons[2] + ':' + cons[2]
    ran1 = ws.Range(ran).Value
    qt = 0
    while not str(ran1[qt][0]) == cons[0]:
        qt += 1
    while ran1[qt][0] is not None:
        qt += 1
    exp = list(ws.Range((cons[1] + str(qt))).Value)
    with open('./imp.csv', 'w', newline='') as f:
        writer = csv.writer(f, quotechar='"')
        writer.writerows(exp)
    cimp = cnx()
    cimp.sqlcmd('create temporary table ' + cons[3] + '_tmp like ' + cons[3])
    query1 = cnx.sqllistimp(cnx(), idx)
    query = """LOAD DATA LOCAL INFILE './imp.csv'
    INTO TABLE """ + cons[3] + '_tmp'"""
    FIELDS TERMINATED BY ',' ENCLOSED BY '"'
    LINES TERMINATED BY '\\n'
    (""" + query1[0] + ') set ' + query1[1]
    cimp.sqlcmd(query)
    resp = cimp.sqllist1('select count(dthr) from ' + cons[
        3] + '_tmp where date_format(dthr, "%Y-%m-%d") >= "' + dti + '" and date_format(dthr, "%Y-%m-%d") <= "' + dtf + '"')
    msgbox = messagebox.askokcancel('Importação', 'Confirma importação de ' + str(resp[0]) + ' linhas?')
    if msgbox:
        cimp.sqlcmd('insert into ' + cons[3] + ' select * from ' + cons[
            3] + '_tmp where date_format(dthr, "%Y-%m-%d") >= "' + dti + '" and date_format(dthr, "%Y-%m-%d") <= "' + dtf + '"')
        sub = cnx.csql(cnx(), 'select id, tab from importacoes_cadastros where sub = ' + str(idx))
        for i in sub:
            query1 = cnx.sqllistimp(cnx(), i[0])
            query = """LOAD DATA LOCAL INFILE './imp.csv'
            INTO TABLE """ + i[1] + """
            FIELDS TERMINATED BY ',' ENCLOSED BY '"'
            LINES TERMINATED BY '\\n'
            (""" + query1[0] + ') set ' + query1[1]
            cnx.sqlcmd(cnx(), query)
    fecha_arquivo_xl()
    return msgbox

def fecha_arquivo_xl():
    xl.Application.Quit()

def monta_range_imp(a, b, c):
    res = []
    d = ''
    for i in a:
        if i.isdigit():
            d += str(i)
    tm = rangestring(c)
    res.append(a + ':' + tm + d)
    res.append(b + ':' + tm)
    return res

def monta_range(idx):
    res = []
    cons = cnx.sqllist1(cnx(),
                        'select r_imp, head_col, head_lin, head_tam from importacoes_cadastros where id = ' + str(idx))
    cons1 = cnx.sqllist1(cnx(),
                         'select cp_e from importacoes_cadastros_detalhes where id_ic = ' + str(idx) + ' and pos = 1')
    h_l = cons[2]
    h_t = rangestring(cons[3])
    res.append(str(cons[1]) + str(h_l + 1) + ':' + h_t)
    res.append(str(cons[1]) + str(h_l) + ':' + h_t + str(h_l))
    res.append(cons1[0])
    return res

def monta_range_dados(arq, aba, idx):
    xl = win32.DispatchEx('Excel.Application')
    wb = xl.Workbooks.Open(arq)
    ws = wb.Sheets(aba)

def carrega_range(idx):
    res = monta_range(idx)
    cnx.sqlcmd(cnx(),
               'update importacoes_cadastros set pri = "' + str(res[2]) + '", r_imp = "' + str(
                   res[0]) + '", r_head = "' + str(res[1]) + '" where id = ' + str(idx))

def salvar_xlcsv(arq, aba, idx):
    xl = win32.DispatchEx('Excel.Application')
    wb = xl.Workbooks.Open(arq)
    ws = wb.Sheets(aba)

def gera_simp():
    print(cnx.sqllist2(cnx(), 'select pos from importacoes_cadastros_detalhes where id_ic = 1'))

def gera_diario():
    Z = ['Encerramento de Obra', 'Cliente', 'Localidade', 'Circuito', 'Gram', 'Gra', 'Diagrama', 'Acionamento', 'PC/IF', 'Reserva', 'Início Real', 'Término Real', 'Tipo de Medição', 'Nº da Medição', 'Valor do Projeto', 'Adicional', 'Desconto', 'Valor Faturado', 'Nº HANDOVER']
    xl = win32.DispatchEx('Excel.Application')
    wb = xl.Workbooks.Add()
    wb.Worksheets(1).Name = 'Teste4'
    ws = wb.Worksheets(1)
    ws.Range('A1:A19').Value = list(zip(Z))
    ws.Range('A1:B1').Merge(False)
    #ws.Range('A1:B1').WrapText = True
    #ws.Range('A1').Width = 30
    ws.Range('A1:B19').Borders.LineStyle = 1
    ws.Columns.AutoFit()
    wb.SaveAs(r'C:\Projects\teste5.xlsx')
    wb.Close(True)
    xl.Quit()

def criaTrigger(nm):
    a = """CREATE DEFINER=`root`@`192.168.%.%` TRIGGER """ + nm + """_tgr1_bi
  BEFORE INSERT ON """ + nm + """
  FOR EACH ROW
 BEGIN
  SET NEW.dtr = NOW();
  IF NEW.ss IS NULL THEN
    SET NEW.ss = fncGetPriSs(NEW.og);
  END IF;
  CALL prcGetSs(NEW.ss, @1, @2, @3, @4, @5, @6, @7);
  IF @3 = 1 THEN
    SET NEW.idp = @4;
  ELSE
    SET NEW.idp = @4;
  END IF;
  SET NEW.dt = fncGetDtSs(@1, @2, NEW.dt);
  SET NEW.dtp = fncGetDtpSs(NEW.dt, @5, @6, @7, NEW.idp);
 END;"""

    b = """CREATE DEFINER=`root`@`192.168.%.%` TRIGGER """ + nm + """_tgr2_bu
  BEFORE UPDATE ON """ + nm + """
  FOR EACH ROW
 BEGIN
  DECLARE vDthr datetime DEFAULT NOW();
  IF OLD.ssp IS NULL AND NEW.ssp IS NOT NULL THEN
    INSERT
      INTO """ + nm + """_ss
      (og, dt, dtp, dte, ss, ssp, idp, rg, dtr, o, op)
    VALUES
      (OLD.id, OLD.dt, OLD.dtp, vDthr, OLD.ss, OLD.ssp, OLD.idp, OLD.rg, OLD.dtr, OLD.o, OLD.op);
    SET NEW.dt = vDthr;
    SET NEW.dtp = NULL;
  ELSE
    IF NEW.ss IS NOT NULL OR (OLD.ssp IS NOT NULL AND NEW.ssp IS NULL) THEN
      SET NEW.dtr = NOW();
      IF fncGetUltSs(OLD.og, NEW.ss) = 1 THEN
        SET NEW.dte = vDthr;
        SET NEW.ss = 0;
      END IF;
      INSERT
        INTO """ + nm + """_ss
        (og, dt, dtp, dte, ss, ssp, idp, rg, dtr, o, op)
      VALUES
        (OLD.id, OLD.dt, OLD.dtp, vDthr, OLD.ss, OLD.ssp, OLD.idp, OLD.rg, OLD.dtr, OLD.o, OLD.op);
      SET NEW.dt = vDthr;
      CALL prcGetSs(NEW.ss, @1, @2, @3, @4, @5, @6, @7);
      IF @3 = 1 THEN
        SET NEW.idp = @4;
      ELSE
        SET NEW.idp = @4;
      END IF;
      SET NEW.dtp = fncGetDtpSs(NEW.dt, @5, @6, @7, NEW.idp);
    END IF;
  END IF;
 END;"""
    cnx.sqlcmd(cnx(), a)
    cnx.sqlcmd(cnx(), b)

def vtela(ps, cp, tb, cn=''): #ps=valor para pesquisar / cp=campo da consulta / tb=tabela da consulta / cn=condição da consulta
    query = 'select ' + cp + ' from ' + tb
    if len(cn) > 0:
        query = query + ' ' + cn
    a = cnx.sqllist1(cnx(), query)
    if ps in a:
        return True
    else:
        return False

class win():
    def __init__(self, master, root, vEx, vEy, vNm):
        self.style = ttk.Style()
        self.style.configure('Treeview.Heading', font=font3)
        self.master = master
        if root != '':
            self.master.transient(root)
        self.master['bg'] = cor_f
        l_tela = self.master.winfo_screenwidth()
        a_tela = self.master.winfo_screenheight()
        l_ws = vEx  # self.master.winfo_width()
        a_ws = vEy  # self.master.winfo_height()
        posx = l_tela / 2 - l_ws / 2
        posy = a_tela / 2 - a_ws / 1.85
        self.master.resizable(width=0, height=0)
        self.master.focus_force()
        self.master.grab_set()
        self.master.geometry("%dx%d+%d+%d" % (l_ws, a_ws, posx, posy))
        self.master.iconphoto(False, tk.PhotoImage(file=modulos.janelas.icon))
        self.master.title(vNm + ' para ' + modulos.janelas.vNm_r + ' | lvflwX ' + vVer1)

class frm(Frame):
    def __init__(self, master=None, row=None, column=None, sticky=W, **kwargs):
        super().__init__(master=master, bg=cor_f, borderwidth=1, relief='ridge', **kwargs)
        self.grid(row=row, column=column, sticky=sticky, ipadx=2, ipady=2, padx=10, pady=10)

class en(Entry):
    def __init__(self, master=None, row=None, column=None, width=None, bd=[], sticky=W, font=font2, rs=None, cs=None, **kwargs):
        super().__init__(master=master, width=width, font=font, **kwargs)
        if len(bd) > 0:
            for i in bd:
                self.bind(i[0], i[1])
        self.grid(row=row, column=column, rowspan=rs, columnspan=cs, sticky=sticky, padx=vpx, pady=vpy)

class lb(Label):
    def __init__(self, master=None, row=None, column=None, text=None, sticky=W, font=font2, rs=None, cs=None, **kwargs):
        super().__init__(master=master, text=text, bg=cor_f, font=font, **kwargs)
        self.grid(row=row, column=column, rowspan=rs, columnspan=cs, sticky=sticky, padx=vpx, pady=vpy)

class sp(Label):
    def __init__(self, master=None, row=None, column=None, text=None, sticky=W, font=sep1, rs=None, cs=None, **kwargs):
        super().__init__(master=master, text=text, bg=cor_f, font=font, **kwargs)
        self.grid(row=row, column=column, rowspan=rs, columnspan=cs, sticky=sticky)

class bt(Button):
    def __init__(self, master=None, row=None, column=None, text=None, command=None, width=None, sticky=W, rs=None, cs=None, font=font2, **kwargs):
        super().__init__(master=master, text=text, font=font, width=width, command=command, **kwargs)
        self.grid(row=row, column=column, rowspan=rs, columnspan=cs, sticky=sticky, padx=vpx, pady=vpy)

class ls(ttk.Treeview):
    def __init__(self, master=None, row=None, column=None, height=None, bd=[], sticky=W, rs=None, cs=None, **kwargs):
        super().__init__(master=master, height=height, **kwargs)
        if len(bd) > 0:
            for i in bd:
                self.bind(i[0], i[1])
        self.grid(row=row, column=column, rowspan=rs, columnspan=cs, sticky=sticky, padx=vpx, pady=vpy)

class cb(ttk.Combobox):
    def __init__(self, master=None, row=None, column=None, width=None, bd=[], sticky=W, rs=None, cs=None, state='readonly', **kwargs):
        super().__init__(master=master, width=width, font=font2, state=state, **kwargs)
        if len(bd) > 0:
            for i in bd:
                self.bind(i[0], i[1])
        self.bind('<Escape>', self.esc)
        self.grid(row=row, column=column, rowspan=rs, columnspan=cs, sticky=sticky, padx=vpx, pady=vpy)
    def esc(self, ev):
        self.set('')

class ck(Checkbutton):
    def __init__(self, master=None, row=None, column=None, text=None, var=None, sticky=W, rs=None, cs=None, **kwargs):
        super().__init__(master=master, text=text, bg=cor_f, font=font2, activebackground=cor_f, activeforeground=cor_f, var=var, **kwargs)
        self.grid(row=row, column=column, rowspan=rs, columnspan=cs, sticky=sticky, padx=vpx, pady=vpy)

class fr(Frame):
    def __init__(self, master=None, row=None, column=None, sticky=W, rs=None, cs=None, **kwargs):
        super().__init__(master=master, bg=cor_f, **kwargs)
        self.grid(row=row, column=column, rowspan=rs, columnspan=cs, sticky=sticky, padx=vpx, pady=vpy)

class rb(Radiobutton):
   def __init__(self, master=None, row=None, column=None, text=None, var=None, bd=[], sticky=W, rs=None, cs=None, **kwargs):
        super().__init__(master=master, text=text, bg=cor_f, font=font2, activebackground=cor_f, activeforeground=cor_f, var=var, **kwargs)
        if len(bd) > 0:
            for i in bd:
                self.bind(i[0], i[1])
        self.grid(row=row, column=column, rowspan=rs, columnspan=cs, sticky=sticky, padx=vpx, pady=vpy) 