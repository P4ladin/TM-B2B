import json
import socket
import os
from tkinter import messagebox

import mysql.connector
from cryptography.fernet import Fernet

def dec(txt):
    k = 'UqFSyNZKimlsXaKNK2TaS-xRZjAW5CP4fS2D0dLRKc0='
    k = k.encode()
    f = Fernet(k)
    return f.decrypt(txt.encode()).decode()

with open('./divs/lvw.json') as j:
    jf = json.load(j)

vVer1 = jf['system']['ver1']
vVer2 = jf['system']['ver2']
vHost = dec(jf['system']['host'])
vUser = dec(jf['system']['user'])
vPass = dec(jf['system']['pass'])
vData = dec(jf['system']['data'])

def chksrv():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.connect((vHost, int('3306')))
        s.shutdown(2)
        return True
    except:
        return False

class cnx():
    def __init__(self):
        while chksrv() == False:
            msgbox = messagebox.askretrycancel('Sistema', 'Servidor não encontrado, certifique se está conectado à rede Telemont!')
            if msgbox:
                pass
            else:
                messagebox.showinfo('Sistema', 'O Sistema será finalizado!', icon='info')
                quit()
        self.con = mysql.connector.connect(
            host=vHost,
            user=vUser,
            passwd=vPass,
            database=vData
        )
        self.cur = self.con.cursor()

    def csql(self, sql):
        self.cur.execute(sql)
        res = self.cur.fetchall()
        return res

    def q(self, s):
        self.cur.execute(s)
        r = self.cur.fetchone()
        if r == None:
            return False
        else:
            return r[0]

    def qin(self, c, t):
        self.cur.execute(f'select {c} from {t}')
        r = self.cur.fetchall()
        if r == None:
            return False
        else:
            q = 1
            s = '('
            for i in r:
                if q == 1:
                    s = f'{s}{i[0]}'
                else:
                    s = f'{s}, {i[0]}'
                q += 1
            s = f'{s})'
            return s

    def csql1(self, sql):
        self.cur.execute(sql)
        res = self.cur.fetchone()
        return res

    def qcb(self, cp1, cp2, tb, o, f=''): #select para preencher combobox / o ordena pela coluna / ftr where
        if f == '':
            sql = f'select concat({cp1}, " - ", {cp2}) from {tb} order by {o}'
        else:
            sql = f'select concat({cp1}, " - ", {cp2}) from {tb} where {f} order by {o}'
        self.cur.execute(sql)
        r = self.cur.fetchall()
        res = []
        for i in r:
            res.append(i[0])
        return res

    def sqlcmd(self, sql):
        self.cur.execute(sql)
        self.con.commit()

    def sqlcmdt(self, a, b, c, d, e):
        self.cur.execute('call prcInsCAtvd(%s, %s, %s, %s, %s)', (a, b, c, d, e))
        self.con.commit()

    def sqlcmdid(self, sql):
        self.cur.execute(sql)
        self.cur.execute('select last_insert_id()')
        rs = self.cur.fetchone()
        self.con.commit()
        return int(rs[0])

    def sqlcmmd(self, sql):
        sql = sql.split(';')
        for i in sql:
            self.cur.execute(i)
            self.con.commit()

    def sqltest(self, campo, tabela, condicao):
        cons = 'select count(' + campo + ') from ' + tabela + ' where ' + campo + ' = ' + condicao
        self.cur.execute(cons)
        rs = self.cur.fetchone()
        if int(rs[0]) == 1:
            return True

    def sqlpass(self, senha, user):
        cons = 'select fncPassDec("' + senha + '", ' + user + ')'
        self.cur.execute(cons)
        rs = self.cur.fetchone()
        if rs[0] == senha:
            return True
        else:
            return False

    def sqlsel(self, campo, tabela, condicao):
        cons = 'select * from ' + tabela + ' where ' + campo + ' = ' + condicao
        self.cur.execute(cons)
        res = self.cur.fetchone()
        return res

    def sqlquery(self, query):
        self.cur.execute(query)
        res = self.cur.fetchall()
        return res

    def sqldict(self, query, cp):
        self.cur.execute(query)
        a = self.cur.fetchall()
        dic = {}
        key = ''
        qt = 0
        for row in a:
            for col in row:
                qt += 1
                if qt == 1:
                    key = col
                    dic[key] = []
                else:
                    dic[key].append(col)
                    if qt == cp:
                        qt = 0
        return dic

    def sqllist(self, query):
        self.cur.execute(query)
        c = self.cur.fetchall()
        lst = {}
        qt = 1
        for row in c:
            lst[qt] = []
            for col in row:
                lst[qt].append(col)
            qt += 1
        return lst

    def sqlcmb(self, chave, valor, tabela, cond=''):
        if cond == '':
            if valor == '':
                query = 'SELECT ' + chave + ', ' + chave + ' FROM ' + tabela + ' ORDER BY ' + chave
            else:
                query = 'SELECT CONCAT(' + chave + '," - ",' + valor + '),' + chave + ' FROM ' + tabela + ' ORDER BY ' + valor
        else:
            query = 'SELECT CONCAT(' + chave + '," - ",' + valor + '),' + chave + ' FROM ' + tabela + ' WHERE CONCAT(' + chave + ',' + valor + ') like "%' + cond + '%"' + ' ORDER BY ' + valor
        self.cur.execute(query)
        a = self.cur.fetchall()
        dic = {}
        key = ''
        qt = 0
        for row in a:
            for col in row:
                qt += 1
                if qt == 1:
                    key = col
                    dic[key] = []
                else:
                    dic[key].append(col)
                    if qt == 2:
                        qt = 0
        return list(dic.keys())

    def sqlexist(self, campo, tabela, condicao):
        cons = 'select count(' + campo + ') from ' + tabela + ' where ' + campo + ' = ' + condicao
        self.cur.execute(cons)
        rs = self.cur.fetchone()
        if int(rs[0]) > 0:
            return True
        else:
            return False

    def sqlcmb2(self, id, ds, tab, ccond='', cond=''):
        if ccond == '':
            if cond == '':
                if ds == '':
                    query = 'SELECT ' + id + ', ' + id + ' FROM ' + tab + ' ORDER BY ' + id
                else:
                    query = 'SELECT CONCAT(' + id + '," - ",' + ds + '),' + id + ' FROM ' + tab + ' ORDER BY ' + ds
            else:
                query = 'SELECT CONCAT(' + id + '," - ",' + ds + '),' + id + ' FROM ' + tab + ' WHERE CONCAT(' + id + ',' + ds + ') like "%' + cond + '%"' + ' ORDER BY ' + ds
        else:
            query = 'SELECT CONCAT(' + id + '," - ",' + ds + '),' + id + ' FROM ' + tab + ' WHERE ' + ccond + ' = ' + cond + ' ORDER BY ' + ds

        self.cur.execute(query)
        a = self.cur.fetchall()
        dic = {}
        key = ''
        qt = 0
        for row in a:
            for col in row:
                qt += 1
                if qt == 1:
                    key = col
                    dic[key] = []
                else:
                    dic[key].append(col)
                    if qt == 2:
                        qt = 0
        return list(dic.keys())

    def sqlcb(self, id, ds, tab, cond=''):
        if cond == '':
            query = 'SELECT CONCAT(coalesce(' + id + ', "NULO")," - ",coalesce(' + ds + ', "NULO")), ' + id + ' FROM ' + tab + ' ORDER BY ' + ds
        else:
            query = 'SELECT CONCAT(coalesce(' + id + ', "NULO")," - ",coalesce(' + ds + ', "NULO")), ' + id + ' FROM ' + tab + ' ' + cond + ' ORDER BY ' + ds
        self.cur.execute(query)
        a = self.cur.fetchall()
        dic = {}
        key = ''
        qt = 0
        for row in a:
            for col in row:
                qt += 1
                if qt == 1:
                    key = col
                    dic[key] = []
                else:
                    dic[key].append(col)
                    if qt == 2:
                        qt = 0
        return list(dic.keys())

    def sqlexist1(self, campo, tabela, condicao):
        cons = 'select count(' + campo + ') from ' + tabela + ' where ' + campo + ' = "' + condicao + '"'
        self.cur.execute(cons)
        rs = self.cur.fetchone()
        if int(rs[0]) > 0:
            return True

    def sqlexist2(self, campo, tabela, ccond, cond):
        cons = 'select ' + campo + ' from ' + tabela + ' where ' + ccond + ' = "' + cond + '"'
        self.cur.execute(cons)
        rs = self.cur.fetchone()
        return rs

    def sqlexist3(self, cp, tb, cd):
        c = f'select count({cp}) from {tb} {cd}'
        self.cur.execute(c)
        rs = self.cur.fetchone()
        if int(rs[0]) > 0:
            return True
        else:
            return False

    def sqllist1(self, query):
        self.cur.execute(query)
        c = self.cur.fetchall()
        lst = []
        for row in c:
            for col in row:
                lst.append(col)
        return lst

    def sqllistimp(self, idx):
        query = 'select pos from importacoes_cadastros_detalhes where id_ic = ' + str(idx)
        self.cur.execute(query)
        c = self.cur.fetchall()
        res = []
        rs1 = []
        rs2 = []
        for row in c:
            for col in row:
                rs1.append('@' + str(col))
        res.append(str(rs1).replace("'", '').strip('[]'))
        query = 'select cp_i, pos from importacoes_cadastros_detalhes where cp_i is not null and id_ic = ' + str(idx)
        self.cur.execute(query)
        c = self.cur.fetchall()
        for row in c:
            rs2.append(str(row[0]) + '=@' + str(row[1]))
        res.append(str(rs2).replace("'", '').strip('[]'))
        return res

    def sqlcb1(self, id, ds, tab, cond=''):
        if cond == '':
            query = 'SELECT CONCAT(' + id + '," - ",' + ds + '), ' + id + ' FROM ' + tab + ' ORDER BY ' + id
        else:
            query = 'SELECT CONCAT(' + id + '," - ",' + ds + '), ' + id + ' FROM ' + tab + ' where CONCAT(' + id + '," - ",' + ds + ') like "%' + cond + '%" ORDER BY ' + id
        self.cur.execute(query)
        a = self.cur.fetchall()
        dic = {}
        key = ''
        qt = 0
        for row in a:
            for col in row:
                qt += 1
                if qt == 1:
                    key = col
                    dic[key] = []
                else:
                    dic[key].append(col)
                    if qt == 2:
                        qt = 0
        return list(dic.keys())

    def sqlcb2(self, id, ds, tab, cond=''):
        if ds == '':
            if cond == '':
                query = 'SELECT ' + id + ', ' + id + ' FROM ' + tab + ' ORDER BY ' + id
            else:
                query = 'SELECT ' + id + ', ' + id + ' FROM ' + tab + ' ' + cond + ' ORDER BY ' + id
        else:
            if cond == '':
                query = 'SELECT CONCAT(' + id + '," - ",' + ds + '),' + id + ' FROM ' + tab + ' ORDER BY ' + id
            else:
                query = 'SELECT CONCAT(' + id + '," - ",' + ds + '),' + id + ' FROM ' + tab + ' ' + cond + ' ORDER BY ' + id
        self.cur.execute(query)
        a = self.cur.fetchall()
        dic = {}
        key = ''
        qt = 0
        for row in a:
            for col in row:
                qt += 1
                if qt == 1:
                    key = col
                    dic[key] = []
                else:
                    dic[key].append(col)
                    if qt == 2:
                        qt = 0
        return list(dic.keys())

    def sqlcb3(self, id, tab, cond=''): #preencher combobox baseado numa única lista, sem índice.
        if cond == '':
            query = 'SELECT ' + id + ' FROM ' + tab + ' ORDER BY ' + id
        else:
            query = 'SELECT ' + id + ' FROM ' + tab + ' ' + cond + ' ORDER BY ' + id
        self.cur.execute(query)
        a = self.cur.fetchall()
        lis = []
        for i in a:
            lis.append(i)
        return lis
    
    def sqllsts(self, query): #consulta com retorno em forma de lista em string para utilização em filtros SQL in
        self.cur.execute(query)
        res = self.cur.fetchall()
        return str(res[0]).replace("'", '')[:-2] + ')'

    def sqlpss(self, o, s): #consulta com retorno dos próximos status de atividades permitidos o=Atividade Origem e s=Atividade Status
        self.cur.execute(f'select p from atividades_status_v where og = {o} and id_as = {s}')
        res = self.cur.fetchone()
        return str(res).replace("'", '')[:-2] + ')'

    def sqlcid(self, i, d, f, t): #consulta id - ds para cb marcar a posição i=campo Id, d=campo Descrição, f=Filtro e t=Tabela
        self.cur.execute(f'select concat({i}, " - ", {d}) from {t} where {i} = {f}')
        r = self.cur.fetchone()
        try:
            return str(r[0])
        except:
            return ''