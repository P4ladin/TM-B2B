from tkinter.ttk import Treeview
import uuid
from datetime import *
import os
import getpass

from modulos.funcoes import *
from modulos.conexao import *

global vUserLocal, vMacLocal

icon='C:/Sistema/lvflwX/divs/icon.png'

vUserLocal = getpass.getuser()
vMacLocal = os.environ['COMPUTERNAME']

cor_f = 'azure2'
sep = ('', 6)
sep1 = ('', 1)
font1 = ('Verdana', 14, 'bold')
font2 = ('Verdana', 10)
font3 = ('Verdana', 10, 'bold')
font4 = ('Verdana', 7)
font5 = ('Verdana', 7, 'bold')


def open_file(loc, tit, tip=()):
    resp = []
    local = filedialog.askopenfilename(initialdir=loc, title=tit, filetypes=(tip))
    resp.append(local)
    arq = local.split('/')[len(local.split('/')) - 1]
    resp.append(arq)
    return resp

def tvhead(tab, controle, sel=1): #1=browse / 2-extended
    nomes = 'SELECT col, tam, anc FROM listab WHERE tab = "' + tab + '"'
    a = cnx()
    b = a.sqllist(nomes)
    qt = 1
    vis = []
    for i in b:
        if b[qt][1] != 0:
            vis.append(qt)
        qt += 1
    if sel == 1:
        s = 'browse'
    else:
        s = 'extended'
    controle.configure(columns=list(b.keys()), displaycolumns=vis, selectmode=s, show='headings')
    qt = 1
    for i in b:
        controle.heading(qt, text=b[qt][0], anchor=b[qt][2])
        controle.column(qt, stretch=False, minwidth=0, width=b[qt][1], anchor=b[qt][2])
        qt += 1

def ifendt(ctrl):
    try:
        trat = datetime.strptime(ctrl.get(), '%d/%m/%Y %H:%M')
        ctrl.delete(0, END)
        ctrl.insert(0, trat.strftime('%d/%m/%Y %H:%M'))
        return True
    except:
        return False

def getpls(ctrl, pos):
    return str(ctrl.item(ctrl.focus())['values'][pos])

def getlls(ctrl, pos):
    r = []
    a = ctrl.selection()
    for i in a:
        r.append(str(ctrl.item(i)['values'][pos]))
    return r

def getlpls(ctrl, pos, r=1): #monta uma lista com os valores selecionados em uma treeview para utilização em condição SQL in / r=1 sem", r=2 com"
    a = ctrl.selection()
    b = []
    if r == 1:
        for i in a:
            b.append(ctrl.item(i)['values'][pos])
    else:
        for i in a:
            b.append(str(ctrl.item(i)['values'][pos]))
    c = str(b).replace('[', '(').replace(']', ')')
    return c

def getptls(ctrl, pos=()): #compara se todos os valores de uma posição, selecionados numa lista são iguais
    r = []
    if len(ctrl.selection()) > 0:
        for j in pos:
            a = ctrl.selection()
            b = ctrl.item(a[0])['values'][j]
            for i in a:
                c = ctrl.item(i)['values'][j]
                if b != c:
                    r = []
                    r.insert(0, 0)
                    return r
            r.append(b)
        s = 1
    else:
        r.insert(0, 0)
        return r
    r.insert(0, s)
    return r

def getpils(ctrl, pos):
    return int(ctrl.item(ctrl.focus())['values'][pos])

def selidls(ctrl, n):
    ctrl.selection_set(n)
    ctrl.focus(n)
    ctrl.see(n)

def locsells(ctrl, pos, loc):
    if ctrl.exists(1):
        n = 1
        while ctrl.item(n)['values'][pos] != loc:
            n += 1
        if ctrl.item(n)['values'][pos] == loc:
            ctrl.selection_set(n)
            ctrl.focus(n)
            ctrl.see(n)

def locqtls(ctrl, pos, loc):
    qt = 0
    n = 1
    f = len(ctrl.get_children())
    if ctrl.exists(1):
        while n <= f:
            if ctrl.item(n)['values'][pos] == loc:
                qt += 1
            n += 1
    return qt

def locexls(ctrl, pos, loc):
    n = 1
    f = len(ctrl.get_children())
    if ctrl.exists(1):
        while n <= f:
            if ctrl.item(n)['values'][pos] == loc:
                return True
            n += 1
    return False

def getvct(ctrl, o=1, v=''): #o=operador: o=1:==, o=2:> | valor do controle entry e combo
    a = str(type(ctrl))[24:26]
    if len(ctrl.get()) > 0:
        if a == 'en':
            return True
        elif a == 'cb':
            if v == '':
                return True
            else:
                if o == 1:
                    t = int(ctrl.get()[:ctrl.get().find('-') - 1]) == int(v)
                else:
                    t = int(ctrl.get()[:ctrl.get().find('-') - 1]) > int(v)
                return t
    else:
        return v == 0

def getven(ctrl, r=1): #resp: 1=com"/2=sem"
    if len(ctrl.get()) > 0:
        if r == 1:
            return f'"{ctrl.get()}"'
        else:
            return ctrl.get()
    else:
        return 'NULL'

def getpcb(ctrl, t=0):  # 0 = int / 1 = str
    r = ctrl.get()[:ctrl.get().find('-') - 1]
    if r == '' or r == None:
        return 'NULL'
    else:
        if t == 0:
            return int(r)
        else:
            return str(r)

def getdscb(ctrl):
    r = ctrl.get()[ctrl.get().find('-')+2:len(ctrl.get())]
    if r == '' or r == None:
        return None
    else:
        return r

def isdthr(tp, ctrl, prn): # Verifica se controle de entrada e uma data | 0=data hora/1=data/2=hora
    if len(ctrl.get()) > 0:
        if tp == 0:
            frm = '%d/%m/%Y %H:%M'
            msg = 'Data/hora inválidos Ex: 01/01/2000 13:50'
        elif tp == 1:
            frm = '%d/%m/%Y'
            msg = 'Data inválida Ex: 01/01/2000'
        elif tp == 2:
            frm = '%H:%M'
            msg = 'Hora inválida Ex: 13:50'
        if ctrl.get() == '':
            trat = 0
        try:
            trat = datetime.strptime(ctrl.get(), frm)
            ctrl.delete(0, END)
            ctrl.insert(0, trat.strftime(frm))
            return True
        except:
            msgb(1, 'Formato', msg, prn)
            ctrl.focus_force()
            return False
    else:
        return False

def isnr(ctrl, prn): #verifica se entrada numa entry é número
    if len(ctrl.get()) > 0:
        try:
            int(ctrl.get())
            return True
        except:
            msgb(1, 'Formato', 'Somente números!', prn)
            ctrl.focus_force()
            return False
    else:
        return False

def clrls(ctrl):
    if ctrl.exists(1):
        for i in ctrl.get_children():
            ctrl.delete(i)

def limpa_lista(controle):
    if controle.exists(1):
        for i in controle.get_children():
            controle.delete(i)

def msgb(tp, tit, msg, prn): # tp=1:erro/2=info/3=aviso/4=sim-não
    if tp == 1:
        tpa = messagebox.showerror
    elif tp == 2:
        tpa = messagebox.showinfo
    elif tp == 3:
        tpa = messagebox.showwarning
    elif tp == 4:
        tpa = messagebox.askyesno
    return tpa(tit, msg, parent=prn)

def insen(ctrl, txt): #limpa e insere um texto em uma entry readonly
    if ctrl['state'] == 'readonly':
        ctrl.configure(state='normal')
        ctrl.delete(0, END)
        ctrl.insert(0, txt)
        ctrl.configure(state='readonly')
    elif ctrl['state'] == 'normal':
        ctrl.delete(0, END)
        ctrl.insert(0, txt)

def chrls(ctrl, sql, m=1): #carrega uma lista à partir de um select | m=1: apenas carrega, m=2: carrega e mantén selecionada a mesma linha (atualização)
    if m == 2:
        x = int(ctrl.selection()[0])
    clrls(ctrl)
    a = cnx.sqlquery(cnx(), sql)
    if ctrl.exists(1):
        for i in ctrl.get_children():
            ctrl.delete(i)
    idx = 1
    for row in a:
        ctrl.insert('', END, iid=idx, values=row)
        idx += 1
    if m == 2:
        selidls(ctrl, x)

def carrega_lista(tp, tab, controle, filtro='', valor=0, sel=1):  # tp: 0=cabeçalho e itens / 1=cabeçalho / 2=itens / 3=select
    if tp in (0, 1):
        try:
            test = controle.heading(1)
        except:
            tvhead(tab, controle, sel)
    if tp in (0, 2):
        if filtro == '':
            itens = 'select * from ' + tab
        else:
            itens = 'select * from ' + tab + ' where ' + filtro + ' like "%' + str(valor) + '%"'
        a = cnx()
        c = a.sqlquery(itens)
        if controle.exists(1):
            for i in controle.get_children():
                controle.delete(i)
        idx = 1
        for row in c:
            controle.insert('', END, iid=idx, values=row)
            idx += 1
    if tp == 3:
        if filtro == '':
            itens = tab
        else:
            itens = tab + ' where ' + filtro + ' like "%' + str(valor) + '%"'
        a = cnx()
        c = a.sqlquery(itens)
        if controle.exists(1):
            for i in controle.get_children():
                controle.delete(i)
        idx = 1
        for row in c:
            controle.insert('', END, iid=idx, values=row)
            idx += 1

class login():
    def __init__(self, master):
        self.lb1var = StringVar()
        self.lb3var = StringVar()
        self.lb4var = StringVar()
        self.master = master
        self.master['bg'] = cor_f
        l_tela = self.master.winfo_screenwidth()
        a_tela = self.master.winfo_screenheight()
        l_ws = 256  # self.master.winfo_width()
        a_ws = 183  # self.master.winfo_height()
        posx = l_tela / 2 - l_ws / 2
        posy = a_tela / 2 - a_ws / 2
        self.master.resizable(width=0, height=0)
        self.master.geometry("%dx%d+%d+%d" % (l_ws, a_ws, posx, posy))
        self.master.iconphoto(False, tk.PhotoImage(file=icon))
        self.master.title('Login | lvflwX ' + vVer1)

        test = cnx.sqlexist2(cnx(), 'ss', 'sistema_usrlcl', 'lcl', vMacLocal)
        if test == None:
            cnx.sqlcmd(cnx(),
                       'insert into sistema_usrlcl (lcl, usr) values ("' + vMacLocal + '", "' + vUserLocal + '")')
            messagebox.showinfo('Sistema',
                                'Este é o primeiro acesso deste computador ao sistema, foi solicitada autoriação de execução ao administrador!',
                                icon='info')
            self.master.destroy()
            exit()
        elif int(test[0]) == 1:
            messagebox.showinfo('Sistema',
                                'A liberação de utilização ao sistema por este computador ainda não foi avaliada pelo administrador!',
                                icon='info')
            self.master.destroy()
            exit()
        elif int(test[0]) == 2:
            if cnx.sqlexist2(cnx(), 'usr', 'sistema_usrlcl', 'lcl', vMacLocal)[0] == vUserLocal:
                pass
            else:
                messagebox.showinfo('Sistema', 'Execução não autorizada!', icon='error')
                self.master.destroy()
                exit()
        elif int(test[0]) == 3:
            messagebox.showinfo('Sistema', 'Instalação não autorizada!', icon='error')
            self.master.destroy()
            exit()

        self.fr1 = Frame(self.master, bg=cor_f)
        self.lb1 = Label(self.fr1, textvariable=self.lb1var, bg='azure3', font=font1).grid(row=0, columnspan=2,
                                                                                           sticky='we')
        self.lb1var.set('Autenticação')
        self.lb2 = Label(self.fr1, bg=cor_f, font=sep).grid(row=1, columnspan=2, sticky='we')
        self.lb3 = Label(self.fr1, textvariable=self.lb3var, bg=cor_f, font=font1).grid(row=2, column=0, sticky=E)
        self.lb3var.set('Usuário')
        self.en1 = Entry(self.fr1, width=10, font=font1)
        self.en1.grid(row=2, column=1)
        self.lb4 = Label(self.fr1, textvariable=self.lb4var, bg=cor_f, font=font1).grid(row=3, column=0, sticky=E)
        self.lb4var.set('Senha')
        self.en2 = Entry(self.fr1, width=10, show='*', font=font1)
        self.en2.bind('<Return>', lambda event: self.fncEntrar())
        self.en2.grid(row=3, column=1)
        self.lb5 = Label(self.fr1, bg=cor_f, font=sep).grid(row=4, columnspan=2, sticky='we')
        self.bt1 = Button(self.fr1, text='Sair', font=font1, command=self.master.destroy)
        self.bt1.grid(row=5, column=0)
        self.bt2 = Button(self.fr1, text='Entrar', font=font1, command=self.fncEntrar)
        self.bt2.grid(row=5, column=1)
        self.fr1.grid(padx=12, pady=12)

        self.master.mainloop()

    def fncAlterar(self):
        vNova, vRepetir = self.en1.get(), self.en2.get()
        if vNova != '' or vRepetir != '':
            if vNova == vRepetir:
                if len(vNova) >= 6:
                    if not cnx.sqlpass(cnx(), vNova, str(vCd)):
                        cnx.sqlcmd(cnx(),
                                   'update usuarios set ss = 2, se = fncPassEnc("' + vNova + '") where id = ' + str(
                                       vId))
                        messagebox.showinfo('Login', 'A senha foi alterada!')
                        self.en2.delete(0, END)
                        self.en1.delete(0, END)
                        self.lb1var.set('Altenticação')
                        self.lb3var.set('Usuário')
                        self.lb4var.set('Senha')
                        self.en1.configure(show='')
                        self.en2.bind('<Return>', lambda event: self.fncEntrar())
                        self.bt3.destroy()
                        self.bt2 = Button(self.fr1, text='Entrar', font=font1, command=self.fncEntrar)
                        self.bt2.grid(row=5, column=1)
                        self.en1.insert(0, vCd)
                        self.en2.focus_force()
                    else:
                        messagebox.showinfo('Alerta', 'A senha não pode ser igual a última utilizada!')
                else:
                    messagebox.showinfo('Alerta', 'A senha não pode ter menos que 6 dígitos!')
            else:
                messagebox.showinfo('Alerta', 'As senhas digitadas não são idênticas!')
        else:
            messagebox.showinfo('Alerta', 'Os campos usuário ou senha não podem ser vazios!')

    def fncEntrar(self):
        global vId, vCd, vCdp, vNm, vNm_r, vNm_p, vS, vC, vPs
        vUser, vPass = self.en1.get(), self.en2.get()
        if vUser != '' or vPass != '':
            a = cnx.q(cnx(), f'select id, cd_p, ss from usuarios where cd_p = {vUser}')
            if a:
                if cnx.sqlpass(cnx(), vPass, vUser):
                    vId, vCd, b = a
                    if b == 1:
                        messagebox.showinfo('Login', 'A senha deve ser alterada!')
                        self.en2.delete(0, END)
                        self.en1.delete(0, END)
                        self.lb1var.set('Alterar Senha')
                        self.lb3var.set('Nova')
                        self.lb4var.set('Repetir')
                        self.en1.configure(show='*')
                        self.en2.bind('<Return>', lambda event: self.fncAlterar())
                        self.bt2.destroy()
                        self.bt3 = Button(self.fr1, text='Alterar', font=font1, command=self.fncAlterar)
                        self.bt3.grid(row=5, column=1)
                        self.en1.focus_force()
                    elif b == 2:
                        vId, vCd, vCdp, vNm, vNm_r, vNm_p, vS, vC, vPs = cnx.sqlsel(cnx(), 'cd', 'vw_colab_usr', vUser)
                        self.master.destroy()
                        self.w_app1 = Tk()
                        self.app1 = principal(self.w_app1)
                    elif b == 3:
                        messagebox.showinfo('Login', 'Usuário bloqueado!')
                else:
                    messagebox.showinfo('Login', 'Senha incorreta!')
            else:
                messagebox.showinfo('Login', 'Usuário não encontrado!')
        else:
            messagebox.showinfo('Alerta', 'Os campos usuário ou senha não podem ser vazios!')

class principal():
    def __init__(self, master):
        self.masterp = master
        self.masterp['bg'] = cor_f
        l_tela = self.masterp.winfo_screenwidth()
        a_tela = self.masterp.winfo_screenheight()
        l_ws = 800  # self.masterp.winfo_width()
        a_ws = 600  # self.masterp.winfo_height()
        posx = l_tela / 2 - l_ws / 2
        posy = a_tela / 2 - a_ws / 2
        self.masterp.resizable(width=0, height=0)
        self.masterp.geometry("%dx%d+%d+%d" % (l_ws, a_ws, posx, posy))
        self.masterp.iconphoto(False, tk.PhotoImage(file=icon))
        self.masterp.title('Principal para ' + vNm_r + ' | lvflwX ' + vVer1)

        self.fr1 = Frame(self.masterp, bg=cor_f)
        self.lb1 = Label(self.fr1, bg='azure3', font=font3, anchor=E).grid(row=0, column=0, sticky='we')
        self.lb2 = Label(self.fr1, text='Logado como ' + vNm_r, bg='azure3', font=font3, anchor=E, width=63).grid(row=0,
                                                                                                                  column=1,
                                                                                                                  sticky='we')
        self.lb3 = Label(self.fr1, text='Comandos', bg=cor_f, font=font2).grid(row=2, column=0, sticky=W)
        self.lb4 = Label(self.fr1, text='Atividades', bg=cor_f, font=font2).grid(row=2, column=1, sticky=W)
        self.ls1 = ttk.Treeview(self.fr1, show='tree', height=25)
        self.carrega_controle(
            'select * from vw_sc where id in (select id_sc from vw_scu_liberados where id_u = ' + str(vId) + ')',
            self.ls1)
        self.ls1.bind('<Double-1>', self.on_action)
        self.ls1.grid(row=3, column=0, sticky='wns', padx=(4, 0), pady=(4, 0))
        self.ls2 = ttk.Treeview(self.fr1, height=25)
        self.ls2.grid(row=3, column=1, sticky='we', padx=(4, 0), pady=(4, 0))
        self.fr1.grid(padx=10, pady=10)

        self.masterp.mainloop()

    def carrega_controle(self, query, controle):
        b = cnx.sqlquery(cnx(), query)
        for row in b:
            if row[0] == 0:
                idx = controle.insert('', END, row[2], text=row[3])
            else:
                controle.insert(idx, END, row[2], text=row[3])

    def on_action(self, event):
        if (self.ls1.selection()[0])[0] != 'I':
            fnc = eval(self.ls1.selection()[0])
            self.w_app2 = Toplevel(self.masterp)
            self.app2 = fnc(self.w_app2, self.masterp)

class popup():
    def __init__(self, master, root, vEx, vEy, vNm):
        #self.ls1_index = 0
        #self.style = ttk.Style()
        self.master = master
        self.master['bg'] = cor_f
        l_tela = self.master.winfo_screenwidth()
        a_tela = self.master.winfo_screenheight()
        l_ws = vEx  # self.master.winfo_width()
        a_ws = vEy  # self.master.winfo_height()
        posx = l_tela / 2 - l_ws / 2
        posy = a_tela / 2 - a_ws / 1.85
        self.master.resizable(width=0, height=0)
        self.master.transient(root)
        self.master.focus_force()
        self.master.grab_set()
        self.master.geometry("%dx%d+%d+%d" % (l_ws, a_ws, posx, posy))
        self.master.iconphoto(False, tk.PhotoImage(file=icon))
        self.master.title(vNm + ' para ' + vNm_r + ' | lvflwX ' + vVer1)

class slct():
    def __init__(self, master, root):
        self.ls1_index = 0
        self.style = ttk.Style()
        self.master = master
        self.master['bg'] = cor_f
        l_tela = self.master.winfo_screenwidth()
        a_tela = self.master.winfo_screenheight()
        l_ws = 960  # self.master.winfo_width()
        a_ws = 660  # self.master.winfo_height()
        posx = l_tela / 2 - l_ws / 2
        posy = a_tela / 2 - a_ws / 1.85
        self.master.resizable(width=0, height=0)
        self.master.transient(root)
        self.master.focus_force()
        self.master.grab_set()
        self.master.geometry("%dx%d+%d+%d" % (l_ws, a_ws, posx, posy))
        self.master.iconphoto(False, tk.PhotoImage(file=icon))
        self.master.title('Solicitação de Material e Serviço para ' + vNm_r + ' | lvflwX ' + vVer1)
        self.fr1 = Frame(self.master, bg=cor_f)

        self.fr2 = Frame(self.fr1, borderwidth=1, relief='ridge', bg=cor_f)
        self.bt1 = Button(self.fr2, width=5, font=font2, command=self.press_bt1)
        self.lb1 = Label(self.fr2, text='Solicitante:', bg=cor_f, font=font2).grid(row=1, column=0, sticky='sw',
                                                                                   padx=(4, 0))
        self.en1 = Entry(self.fr2, width=50, font=font2)
        self.en1.grid(row=2, column=0, padx=(4, 0))
        self.en1.bind('<Tab>', self.carrega_cb1)
        self.cb1 = ttk.Combobox(self.fr2, state='readonly')
        self.cb1.bind('<<ComboboxSelected>>', self.carrega_cb2)
        self.cb1.grid(row=3, column=0, sticky='we', padx=(4, 0))
        self.lb2 = Label(self.fr2, text='Anexo:', bg=cor_f, font=font2).grid(row=0, column=1, rowspan=1, columnspan=2,
                                                                             sticky='sw', padx=(4, 0))
        self.en2 = Entry(self.fr2, state='readonly', font=font2)
        self.en2.grid(row=1, column=1, columnspan=2, sticky='we', padx=(4, 0))
        self.bt3 = Button(self.fr2, text='Localizar', font=font2, command=self.open_file)
        self.bt3.grid(row=0, column=3, rowspan=2, sticky='ws')
        self.lb3 = Label(self.fr2, text='Data Solicitação:', bg=cor_f, font=font2).grid(row=2, column=1, sticky=W,
                                                                                        padx=(4, 0))
        self.en3 = Entry(self.fr2, width=30, font=font2, justify=RIGHT)
        self.en3.bind('<FocusOut>', self.valida_en3)
        self.en3.grid(row=3, column=1, sticky=W, padx=(4, 0))
        self.lb4 = Label(self.fr2, text='Prioridade:', bg=cor_f, font=font2).grid(row=2, column=2, sticky='sw',
                                                                                  padx=(4, 0))
        self.cb2 = ttk.Combobox(self.fr2, state='disable', width=30)
        self.cb2.grid(row=3, column=2, padx=(4, 0))
        self.ls1 = ttk.Treeview(self.fr2, height=1)
        self.style.configure('Treeview.Heading', font=font3)
        self.carrega_lista('vw_solmat_rep', self.ls1)
        
        if self.ls1.exists(1):
            self.ls1.selection_set(1)
            self.ls1.focus(1)
            self.bt1.configure(text='Salvar')
            # self.en1.configure(state='readonly')
            # self.cb1.configure(state='disable')
            # self.bt3.configure(state='disable')
            # self.en3.configure(state='readonly')
        else:
            self.bt1.configure(text='Nova')
        self.bt1.grid(row=2, column=3, rowspan=2, sticky='es')
        self.ls1.bind('<<TreeviewSelect>>', self.get_ls1)
        self.ls1.grid(row=5, column=0, columnspan=4, sticky='we', padx=(4, 0), pady=(4, 0))
        self.fr2.grid(row=0, column=0, ipadx=2, ipady=2)

        self.fr3 = Frame(self.fr1, borderwidth=1, relief='ridge', bg=cor_f)
        self.lb5 = Label(self.fr3, text='Colaborador:', bg=cor_f, font=font2).grid(row=0, column=0, sticky=W,
                                                                                   padx=(4, 0))
        self.en4 = Entry(self.fr3, width=40, font=font2)
        self.en4.bind('<FocusOut>', self.carrega_cb3)
        self.en4.grid(row=1, column=0, sticky=W, padx=(4, 0))
        self.cb3 = ttk.Combobox(self.fr3, state='readonly')
        self.cb3.grid(row=2, column=0, sticky='we', padx=(4, 0))
        self.lb6 = Label(self.fr3, text='Aplicação:', bg=cor_f, font=font2).grid(row=0, column=1, sticky=W, padx=(4, 0))
        self.cb4 = ttk.Combobox(self.fr3, width=34, state='readonly')
        self.cb4.grid(row=1, column=1, sticky=W, padx=(4, 0))
        self.lb7 = Label(self.fr3, text='Material/Serviço:', bg=cor_f, font=font2).grid(row=0, column=2, sticky=W,
                                                                                        padx=(4, 0))
        self.en5 = Entry(self.fr3, font=font2)
        self.en5.bind('<FocusOut>', self.carrega_cb4)
        self.en5.grid(row=1, column=2, sticky='we', padx=(4, 0))
        self.cb5 = ttk.Combobox(self.fr3, state='readonly', width=40)
        self.cb5.grid(row=2, column=2, sticky='we', padx=(4, 0))
        self.lb8 = Label(self.fr3, text='Qt.:', bg=cor_f, font=font2).grid(row=0, column=3, sticky=W, padx=(4, 0))
        self.en6c = (self.master.register(self.en6_mask), '%d', '%P')
        self.en6 = Entry(self.fr3, width=5, font=font2, validate='key', validatecommand=self.en6c, justify=RIGHT)
        self.en6.grid(row=1, column=3, sticky=W, padx=(4, 0))
        self.bt2 = Button(self.fr3, text='Incluir', font=font2, command=self.press_bt2)
        self.bt2.grid(row=0, column=4, rowspan=3, sticky=E, padx=(4, 0))
        self.ls2 = ttk.Treeview(self.fr3, height=10)
        self.vbar = ttk.Scrollbar(self.fr3, command=self.ls2.yview, orient=VERTICAL)
        self.ls2.configure(yscrollcommand=self.vbar.set)
        self.carrega_lista('vw_solmat_rep_itens', self.ls2, 'id_sm', self.get_ls1()['values'][0])
        self.ls2.grid(row=3, column=0, columnspan=5, sticky='we', padx=(4, 0), pady=(4, 0))
        self.vbar.grid(row=3, column=4, sticky='nse', padx=(4, 0), pady=(4, 0))
        self.fr3.grid(row=1, column=0, ipadx=2, ipady=2, pady=(4, 0), sticky='we')
        self.fr1.grid(padx=10, pady=10)

    def en6_mask(self, action, value_if_allowed):
        if action != '1':
            return True
        try:
            return value_if_allowed.isnumeric()
        except ValueError:
            return False

    def press_bt2(self):
        print(self.cb2.get()[:self.cb2.get().find('-') - 1])

    def press_bt1(self):
        if self.bt1['text'] == 'Salvar':
            if self.ls2.exists(1):
                print('Salvar')
            else:
                messagebox.showinfo('Solicitação de material', 'Não é possível salvar uma solciitação sem itens!')
        else:
            print('Novo')

    def get_ls1(self, event=''):
        curItem = self.ls1.focus()
        return self.ls1.item(curItem)

    def carrega_lista(self, tab, controle, campo='', valor=0):
        nomes = 'SELECT col, tam, anc FROM listab WHERE tab = "' + tab + '"'
        if campo == '':
            itens = 'select * from ' + tab
        else:
            itens = 'select * from ' + tab + ' where ' + campo + ' = ' + str(valor)
        a = cnx()
        b = a.sqllist(nomes)
        qt = 1
        vis = []
        for i in b:
            if b[qt][1] != 0:
                vis.append(qt)
            qt += 1
        controle.configure(columns=list(b.keys()), displaycolumns=vis, show="headings")
        qt = 1
        for i in b:
            controle.heading(qt, text=b[qt][0], anchor=b[qt][2])
            controle.column(qt, stretch=True, minwidth=0, width=b[qt][1], anchor=b[qt][2])
            qt += 1
        a = cnx()
        c = a.sqlquery(itens)
        idx = 1
        for row in c:
            controle.insert('', END, iid=idx, values=row)
            idx += 1

    def carrega_cb1(self, event):
        a = cnx()
        b = a.sqlcmb('cd', 'nm', 'colab', self.en1.get())
        self.cb1['values'] = b
        self.en3.delete(0, END)
        self.en3.insert(0, datetime.now().strftime("%d/%m/%Y %H:%M"))

    def carrega_cb3(self, event):
        a = cnx()
        b = a.sqlcmb('cd', 'nm', 'colab', self.en4.get())
        self.cb3['values'] = b

    def carrega_cb4(self, event):
        a = cnx()
        b = a.sqlcmb('id', 'ds', 'vw_msa_ativos', self.en5.get())
        self.cb4['values'] = b

    def valida_en3(self, event):
        try:
            trat = datetime.strptime(self.en3.get(), "%d/%m/%Y %H:%M")
            self.en3.delete(0, END)
            self.en3.insert(0, trat.strftime("%d/%m/%Y %H:%M"))
        except:
            messagebox.showinfo('Formato', 'Data/Hora inválidos!')
            self.en3.focus_force()

    def carrega_cb2(self, event):
        a = cnx()
        b = a.sqlcmb('id', 'ds', 'solmat_prioridade')
        self.cb2['values'] = b
        self.cb2.current(0)

    def open_file(self):
        arq = filedialog.askopenfilename(initialdir='//Servdatatmt/dados_rmg/GER_DADOS/PLANEJAMENTO E CONTROLE/ANEXOS',
                                         title='Selecione o anexo', filetypes=(('Arquivos msg', '.msg'),))
        self.en2.configure(state='normal', justify=RIGHT)
        self.en2.insert(END, arq)
        self.en2.configure(state='readonly')

class cdst():
    def __init__(self, master, root):
        self.ls1_index = 0
        self.style = ttk.Style()
        self.master = master
        self.master['bg'] = cor_f
        l_tela = self.master.winfo_screenwidth()
        a_tela = self.master.winfo_screenheight()
        l_ws = 960  # self.master.winfo_width()
        a_ws = 660  # self.master.winfo_height()
        posx = l_tela / 2 - l_ws / 2
        posy = a_tela / 2 - a_ws / 1.85
        self.master.resizable(width=0, height=0)
        self.master.transient(root)
        self.master.focus_force()
        self.master.grab_set()
        self.master.geometry("%dx%d+%d+%d" % (l_ws, a_ws, posx, posy))
        self.master.iconphoto(False, tk.PhotoImage(file=icon))
        self.master.title('Cadastro de Material e Serviço para ' + vNm_r + ' | lvflwX ' + vVer1)
        self.fr1 = Frame(self.master, bg=cor_f)

        self.fr2 = Frame(self.fr1, borderwidth=1, relief='ridge', bg=cor_f)

        self.fr2a = Frame(self.fr2, bg=cor_f)
        self.lb1 = Label(self.fr2a, text='Materiais e Serviços:', bg=cor_f, font=font2).grid(row=0, column=0, sticky=W,
                                                                                             padx=(4, 0))
        self.en1 = Entry(self.fr2a, width=40, font=font2)
        self.en1.grid(row=1, column=0, sticky=W, padx=(4, 0))
        self.ckvar = BooleanVar()
        self.ckvar.set(True)
        self.ck1 = Checkbutton(self.fr2a, text='Verificar', bg=cor_f, font=font2, activebackground=cor_f,
                               activeforeground=cor_f, var=self.ckvar,
                               command=lambda: self.carrega_ls1('vw_matserv', self.ls1, self.ckvar.get(), 'pesq',
                                                                self.en1.get()))
        self.ck1.grid(row=1, column=1, sticky=W, padx=(4, 0))
        self.fr2a.grid(row=0, column=0, sticky=W)

        self.ls1 = ttk.Treeview(self.fr2, height=9)
        self.en1.bind('<Tab>',
                      lambda event: self.carrega_ls1('vw_matserv', self.ls1, self.ckvar.get(), 'pesq', self.en1.get()))
        self.ls1.bind('<<TreeviewSelect>>', self.get_ls1)
        self.style.configure('Treeview.Heading', font=font3)
        self.carrega_ls1('vw_matserv', self.ls1, self.ckvar.get(), 'pesq', self.en1.get())
        self.ls1.bind('<<TreeviewSelect>>', self.get_ls1)
        self.ls1.grid(row=1, column=0, sticky='we', padx=(4, 0))

        self.fr2b = Frame(self.fr2, bg=cor_f)
        self.lb2 = Label(self.fr2b, text='Fornecimento:', bg=cor_f, font=font2).grid(row=0, column=0, padx=(4, 0),
                                                                                     pady=(4, 0), sticky=W)
        self.en2 = Entry(self.fr2b, width=22, font=font2, state='readonly')
        self.en2.grid(row=1, column=0, sticky=W, padx=(4, 0))
        self.cb1 = ttk.Combobox(self.fr2b, state='disable')
        self.cb1.grid(row=2, column=0, sticky='we', padx=(4, 0))
        self.lb3 = Label(self.fr2b, text='Grupo:', bg=cor_f, font=font2).grid(row=0, column=1, padx=(4, 0), pady=(4, 0),
                                                                              sticky=W)
        self.en3 = Entry(self.fr2b, width=40, font=font2, state='readonly')
        self.en3.grid(row=1, column=1, sticky=W, padx=(4, 0))
        self.cb2 = ttk.Combobox(self.fr2b, state='disable')
        self.cb2.grid(row=2, column=1, sticky='we', padx=(4, 0))
        self.lb4 = Label(self.fr2b, text='Agrupamento:', bg=cor_f, font=font2).grid(row=0, column=2, padx=(4, 0),
                                                                                    pady=(4, 0), sticky=W)
        self.en4 = Entry(self.fr2b, width=40, font=font2, state='readonly')
        self.en4.grid(row=1, column=2, sticky=W, padx=(4, 0))
        self.cb3 = ttk.Combobox(self.fr2b, state='disable')
        self.cb3.grid(row=2, column=2, sticky='we', padx=(4, 0))
        self.aj1 = Frame(self.fr2b, width=34, bg=cor_f).grid(row=1, column=4, sticky=W)
        self.bt1 = Button(self.fr2b, width=6, text='Editar', font=font2, state='disable', command=self.editms)
        self.bt1.grid(row=1, column=5, rowspan=2, sticky='nswe', padx=(4, 0))
        self.fr2b.grid(row=2, column=0, sticky=W)

        self.carrega_comb('id', 'ds', 'matserv_fornecimento', self.en2, self.cb1)
        self.carrega_comb('id', 'ds', 'matserv_grupo', self.en3, self.cb2)
        self.carrega_comb('id', 'ds', 'matserv_agrupamento', self.en4, self.cb3)

        self.fr2.grid(row=0, column=0, columnspan=2, ipadx=2, ipady=2)

        self.fr1a = Frame(self.fr1, bg=cor_f)

        self.fr3 = Frame(self.fr1a, borderwidth=1, relief='ridge', bg=cor_f)
        self.lb5 = Label(self.fr3, text='Agrupamentos:', bg=cor_f, font=font2).grid(row=0, column=0, sticky=W,
                                                                                    padx=(4, 0))
        self.en5 = Entry(self.fr3, width=34, font=font2)
        self.en5.bind('<Tab>',
                      lambda event: self.carrega_lista(2, 'vw_matserv_agrup', self.ls2, 'pesq', self.en5.get()))
        self.en5.bind('<Escape>', lambda event: self.canagrup())
        self.en5.grid(row=1, column=0, sticky=W, padx=(4, 0))
        self.lb6 = Label(self.fr3, text='Unid:', bg=cor_f, font=font2).grid(row=0, column=1, sticky=W, padx=(4, 0))
        self.cb4 = ttk.Combobox(self.fr3, width=6, state='disable')
        self.cb4.grid(row=1, column=1, sticky='we', padx=(4, 0))
        self.carrega_comb('id', '', 'matserv_un', '', self.cb4)
        self.aj3 = Frame(self.fr3, width=2, bg=cor_f).grid(row=0, column=2, sticky=W)
        self.bt2 = Button(self.fr3, text='Incluir', width=6, font=font2, command=self.editagrup)
        self.bt2.grid(row=0, column=3, rowspan=2, sticky='ns', pady=(4, 0), padx=(4, 0))

        self.ls2 = ttk.Treeview(self.fr3, height=4)
        self.carrega_lista(1, 'vw_matserv_agrup', self.ls2)
        self.ls2.bind('<<TreeviewSelect>>', lambda event: self.carrega_lista(2, 'vw_matserv_agrup_ms', self.ls3))
        self.ls2.grid(row=2, column=0, columnspan=4, sticky='we', padx=(4, 0), pady=(4, 0))

        self.ls3 = ttk.Treeview(self.fr3, height=6)
        self.carrega_lista(1, 'vw_matserv_agrup_ms', self.ls3)
        self.ls3.grid(row=3, column=0, columnspan=4, sticky='we', padx=(4, 0), pady=(4, 0))

        self.fr3.grid(row=0, column=0, ipadx=2, ipady=2, pady=(4, 0), sticky=W)

        self.fr4 = Frame(self.fr1a, borderwidth=1, relief='ridge', bg=cor_f)
        self.lb7 = Label(self.fr4, text='Atividade:', bg=cor_f, font=font2).grid(row=0, column=0, sticky=W, padx=(4, 0))

        self.cb5 = ttk.Combobox(self.fr4, width=30, state='readonly')
        self.cb5.grid(row=1, column=0, padx=(4, 0), sticky=W)
        self.carrega_comb('id', 'ds', 'vw_contratos_clientes', '', self.cb5)

        self.lb8 = Label(self.fr4, text='Fornecimento:', bg=cor_f, font=font2).grid(row=0, column=1, sticky=W,
                                                                                    padx=(4, 0))
        self.cb6 = ttk.Combobox(self.fr4, width=30, state='readonly')
        self.cb6.grid(row=1, column=1, padx=(4, 0), sticky=W)
        self.carrega_comb('id', 'ds', 'vw_contratos', '', self.cb6)
        self.aj2 = Frame(self.fr4, width=49, bg=cor_f).grid(row=1, column=2, sticky=W)
        self.bt3 = Button(self.fr4, text='Incluir', font=font2)
        self.bt3.grid(row=1, column=3, rowspan=2, sticky='ns', pady=(4, 0), padx=(4, 0))
        self.lb9 = Label(self.fr4, text='Agrupamento:', bg=cor_f, font=font2).grid(row=2, column=0, sticky=W,
                                                                                   padx=(4, 0))
        self.en6 = Entry(self.fr4, width=35, font=font2)
        self.en6.grid(row=3, column=0, columnspan=2, sticky='we', padx=(4, 0))
        self.cb7 = ttk.Combobox(self.fr4, width=30, state='readonly')
        self.cb7.grid(row=4, column=0, columnspan=2, padx=(4, 0), sticky='we')
        self.aj4 = Frame(self.fr4, width=10, height=8, bg=cor_f).grid(row=5, column=0, sticky=W)
        self.ls4 = ttk.Treeview(self.fr4, height=8)
        self.ls4.grid(row=6, column=0, columnspan=4, sticky='nswe', padx=(4, 0), pady=(4, 0))
        self.fr4.grid(row=0, column=1, ipadx=2, ipady=2, padx=(4, 0), pady=(4, 0), sticky='nswe')
        self.fr1a.grid(row=1, column=0, sticky=W)
        self.fr1.grid(padx=10, pady=10)

    def canagrup(self, event=''):
        self.cb4.set('')
        self.cb4.configure(state='disable')
        self.bt2.configure(text='Incluir')

    def editagrup(self):
        if self.bt2['text'] == 'Incluir':
            self.cb4.configure(state='readonly')
            self.bt2.configure(text='Salvar')
        elif self.bt2['text'] == 'Salvar':
            if self.en5.get() == '' or self.cb4.get() == '':
                messagebox.showinfo('Cadastro de material', 'Não é possível salvar um agrupamento sem nome ou unidade!')
            else:
                a = cnx()
                b = a.sqlcmd('call prcInsereMSAgrup("' + self.en5.get() + ' [' + self.cb4.get() + ']")')
                if b == 0:
                    messagebox.showinfo('Cadastro de material',
                                        'Agrupamento ' + self.en5.get() + ' [' + self.cb4.get() + '] já cadastrado!')
                else:
                    self.en5.delete(0, END)
                    self.canagrup()

    def editms(self):
        if self.bt1['text'] == 'Editar':
            self.en2.configure(state='normal')
            self.cb1.configure(state='readonly')
            self.en3.configure(state='normal')
            self.cb2.configure(state='readonly')
            self.en4.configure(state='normal')
            self.cb3.configure(state='readonly')
            self.bt1.configure(text='Salvar')
        elif self.bt1['text'] == 'Salvar':
            self.en2.configure(state='disable')
            self.cb1.configure(state='disable')
            self.en3.configure(state='disable')
            self.cb2.configure(state='disable')
            self.en4.configure(state='disable')
            self.cb3.configure(state='disable')
            self.bt1.configure(text='Editar')
            if str(self.ls1.item(self.ls1.focus())['values'][11]) + str(
                    self.ls1.item(self.ls1.focus())['values'][9]) + str(
                self.ls1.item(self.ls1.focus())['values'][10]) != self.cb1.get()[
                                                                  :self.cb1.get().find('-') - 1] + self.cb2.get()[
                                                                                                   :self.cb2.get().find(
                                                                                                       '-') - 1] + self.cb3.get()[
                                                                                                                   :self.cb3.get().find(
                                                                                                                       '-') - 1]:
                a = cnx()
                b = a.sqlcmd('update matserv set ss=2, id_msg=' + self.cb2.get()[:self.cb2.get().find(
                    '-') - 1] + ', id_msa=' + self.cb3.get()[
                                              :self.cb3.get().find('-') - 1] + ', id_msf=' + self.cb1.get()[
                                                                                             :self.cb1.get().find(
                                                                                                 '-') - 1] + ' where id=' + str(
                    self.ls1.item(self.ls1.focus())['values'][0]))
                itmx = int(self.ls1.selection()[0])
                self.carrega_ls1('vw_matserv', self.ls1, self.ckvar.get(), 'pesq', self.en1.get())
                self.ls1.selection_set(itmx)
                self.ls1.focus(itmx)

    def en6_mask(self, action, value_if_allowed):
        if action != '1':
            return True
        try:
            return value_if_allowed.isnumeric()
        except ValueError:
            return False

    def press_bt2(self):
        print(self.cb2.get()[:self.cb2.get().find('-') - 1])

    def press_bt1(self):
        if self.bt1['text'] == 'Salvar':
            if self.ls2.exists(1):
                print('Salvar')
            else:
                messagebox.showinfo('Solicitação de material', 'Não é possível salvar uma solciitação sem itens!')
        else:
            print('Novo')

    def get_ls1(self, event=''):
        if self.bt1['text'] == 'Salvar':
            self.bt1.configure(text='Editar')
            self.en2.configure(state='disable')
            self.cb1.configure(state='disable')
            self.en3.configure(state='disable')
            self.cb2.configure(state='disable')
            self.en4.configure(state='disable')
            self.cb3.configure(state='disable')
            self.bt1.configure(text='Editar')
        elif self.bt1['text'] == 'Editar':
            self.bt1.configure(state='normal')

        self.cb1.set(self.ls1.item(self.ls1.focus())['values'][6])
        self.cb2.set(self.ls1.item(self.ls1.focus())['values'][5])
        self.cb3.set(self.ls1.item(self.ls1.focus())['values'][4])

    def carrega_comb(self, cd, ds, tab, filtro, controle):
        a = cnx()
        if filtro == '':
            b = a.sqlcmb(cd, ds, tab)
        else:
            b = a.sqlcmb(cd, ds, tab, filtro.get())
        controle['values'] = b

    def carrega_ls1(self, tab, controle, check, filtro='', valor=0):
        nomes = 'SELECT col, tam, anc FROM listab WHERE tab = "' + tab + '"'
        if filtro == '':
            if check == True:
                itens = 'select * from ' + tab + ' where ss = 1'
            else:
                itens = 'select * from ' + tab
        else:
            if check == True:
                itens = 'select * from ' + tab + ' where ss = 1 and ' + filtro + ' like "%' + str(valor) + '%"'
            else:
                itens = 'select * from ' + tab + ' where ' + filtro + ' like "%' + str(valor) + '%"'
        a = cnx()
        b = a.sqllist(nomes)
        qt = 1
        vis = []
        for i in b:
            if b[qt][1] != 0:
                vis.append(qt)
            qt += 1
        controle.configure(columns=list(b.keys()), displaycolumns=vis, show='headings')
        qt = 1
        for i in b:
            controle.heading(qt, text=b[qt][0], anchor=b[qt][2])
            controle.column(qt, stretch=False, minwidth=0, width=b[qt][1], anchor=b[qt][2])
            qt += 1
        a = cnx()
        c = a.sqlquery(itens)
        if controle.exists(1):
            for i in controle.get_children():
                controle.delete(i)
        idx = 1
        for row in c:
            controle.insert('', END, iid=idx, values=row, )  # tag='a')
            idx += 1
        # controle.tag_configure('a', font=font4)

    def tvhead(self, tab, controle):
        nomes = 'SELECT col, tam, anc FROM listab WHERE tab = "' + tab + '"'
        a = cnx()
        b = a.sqllist(nomes)
        qt = 1
        vis = []
        for i in b:
            if b[qt][1] != 0:
                vis.append(qt)
            qt += 1
        controle.configure(columns=list(b.keys()), displaycolumns=vis, selectmode='browse', show='headings')
        qt = 1
        for i in b:
            controle.heading(qt, text=b[qt][0], anchor=b[qt][2])
            controle.column(qt, stretch=False, minwidth=0, width=b[qt][1], anchor=b[qt][2])
            qt += 1

    def carrega_lista(self, tp, tab, controle, filtro='', valor=0):  # tp: 0=cabeçalho e itens / 1=cabeçalho / 2=itens
        if tp in (0, 1):
            try:
                test = controle.heading(1)
            except:
                self.tvhead(tab, controle)
        if tp in (0, 2):
            if filtro == '':
                itens = 'select * from ' + tab
            else:
                itens = 'select * from ' + tab + ' where ' + filtro + ' like "%' + str(valor) + '%"'
            a = cnx()
            c = a.sqlquery(itens)
            if controle.exists(1):
                for i in controle.get_children():
                    controle.delete(i)
            idx = 1
            for row in c:
                controle.insert('', END, iid=idx, values=row, )
                idx += 1

    def carrega_ls3(self, event=''):
        tab = 'vw_matserv_agrup_ms'
        controle = self.ls2
        filtro = 'id_msa'
        valor = self.ls3.item(self.ls3.focus())['values'][0]
        if filtro == '':
            itens = 'select * from ' + tab
        else:
            itens = 'select * from ' + tab + ' where ' + filtro + ' = ' + str(valor)
        a = cnx()
        c = a.sqlquery(itens)
        if controle.exists(1):
            for i in controle.get_children():
                controle.delete(i)
        idx = 1
        for row in c:
            controle.insert('', END, iid=idx, values=row, )
            idx += 1

    def carrega_cb1(self, event):
        a = cnx()
        b = a.sqlcmb('cd', 'nm', 'colab', self.en1.get())
        self.cb1['values'] = b
        self.en3.delete(0, END)
        self.en3.insert(0, datetime.now().strftime("%d/%m/%Y %H:%M"))

    def carrega_cb3(self, event):
        a = cnx()
        b = a.sqlcmb('cd', 'nm', 'colab', self.en4.get())
        self.cb3['values'] = b

    def carrega_cb4(self, event):
        a = cnx()
        b = a.sqlcmb('id', 'ds', 'vw_msa_ativos', self.en5.get())
        self.cb4['values'] = b

    def valida_en3(self, event):
        try:
            trat = datetime.strptime(self.en3.get(), "%d/%m/%Y %H:%M")
            self.en3.delete(0, END)
            self.en3.insert(0, trat.strftime("%d/%m/%Y %H:%M"))
        except:
            messagebox.showinfo('Formato', 'Data/Hora inválidos!')
            self.en3.focus_force()

    def carrega_cb2(self, event):
        a = cnx()
        b = a.sqlcmb('id', 'ds', 'solmat_prioridade')
        self.cb2['values'] = b
        self.cb2.current(0)

    def open_file(self):
        arq = filedialog.askopenfilename(initialdir='//Servdatatmt/dados_rmg/GER_DADOS/PLANEJAMENTO E CONTROLE/ANEXOS',
                                         title='Selecione o anexo', filetypes=(('Arquivos msg', '.msg'),))
        self.en2.configure(state='normal', justify=RIGHT)
        self.en2.insert(END, arq)
        self.en2.configure(state='readonly')

class atvd2():
    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 960, 660, 'Atividades Operacionais', vNm_r)
        sf.frm = frm(master, 0, 0)
        sf.fr1 = fr(sf.frm, 0, 0)
        lb(sf.fr1, 0, 0, 'Coordenação')
        sf.cb1 = cb(sf.fr1, 0, 1, 25, sticky='we')
        lb(sf.fr1, 1, 0, 'Supervisão')
        sf.cb2 = cb(sf.fr1, 1, 1, 25, sticky='we')
        sf.fr1a = fr(sf.fr1, 2, 0, cs=2)
        sf.ck1 = ck(sf.fr1a, 0, 0, 'Backlog')
        sf.ck2 = ck(sf.fr1a, 0, 1, 'Execução')
        sf.ck3 = ck(sf.fr1a, 0, 2, 'Pendencia')
        sf.ck4 = ck(sf.fr1a, 0, 3, 'Agendado')
        lb(sf.fr1, 3, 0, 'Localizar') 
        sf.en1 = en(sf.fr1, 3, 1, sticky='we')
        sf.fr1b = fr(sf.fr1, 0, 2, width=390)
        sf.bt1 = bt(sf.fr1, 0, 3, 'Novo', sf.prsbt1, 10)
        sf.bt2 = bt(sf.fr1, 1, 3, 'Editar', sf.prsbt2, 10)
        #sf.bt3 = bt(sf.fr1, 0, 4, 'Agendar', sf.prsbt3, 9)
        #sf.bt4 = bt(sf.fr1, 1, 4, 'Executar', sf.prsbt4, 9)
        #sf.bt5 = bt(sf.fr1, 2, 4, 'Pendenciar', sf.prsbt5, 9)
        #sf.bt6 = bt(sf.fr1, 3, 4, 'Finalizar', sf.prsbt6, 9)
        sf.bt7 = bt(sf.fr1, 2, 3, 'Continuar',  sf.prsbt7, 10)
        sf.bt8 = bt(sf.fr1, 3, 3, 'Responsável',sf.prsbt8, 10)
        sf.bt9 = bt(sf.fr1, 0, 4, 'Ação', lambda: sf.prsbt9(getpils(sf.ls1, 13)), 9)
        sf.ls1 = ls(sf.fr1, 4, 0, 24, [("<Double-1>", sf.dblls1)], 'we', cs=5)
        carrega_lista(0, 'vw_ativoper_p', sf.ls1)

    def dblls1(sf, ev):
        sf.popup = Toplevel(sf.master)
        win(sf.popup, sf.master, 960, 460, 'Histórico Status')
        sf.f = frm(sf.popup, 0, 0)
        sf.l1 = ls(sf.f, 0, 0, 10)
        carrega_lista(1, 'vw_ativoper_hist', sf.l1)
        carrega_lista(3, 'select * from vw_ativoper_hist where f = ' + getpls(sf.ls1, 0), sf.l1)

    def prsbt1(sf):
        sf.popup = Toplevel(sf.master)
        win(sf.popup, sf.master, 415, 150, 'Nova Atividade')
        sf.f = frm(sf.popup, 0, 0)
        lb(sf.f, 0, 0, 'Atividade')
        sf.e1 = en(sf.f, 0, 1, 10, [('<FocusOut>', sf.oute1)])
        sf.c1 = cb(sf.f, 0, 2, 25)
        lb(sf.f, 1, 0, 'Referencia')
        sf.e2 = en(sf.f, 1, 1, 20, cs=2)
        lb(sf.f, 2, 0, 'Planta')
        sf.e3 = en(sf.f, 2, 1, 10, [('<FocusOut>', sf.oute3)])
        sf.c2 = cb(sf.f, 2, 2, 25)
        sf.b1 = bt(sf.f, 4, 0, 'Salvar', sf.prsb1, 5, E, cs=3)

    def oute1(sf, ev):
        sf.c1['values'] = ''
        sf.c1['values'] = cnx.sqlcb(cnx(), 'id', 'nm', 'ativoper_cadastros', ' where nm like "%' + sf.e1.get() + '%"') 

    def oute3(sf, ev):
        sf.c2['values'] = ''
        sf.c2['values'] = cnx.sqlcb(cnx(), 'id', 'idx', 'planta', ' where idx like "%' + sf.e3.get() + '%"')    
        
    def prsb1(sf):
        if sf.c1.get() == '' or sf.e2.get() == '' or sf.c2.get() == '':
            messagebox.showinfo('Nova Atividade', 'Nenhum campo pode estar em branco!', parent=sf.popup)
        else:
            cnx.sqlcmd(cnx(), 'insert into ativoper(`or`, ref, id_p, dt) values(' + getpcb(sf.c1, 1) + ', "' + sf.e2.get() + '", ' + getpcb(sf.c2, 1) + ', "' + sf.e4.get() + '")')
            carrega_lista(2, 'vw_ativoper_p', sf.ls1)
            sf.popup.destroy()

    def prsbt2(sf): #Botão Editar
        if sf.ls1.selection():
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 318, 90, 'Editar Atividade')
            sf.f = frm(sf.popup, 0, 0)
            lb(sf.f, 0, 0, 'Selecione:')
            sf.c1 = cb(sf.f, 0, 1, 24, [], 'we', cs=2)
            sf.c1['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'ss_tp', 'where id > 9')
            sf.b2 = bt(sf.f, 1, 1, 'Ok', lambda: sf.prsbt2a(getpcb(sf.c1, 1)), 5, E, cs=3)

    def prsbt2a(sf, op):
        if op != 'NULL':
            sf.popup.destroy()
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 318, 185, 'Editar Atividade')
            sf.f = frm(sf.popup, 0, 0)
            lb(sf.f, 0, 0, 'Atividade:')
            lb(sf.f, 0, 1, getpls(sf.ls1, 1), font=font3)
            lb(sf.f, 1, 0, 'Referencia: ')
            lb(sf.f, 1, 1, getpls(sf.ls1, 4), font=font3)
            lb(sf.f, 2, 0, 'Planta: ')
            lb(sf.f, 2, 1, getpls(sf.ls1, 5), font=font3)
            if op == '10':
                lb(sf.f, 3, 0, 'Responsável')
                sf.e1 = en(sf.f, 3, 1, 23)
                sf.c1 = cb(sf.f, 4, 1, 23)
            elif op == '11':
                lb(sf.f, 3, 0, 'Referência')
                sf.e2 = en(sf.f, 3, 1, 22)
            else:
                if op == '12':
                    lb(sf.f, 3, 0, 'Dt. Início')
                elif op == '13':
                    lb(sf.f, 3, 0, 'Dt. Prazo')
                else:
                    lb(sf.f, 3, 0, 'Dt. Conclusão')
                sf.e3 = en(sf.f, 3, 1, 22,[('<FocusOut>',sf.oute6)])
            sf.b4 = bt(sf.f, 5, 0, 'Salvar',lambda: sf.prsb6(op), 5, E, cs=2)
        else:
            messagebox.showinfo('Editar Atividade', 'Nenhum tipo de alteração selecionado!', parent=sf.popup)

    def prsb6(sf, op):
        if op >='12':    
            try:
                trat = datetime.strptime(sf.e3.get(), '%d/%m/%Y %H:%M')
                sf.e3.delete(0, END)
                sf.e3.insert(0, trat.strftime('%d/%m/%Y %H:%M'))
            except:
                if sf.e3.get() != '':
                    messagebox.showinfo('Formato', 'Formato de data/hora invalido EX:"01/01/2000 12:00"!!', parent=sf.popup)
                    sf.e3.focus_force()
                else:
                    pass

        elif op == '10':
              
              sf.e3 = en(sf.f, 2, 1, 10, [('<FocusOut>', sf.oute3)])
              sf.c2 = cb(sf.f, 2, 2, 25) 
        
        else:
            pass           

    def oute6(sf):
            pass
  
    def prsbt3(sf):
        if sf.ls1.selection():
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 338, 150, 'Agendar Atividade')
            sf.f = frm(sf.popup, 0, 0)
            lb(sf.f, 0, 0, 'Atividade:')
            lb(sf.f, 0, 1, getpls(sf.ls1, 1), font=font3)
            lb(sf.f, 1, 0, 'Referencia: ')
            lb(sf.f, 1, 1, getpls(sf.ls1, 4), font=font3)
            lb(sf.f, 2, 0, 'Planta: ')
            lb(sf.f, 2, 1, getpls(sf.ls1, 5), font=font3)
            lb(sf.f, 3, 0, 'Data Agendamento: ')
            sf.e5 = en(sf.f, 3, 1, 20, cs=2)
            sf.b3 = bt(sf.f, 4, 0, 'Salvar', sf.prsb3, 5, E, cs=3)

    def prsb3(sf):
        if sf.e5.get() == '': 
            messagebox.showinfo('Agendar Atividade', 'O campo data agendamento não pode estar em branco!',parent=sf.popup)
        else:
            if ifendt(sf.e5):
                cnx.sqlcmd(cnx(), 'update ativoper set dt = str_to_date("' + sf.e5.get() + '", "%d/%m/%Y %H:%i"), tp = 3 where id = ' + getpls(sf.ls1, 0))
                carrega_lista(2, 'vw_ativoper_p', sf.ls1)
                sf.popup.destroy()
            else:
                messagebox.showinfo('Formato', 'Formato de data/hora invalido EX:"01/01/2000 12:00"!!',parent=sf.popup)
    
    def prsbt4(sf):
        if sf.ls1.selection():
            cnx.sqlcmd(cnx(), 'update ativoper set tp = 9, ssp = NULL where id = ' + getpls(sf.ls1, 0))
            carrega_lista(2, 'vw_ativoper_p', sf.ls1)
            sf.popup.destroy()
        else:
            pass

    def prsbt5(sf):
        if sf.ls1.selection():
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 308, 150, 'Pendenciar Atividade')
            sf.f = frm(sf.popup, 0, 0)
            lb(sf.f, 0, 0, 'Atividade:')
            lb(sf.f, 0, 1, getpls(sf.ls1, 1), font=font3)
            lb(sf.f, 1, 0, 'Referencia: ')
            lb(sf.f, 1, 1, getpls(sf.ls1, 4), font=font3)
            lb(sf.f, 2, 0, 'Planta: ')
            lb(sf.f, 2, 1, getpls(sf.ls1, 5), font=font3)
            lb(sf.f, 3, 0, 'Pendência: ')
            sf.c5 = cb(sf.f, 3, 1, 20)
            sf.c5['values'] = cnx.sqlcb2(cnx(), 'id', 'nm', 'vw_ativoper_pdv', 'where `or` = ' + getpls(sf.ls1, 14))
            sf.b4 = bt(sf.f, 4, 0, 'Salvar', sf.prsb5, 5, E, cs=3)
    
    def prsb5(sf):
        if sf.c5.get() == '': 
            messagebox.showinfo('Pendencia Atividade', 'O campo pendência não pode estar em branco!',parent=sf.popup)
        else:
            cnx.sqlcmd(cnx(), 'update ativoper set ssp = ' + getpcb(sf.c5, 1) + ', tp=2 where id = ' + getpls(sf.ls1, 0))
            carrega_lista(2, 'vw_ativoper_p', sf.ls1)
            sf.popup.destroy()

    def prsbt6(sf):
        if sf.ls1.selection():
            cnx.sqlcmd(cnx(), 'update ativoper set tp = 0, ssp = NULL where id = ' + getpls(sf.ls1, 0))
            carrega_lista(2, 'vw_ativoper_p', sf.ls1)
            sf.popup.destroy()
        else:
            pass
    
    def prsbt7(sf):  
        pass     

    def prsbt8(sf):  
        pass       

    def prsbt9(sf, tp):  
        if tp in (3,5):
            if sf.ls1.selection():
                if tp == 3:
                    nome = 'Agendar Atividade'
                elif tp == 5:
                    nome = 'Despachar Atividade'
                sf.popup = Toplevel(sf.master)
                win(sf.popup, sf.master, 415, 150, nome)
                sf.f = frm(sf.popup, 0, 0)
            if tp==3:
                    lb(sf.f, 0, 0, 'Atividade:')
                    lb(sf.f, 0, 1, getpls(sf.ls1, 1), font=font3)
                    lb(sf.f, 1, 0, 'Referencia: ')
                    lb(sf.f, 1, 1, getpls(sf.ls1, 4), font=font3)
                    lb(sf.f, 2, 0, 'Planta: ')
                    lb(sf.f, 2, 1, getpls(sf.ls1, 5), font=font3)
                    lb(sf.f, 3, 0, 'Data Agendamento: ')
                    sf.e5 = en(sf.f, 3, 1, 20, cs=2)
                    sf.b3 = bt(sf.f, 4, 0, 'Salvar', sf.prsb3, 5, E, cs=3)
            elif tp==5:
                    lb(sf.f, 0, 0, 'Atividade:')
                    lb(sf.f, 0, 1, getpls(sf.ls1, 1), font=font3)
                    lb(sf.f, 1, 0, 'Referencia: ')
                    lb(sf.f, 1, 1, getpls(sf.ls1, 4), font=font3)
                    lb(sf.f, 2, 0, 'Planta: ')
                    lb(sf.f, 2, 1, getpls(sf.ls1, 5), font=font3)
                    lb(sf.f, 3, 0, 'Resposavel: ')
                    sf.e1 = en(sf.f, 3, 1, 10)
                    sf.c1 = cb(sf.f, 3, 2, 25,[], 'we')
        else:
            messagebox.showinfo('Ação', 'Ação sem condição!')             

class b2bp():
    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 960, 660, 'Pendência Material B2B')
        sf.frm = frm(master, 0, 0)
        sf.fr1 = fr(sf.frm, 0, 0)
        lb(sf.fr1, 0, 0, 'Localizar: ')
        sf.en1 = en(sf.fr1, 0, 1)
        sf.fr2 = fr(sf.frm, 0, 1, E)
        sf.bt1 = bt(sf.fr2, 0, 0, 'Tratar Mat.', sf.prsbt1, 15, E)
        sf.fr3 = fr(sf.frm, 1, 0, cs=2)
        sf.ls1 = ls(sf.fr3, 0, 0, 13, [], 'we')
        carrega_lista(0,'vw_b2b_mat_p', sf.ls1, sel=2)
        sf.fr4 = fr(sf.frm, 2, 0, cs=2)
        sf.fr5 = fr(sf.fr4, 0, 0)
        lb(sf.fr5, 0, 0, 'Compras/Transferências', W)
        sf.bt2 = bt(sf.fr5, 0, 1, 'Entregue', sf.prsbt2, 10, E)
        sf.ls2 = ls(sf.fr5, 1, 0, 12, [('<<TreeviewSelect>>', sf.clkls2)], 'we', cs=2)
        carrega_lista(0,'vw_b2b_mat_t', sf.ls2)
        sf.fr6 = fr(sf.fr4, 0, 1)
        lb(sf.fr6, 0, 0, 'Detalhe Compras/Transferências Tratadas', W)
        sf.ls3 = ls(sf.fr6, 1, 0, 12, [], 'we')
        carrega_lista(1,'vw_b2b_mat_m',sf.ls3)

    def prsbt2(sf):
        if len(sf.ls3.selection()) > 0:
            r = msgb(4, 'Material recebido', f'Confirma o recebimento do material {getpls(sf.ls2, 0)} - {getpls(sf.ls3, 1)}-{getpls(sf.ls3, 2)} - Nº: {getpls(sf.ls2, 1)}', sf.master)
            if r:
                cnx.sqlcmd(cnx(), f'update b2b_mat set reg = {str(vId)}, ss = 4, ssc = "BHE", t = NULL where t = {getpls(sf.ls2, 3)} and cd = "{getpls(sf.ls3, 1)}"')
                sf.clkls2(1)
                if not cnx.q(cnx(), f'select * from b2b_mat where t ={getpls(sf.ls2, 3)}'):
                    cnx.sqlcmd(cnx(), f'update b2b_mat_transito set ss = 2 where id = {getpls(sf.ls2, 3)}')
                    chrls(sf.ls2, 'select * from vw_b2b_mat_t')
                    clrls(sf.ls3)
        else:
            if len(sf.ls2.selection()) > 0:
                r = msgb(4, 'Material recebido', f'Confirma o recebimento dos materiais {getpls(sf.ls2, 0)} - Nº: {getpls(sf.ls2, 1)}', sf.master)
                if r:
                    cnx.sqlcmd(cnx(), f'update b2b_mat set reg = {str(vId)}, ss = 4, ssc = "BHE", t = NULL where t = {getpls(sf.ls2, 3)}')
                    cnx.sqlcmd(cnx(), f'update b2b_mat_transito set ss = 2 where id = {getpls(sf.ls2, 3)}')
                    chrls(sf.ls2, 'select * from vw_b2b_mat_t')
                    clrls(sf.ls3)
            else:
                msgb(3, 'Material recebido', 'Nenhuma Compra/Transferência ou material selecionados!', sf.master)

    def clkls2(sf, e):
        chrls(sf.ls3, f'select * from vw_b2b_mat_m where t = {getpls(sf.ls2, 3)}')

    def prsbt1(sf):
        a = getptls(sf.ls1, (0,))
        if a[0]:
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 322, 128, 'Tratar Pendência')
            sf.f = frm(sf.popup, 0, 0)
            lb(sf.f, 0, 0, 'Fornec.: ')
            sf.e1 = en(sf.f, 0, 1, 27, state='readonly')
            if a[1] == 'TLM':
                insen(sf.e1, f'1 - {a[1]}')
            else:
                insen(sf.e1, f'2 - {a[1]}')
            lb(sf.f, 1, 0, 'Número: ')
            sf.e2 = en(sf.f, 1, 1, 27, [('<FocusOut>', sf.oute2)])
            lb(sf.f, 2, 0, 'Previsão: ')
            sf.e3 = en(sf.f, 2, 1, 27, [('<FocusOut>', sf.oute3)])
            sf.b1 = bt(sf.f, 3, 1, 'Salvar', sf.prsb1, 5, E, cs=3)
        else:
            msgb(3, 'Tratar pendencia', 'Nenhum material selecionado ou materiais selecionados contém Fornecedores diferentes!', sf.master)
    
    def prsb1(sf):
        a = cnx.sqlcmdid(cnx(), f'call prcInsBtbT({getven(sf.e3)}, {getven(sf.e1, 2)[0]}, {getven(sf.e2, 2)})')
        cnx.sqlcmd(cnx(), f'update b2b_mat set t = {a} , dtp = str_to_date({getven(sf.e3)}, "%d/%m/%Y") where ss = 3 and cd in {getlpls(sf.ls1, 1, 2)}')
        chrls(sf.ls1, 'select * from vw_b2b_mat_p')
        chrls(sf.ls2, 'select * from vw_b2b_mat_t')
        clrls(sf.ls3)
        sf.popup.destroy()

    def oute2(sf, e):
        isnr(sf.e2, sf.popup)

    def oute3(sf, e):
        isdthr(1, sf.e3, sf.popup)

class b2b():
    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 960, 660, 'Material B2B')
        sf.frm = frm(master, 0, 0)
        sf.fr1 = fr(sf.frm, 0, 0)
        lb(sf.fr1, 0, 0, 'Localizar: ')
        sf.en1 = en(sf.fr1, 0, 1)
        sf.fr2 = fr(sf.frm, 0, 1, E)
        sf.bt2 = bt(sf.fr2, 0, 0, 'Atualizar', sf.atlzls1, 15, E)
        sf.fr3 = fr(sf.frm, 1, 0, cs=2)
        sf.ls1 = ls(sf.fr3, 0, 0, 7, [('<<TreeviewSelect>>', sf.prsls1)], 'we')
        carrega_lista(1,'vw_b2b_base', sf.ls1)
        sf.fr4 = fr(sf.frm, 2, 0)
        lb(sf.fr4, 0, 0, 'Resposabilidade própria', W)
        sf.fr5 = fr(sf.frm, 2, 1, E)
        sf.bt1 = bt(sf.fr5, 0, 0, 'Tratar Mat.', sf.prsbt1, 15, E)
        sf.fr6 = fr(sf.frm, 3, 0, cs=2)
        sf.ls2 = ls(sf.fr6, 0, 0, 8, [], 'we')
        carrega_lista(1,'vw_b2b_mat', sf.ls2, sel=2)
        lb(sf.fr6, 1, 0, 'Resposabilidade de terceiros', W)
        sf.ls3 = ls(sf.fr6, 2, 0, 8, [], 'we')
        carrega_lista(1,'vw_b2b_mat',sf.ls3)
        sf.atlzls1()

    def prsls1(sf, ev):
        carrega_lista(3,'select * from vw_b2b_mat where idp = ' + str(vPs) + ' and ac = ' + getpls(sf.ls1, 0), sf.ls2)
        carrega_lista(3,'select * from vw_b2b_mat where idp <> ' + str(vPs) + ' and ac = ' + getpls(sf.ls1, 0), sf.ls3)

    def prsbt1(sf): #Botão Editar
        a = getptls(sf.ls2, (12, 2))
        if a[0] and a[1] < 7:
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 318, 200, 'Tratar Material')
            sf.f = frm(sf.popup, 0, 0)
            lb(sf.f, 0, 0, 'Selecione:')
            sf.c1 = cb(sf.f, 0, 1, 24, [('<<ComboboxSelected>>', sf.prsc1)])
            b = cnx.sqllsts(cnx(), 'select p from b2b_ss where id = ' + str(a[1]))
            sf.c1['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'b2b_ss', 'where id in ' + b)
            lb(sf.f, 1, 0, 'DE: ')
            sf.c2 = cb(sf.f, 1, 1, 15, state='disable')
            lb(sf.f, 2, 0, 'PARA: ')
            sf.c3 = cb(sf.f, 2, 1, 15, state='disable')
            lb(sf.f, 3, 0, 'Cod.Rast: ')
            sf.e1 = en(sf.f, 3, 1, 17, state='disable')
            lb(sf.f, 4, 0, 'Dt.Prazo: ')
            sf.e2 = en(sf.f, 4, 1, 17, state='disable', cs=2)
            sf.b1 = bt(sf.f, 5, 1, 'Salvar', sf.prsb1, 5, E, cs=3)
        else:
            msgb(3, 'Tratar material', 'Nenhum material selecionado, materiais selecionados contém Status ou Fornecedores diferentes ou materiais já entregues!', sf.master)

    def atlzcb(sf, op=0):
        if op == 0:
            sf.c2.set('')
            sf.c3.set('')
            sf.c2.configure(state='disable')
        else:
            sf.c2.set(getpls(sf.ls2, 6))
            sf.c3.set(getpls(sf.ls1, 1))

    def prsc1(sf, op):
        a = getpcb(sf.c1)
        if a in (2, 3, 7):
            sf.e1.configure(state='disable')
            sf.e2.configure(state='disable')
            sf.atlzcb()
        elif a == 5:
            sf.e1.configure(state='disable')
            sf.e2.configure(state='normal')
            sf.atlzcb(1)
        elif a == 6:
            sf.e1.configure(state='normal')
            sf.e2.configure(state='normal')
            sf.atlzcb()
        else:
            sf.c2.configure(state='normal')
            sf.c2['values'] = cnx.sqlcb3(cnx(), 'gram', 'b2b_mat_resp', 'where gram <> "CTRL"')
    
    def prsb1(sf):
        c = False
        a = getpcb(sf.c1)
        if a in (5, 6):
            if isdthr(1, sf.e2, sf.popup):
                if a == 5:
                    if sf.c2.get() != '' and sf.c3.get() != '' and sf.e2.get() != '':
                        vSsc = sf.c2.get() + '/' + sf.c3.get()
                        c = True
                elif a == 6:
                    if sf.e1.get() != '' and sf.e2.get() != '':
                        vSsc = sf.e1.get()
                        c = True
                if c:
                    cnx.sqlcmd(cnx(), f'update b2b_mat set reg = {str(vId)}, dtp = str_to_date({getven(sf.e2)}, "%d/%m/%Y"), ssc = "{vSsc}", ss = {getpcb(sf.c1, 1)} where id in {getlpls(sf.ls2, 0)}')
                    sf.atlzls1()
                    sf.popup.destroy()

                else:
                    msgb(1, 'Tratar Material', 'Nenhum campo pode estar em branco!', sf.popup)
        elif a == 4:
            if sf.c2.get() != '':
                cnx.sqlcmd(cnx(), f'update b2b_mat set reg = {str(vId)}, ss = {getpcb(sf.c1, 1)}, ssc = {getven(sf.c2)} where id in {getlpls(sf.ls2, 0)}')
                sf.atlzls1()
                sf.popup.destroy()
            else:
                msgb(1, 'Tratar Material', 'Nenhum campo pode estar em branco!', sf.popup)
        else:
            cnx.sqlcmd(cnx(), f'update b2b_mat set reg = {str(vId)}, ss = {getpcb(sf.c1, 1)} where id in {getlpls(sf.ls2, 0)}')
            sf.atlzls1()
            sf.popup.destroy()
    
    def atlzls1(sf):
        clrls(sf.ls2)
        try:
            n = sf.ls1.focus()
        except:
            pass
        if vPs in cnx.sqllist1(cnx(), 'select idp from b2b_mat_resp'):
            carrega_lista(3,'select * from vw_b2b_base where idp = ' + str(vPs) + ' and flt like "%' + sf.en1.get() + '%"', sf.ls1)
        else:
            carrega_lista(3,'select * from vw_b2b_base where flt like "%' + sf.en1.get() + '%"', sf.ls1)
        try:
            if int(n) > 0:
                selidls(sf.ls1, n)
        except:
            pass

class cdvn():
    def __init__(self, master, root):
        self.cb1dict = {}
        self.cb2dict = {}
        self.cb3dict = {}
        self.lb4var = StringVar()
        self.lb6var = StringVar()
        self.style = ttk.Style()
        self.style.configure('Treeview.Heading', font=font3)
        self.master = master
        self.master['bg'] = cor_f
        l_tela = self.master.winfo_screenwidth()
        a_tela = self.master.winfo_screenheight()
        l_ws = 960  # self.master.winfo_width()
        a_ws = 660  # self.master.winfo_height()
        posx = l_tela / 2 - l_ws / 2
        posy = a_tela / 2 - a_ws / 1.85
        self.master.resizable(width=0, height=0)
        self.master.transient(root)
        self.master.focus_force()
        self.master.grab_set()
        self.master.geometry("%dx%d+%d+%d" % (l_ws, a_ws, posx, posy))
        self.master.iconphoto(False, tk.PhotoImage(file=icon))
        self.master.title('Cadastro e vínculo de Instrumentais para ' + vNm_r + ' | lvflwX ' + vVer1)

        self.fr1 = Frame(self.master, bg=cor_f)
        self.fr2 = Frame(self.fr1, borderwidth=1, relief='ridge', bg=cor_f)
        self.fr2a = Frame(self.fr2, bg=cor_f)
        self.lb1 = Label(self.fr2a, text='Tipo:', bg=cor_f, font=font2).grid(row=0, column=0, sticky=W, padx=(4, 0))
        self.cb1 = ttk.Combobox(self.fr2a, state='readonly', width=21)
        self.cb1['values'] = cnx.sqlcb(cnx(), 'id', 'ds', 'instrumental_tipo')
        self.cb1dict = cnx.sqldict(cnx(), 'SELECT * FROM instrumental_tipo', 3)
        self.cb1.bind('<<ComboboxSelected>>', lambda event: self.selcb1())
        self.cb1.grid(row=1, column=0, sticky='we', padx=(4, 0))
        self.lb2 = Label(self.fr2a, text='Subtipo:', bg=cor_f, font=font2).grid(row=0, column=1, sticky=W, padx=(4, 0))
        self.cb2 = ttk.Combobox(self.fr2a, state='readonly', width=21)
        self.cb2.bind('<<ComboboxSelected>>', lambda event: self.selcb2())
        self.cb2.grid(row=1, column=1, sticky='we', padx=(4, 0))
        self.lb3 = Label(self.fr2a, text='Origem:', bg=cor_f, font=font2).grid(row=0, column=2, sticky=W, padx=(4, 0))
        self.cb3 = ttk.Combobox(self.fr2a, state='readonly', width=21)
        self.carrega_comb('id', 'ds', 'instrumental_origem', self.cb3)
        self.cb3.bind('<<ComboboxSelected>>', lambda event: self.selcb3())
        self.cb3.grid(row=1, column=2, sticky='we', padx=(4, 0))
        self.lb4 = Label(self.fr2a, bg=cor_f, textvariable=self.lb4var, font=font2).grid(row=0, column=3, sticky=W,
                                                                                         padx=(4, 0))
        self.en1 = Entry(self.fr2a, width=20, font=font2)
        self.en1.bind('<FocusOut>', lambda event: self.valen1())
        self.en1.grid(row=1, column=3, sticky=W, padx=(4, 0))
        self.lb5 = Label(self.fr2a, text='Cor:', bg=cor_f, font=font2).grid(row=0, column=4, sticky=W, padx=(4, 0))
        self.cb4 = ttk.Combobox(self.fr2a, state='disable', width=15)
        self.cb4.set('0 - Não se aplica')
        self.cb4.grid(row=1, column=4, sticky='we', padx=(4, 0))
        self.lb6 = Label(self.fr2a, bg=cor_f, textvariable=self.lb6var, font=font2).grid(row=0, column=5, sticky=W,
                                                                                         padx=(4, 0))
        self.en2 = Entry(self.fr2a, width=16, font=font2, justify=RIGHT)
        self.en2.insert(0, '0 - Não se aplica')
        self.en2.configure(state='disable')
        self.en2.bind('<FocusOut>', lambda event: self.valen2())
        self.en2.grid(row=1, column=5, sticky=W, padx=(4, 0))
        self.fr2a.grid(row=0, column=0, sticky=W)
        self.fr2b = Frame(self.fr2, bg=cor_f)

        self.lb7 = Label(self.fr2b, text='Modelo:', bg=cor_f, font=font2).grid(row=0, column=0, sticky=W, padx=(4, 0))
        self.en3 = Entry(self.fr2b, width=35, font=font2, state='disable')
        self.en3.bind('<Tab>', lambda event: self.taben3())
        self.en3.grid(row=1, column=0, sticky=W, padx=(4, 0))
        self.cb5 = ttk.Combobox(self.fr2b, state='disable')
        self.cb5.set('0 - Não se aplica')
        self.cb5.grid(row=2, column=0, sticky='we', padx=(4, 0))

        self.lb8 = Label(self.fr2b, text='Contrato:', bg=cor_f, font=font2).grid(row=0, column=1, sticky=W, padx=(4, 0))
        self.en4 = Entry(self.fr2b, width=35, font=font2)
        self.en4.grid(row=1, column=1, sticky=W, padx=(4, 0))
        self.cb6 = ttk.Combobox(self.fr2b, state='readonly')
        self.cb6.grid(row=2, column=1, sticky='we', padx=(4, 0))

        self.lb9 = Label(self.fr2b, text='Colaborador:', bg=cor_f, font=font2).grid(row=0, column=2, sticky=W,
                                                                                    padx=(4, 0))
        self.en5 = Entry(self.fr2b, width=37, font=font2, state='disable')
        self.en5.grid(row=1, column=2, sticky=W, padx=(4, 0))
        self.cb7 = ttk.Combobox(self.fr2b, state='disable')
        self.cb7.set('0 - Não se aplica')
        self.cb7.grid(row=2, column=2, sticky='we', padx=(4, 0))

        self.fr2b.grid(row=1, column=0, sticky=W)
        self.fr2c = Frame(self.fr2, bg=cor_f)
        self.bt1 = Button(self.fr2c, text='Incluir', command=self.pressbt1, font=font2)
        self.bt1.grid(row=0, column=0, sticky=W, padx=(4, 0))
        self.fr2c.grid(row=0, column=1, rowspan=2)
        self.fr2d = Frame(self.fr2, bg=cor_f)
        self.en6 = Entry(self.fr2d, width=107, font=font2)
        self.en6.grid(row=0, column=0, sticky=W, padx=(4, 0), pady=(4, 0))
        self.bt2 = Button(self.fr2d, text='Localizar', font=font2)
        self.bt2.grid(row=0, column=1, sticky=W, padx=(4, 0), pady=(4, 0))
        self.fr2d.grid(row=2, column=0, columnspan=2, sticky=E)
        self.ls1 = ttk.Treeview(self.fr2, height=8)
        self.carrega_lista(0, 'vw_instrumental', self.ls1)
        self.ls1.grid(row=3, column=0, columnspan=2, sticky='nswe', padx=(4, 0), pady=(4, 0))
        self.fr2.grid(row=1, column=0, sticky=W, ipadx=2, ipady=2)
        self.fr1.grid(padx=10, pady=10)

    def valen1(self):
        trat = self.en1.get()
        self.en1.delete(0, END)
        self.en1.insert(0, ''.join(trat.split()).upper())

    def valen2(self):
        try:
            if self.lb6var.get()[0] == 'D':
                trat = datetime.strptime(self.en2.get(), '%d/%m/%Y')
                self.en2.delete(0, END)
                self.en2.insert(0, trat.strftime('%d/%m/%Y'))
            else:
                trat = datetime.strptime(self.en2.get(), '%Y')
                self.en2.delete(0, END)
                self.en2.insert(0, trat.strftime('%Y'))
        except:
            messagebox.showinfo('Formato', 'Data/Ano inválidos!')
            self.en2.focus_force()

    def telainicial(self):
        self.lb4var.set('')
        self.lb6var.set('')
        self.cb2.set('')
        self.cb3.set('')
        self.en1.delete(0, END)
        self.cb4.set('0 - Não se aplica')
        self.cb4.configure(state='disable')
        self.en2.delete(0, END)
        self.en2.insert(0, '0 - Não se aplica')
        self.en2.configure(state='disable')
        self.en3.delete(0, END)
        self.cb5.set('')
        self.en3.configure(state='disable')
        self.cb5.configure(state='disable')
        self.en5.delete(0, END)
        self.cb7.set('')
        self.en5.configure(state='disable')
        self.cb7.configure(state='disable')

    def pressbt1(self):
        ck1 = self.cb1.get()[:self.cb1.get().find('-') - 1]
        ck2 = self.cb2.get()[:self.cb2.get().find('-') - 1]  # not insert
        ck3 = self.cb3.get()[:self.cb3.get().find('-') - 1]
        ck4 = self.en1.get()
        ck5 = self.cb4.get()[:self.cb4.get().find('-') - 1]
        ck6 = self.en2.get()
        ck7 = self.cb5.get()[:self.cb5.get().find('-') - 1]
        ck8 = self.cb6.get()[:self.cb6.get().find('-') - 1]
        ck9 = self.cb7.get()[:self.cb7.get().find('-') - 1]  # not insert
        if ck1 != '' and ck2 != '' and ck3 != '' and ck4 != '' and ck5 != '' and ck6 != '' and ck7 != '' and ck8 != '' and ck9 != '':
            query = 'call prcInsereInstrumental(' + ck2 + ', ' + ck3 + ', "' + ck4 + '", ' + ck5 + ', "' + ck6 + '", ' + ck7 + ', ' + ck8 + ', ' + ck9 + ')'
            ret = cnx.sqlcmd(cnx(), query)
            if int(ret) > 0:
                messagebox.showinfo('Cadastro de instrumental', 'Cadastro realizado com sucesso!')
                self.telainicial()
                self.carrega_lista(0, 'vw_instrumental', self.ls1)
            else:
                messagebox.showinfo('Cadastro de instrumental', 'O cadastro não foi realizado!')
        else:
            messagebox.showinfo('Cadastro de instrumental', 'Certifique que todos os campos estão preenchidos!')

    def taben3(self):
        self.cb5.set('')
        self.cb5['values'] = cnx.sqlcb(cnx(), 'id', 'ds', 'vw_matserv_instrumental',
                                       'where ds like "%' + self.en3.get() + '%"')

    def taben4(self):
        self.cb6.set('')
        self.cb6['values'] = cnx.sqlcb(cnx(), 'id', 'ds', 'vw_instrumental_contrato', 'where id_is = ' +
                                       self.cb2.get()[:self.cb2.get().find('-') - 1] + ' and id_io = ' +
                                       self.cb3.get()[:self.cb3.get().find(
                                           '-') - 1] + ' and ds like "%' + self.en4.get() + '%"')

    def carrega_comb(self, id, ds, tab, controle, ccond='', cond=''):
        controle.set('')
        if cond == '':
            b = cnx.sqlcmb2(cnx(), id, ds, tab)
        else:
            if ccond == '':
                b = cnx.sqlcmb2(cnx(), id, ds, tab, '', str(cond))
            else:
                b = cnx.sqlcmb2(cnx(), id, ds, tab, ccond, str(cond))
        controle['values'] = b

    def selcb1(self):
        self.telainicial()
        if self.cb1dict[int(self.cb1.get()[:self.cb1.get().find('-') - 1])][1] == 0:
            self.en3.configure(state='disable')
            self.cb5.configure(state='disable')
        else:
            self.en3.configure(state='normal')
            self.cb5.configure(state='readonly')
        self.carrega_comb('id', 'ds', 'instrumental_subtipo', self.cb2, 'id_it',
                          self.cb1.get()[:self.cb1.get().find('-') - 1])
        self.cb2dict = cnx.sqldict(cnx(), 'SELECT * FROM vw_instrumental_subtipo', 4)
        if self.cb1.get()[:self.cb1.get().find('-') - 1] != '3':
            self.en3.configure(state='normal')
            self.cb5.configure(state='readonly')
            self.cb5.set('')
        else:
            self.en3.configure(state='disable')
            self.cb5.configure(state='disable')
            self.en3.delete(0, END)
            self.cb5.set('0 - Não se aplica')

    def selcb2(self):
        self.lb4var.set(self.cb2dict[int(self.cb2.get()[:self.cb2.get().find('-') - 1])][0])
        if not self.cb2dict[int(self.cb2.get()[:self.cb2.get().find('-') - 1])][1] == None:
            self.lb6var.set(self.cb2dict[int(self.cb2.get()[:self.cb2.get().find('-') - 1])][1])
            self.en2.configure(state='normal')
            self.en2.delete(0, END)
        else:
            self.lb6var.set('')
            self.en2.configure(state='normal')
            if self.en2.get() == '':
                self.en2.insert(0, '0 - Não se aplica')
            self.en2.configure(state='disable')
        if self.cb2dict[int(self.cb2.get()[:self.cb2.get().find('-') - 1])][2] == 1:
            self.carrega_comb('id', 'ds', 'instrumental_subtipo_cor', self.cb4)
            self.cb4.configure(state='readonly')
        else:
            self.cb4.set('0 - Não se aplica')
            self.cb4.configure(state='disable')

    def selcb3(self):
        if int(self.cb3.get()[:self.cb3.get().find('-') - 1]) == 1:
            self.en5.configure(state='normal')
            self.cb7.configure(state='readonly')
            self.cb7.set('')
        else:
            self.cb7.set('0 - Não se aplica')
            self.en5.configure(state='disable')
            self.cb7.configure(state='disable')

    def carrega_lista(self, tp, tab, controle, filtro='', valor=0):  # tp: 0=cabeçalho e itens / 1=cabeçalho / 2=itens
        if tp in (0, 1):
            try:
                test = controle.heading(1)
            except:
                self.tvhead(tab, controle)
        if tp in (0, 2):
            if filtro == '':
                itens = 'select * from ' + tab
            else:
                itens = 'select * from ' + tab + ' where ' + filtro + ' like "%' + str(valor) + '%"'
            a = cnx()
            c = a.sqlquery(itens)
            if controle.exists(1):
                for i in controle.get_children():
                    controle.delete(i)
            idx = 1
            for row in c:
                controle.insert('', END, iid=idx, values=row, )
                idx += 1

    def tvhead(self, tab, controle):
        nomes = 'SELECT col, tam, anc FROM listab WHERE tab = "' + tab + '"'
        a = cnx()
        b = a.sqllist(nomes)
        qt = 1
        vis = []
        for i in b:
            if b[qt][1] != 0:
                vis.append(qt)
            qt += 1
        controle.configure(columns=list(b.keys()), displaycolumns=vis, selectmode='browse', show='headings')
        qt = 1
        for i in b:
            controle.heading(qt, text=b[qt][0], anchor=b[qt][2])
            controle.column(qt, stretch=False, minwidth=0, width=b[qt][1], anchor=b[qt][2])
            qt += 1

class usrs():
    def __init__(self, master, root):
        self.cb2dict = {}
        self.cb3dict = {}
        self.lb4var = StringVar()
        self.lb6var = StringVar()
        self.style = ttk.Style()
        self.style.configure('Treeview.Heading', font=font3)
        self.master = master
        self.master['bg'] = cor_f
        l_tela = self.master.winfo_screenwidth()
        a_tela = self.master.winfo_screenheight()
        l_ws = 960  # self.master.winfo_width()
        a_ws = 660  # self.master.winfo_height()
        posx = l_tela / 2 - l_ws / 2
        posy = a_tela / 2 - a_ws / 1.85
        self.master.resizable(width=0, height=0)
        self.master.transient(root)
        self.master.focus_force()
        self.master.grab_set()
        self.master.geometry("%dx%d+%d+%d" % (l_ws, a_ws, posx, posy))
        self.master.iconphoto(False, tk.PhotoImage(file=icon))
        self.master.title('Usuários e acessos para ' + vNm_r + ' | lvflwX ' + vVer1)

        self.fr1 = Frame(self.master, bg=cor_f)
        self.fr2 = Frame(self.fr1, borderwidth=1, relief='ridge', bg=cor_f)
        self.fr2a = Frame(self.fr2, bg=cor_f)
        self.lb1 = Label(self.fr2a, text='Colaboradores:', bg=cor_f, font=font2).grid(row=0, column=0, sticky=W,
                                                                                      padx=(4, 0))
        self.en1 = Entry(self.fr2a, width=35, font=font2)
        self.en1.bind('<Tab>', lambda event: self.carcb1())
        self.en1.grid(row=1, column=0, sticky=W, padx=(4, 0))
        self.cb1 = ttk.Combobox(self.fr2a, state='readonly', width=21)
        self.cb1.grid(row=2, column=0, sticky='we', padx=(4, 0))
        self.en2 = Entry(self.fr2a, width=35, font=font2)
        self.en2.grid(row=3, column=0, sticky=W, padx=(4, 0), pady=(4, 0))
        self.fr2a.grid(row=0, column=0)
        self.fr2b = Frame(self.fr2, bg=cor_f)
        self.bt1 = Button(self.fr2b, text='Incluir', font=font2)
        self.bt1.grid(row=0, column=1, sticky='we', padx=(4, 0), pady=(4, 0))
        self.bt2 = Button(self.fr2b, text='Bloquear', font=font2)
        self.bt2.grid(row=1, column=1, sticky='we', padx=(4, 0), pady=(4, 0))
        self.bt3 = Button(self.fr2b, text='Localizar', font=font2)
        self.bt3.grid(row=3, column=1, sticky='we', padx=(4, 0), pady=(4, 0))
        self.fr2b.grid(row=0, column=1)

        self.ls1 = ttk.Treeview(self.fr2, height=10)
        self.carrega_lista(0, 'vw_usrs_users', self.ls1)
        self.ls1.bind('<<TreeviewSelect>>', lambda event: self.getls1())
        self.ls1.grid(row=1, column=0, columnspan=2, sticky='nswe', padx=(4, 0), pady=(4, 0))

        self.fr2c = Frame(self.fr2, bg=cor_f)
        self.lb2 = Label(self.fr2c, text='Comandos disponíveis:', bg=cor_f, font=font2).grid(row=1, column=2, sticky=W,
                                                                                             padx=(4, 0))
        self.lb3 = Label(self.fr2c, text='Comandos liberados:', bg=cor_f, font=font2).grid(row=1, column=3, sticky=W,
                                                                                           padx=(4, 0))
        self.lb4 = Label(self.fr2c, bg=cor_f, font=sep, width=56).grid(row=0, column=2, sticky='we')
        self.lb5 = Label(self.fr2c, bg=cor_f, font=sep, width=56).grid(row=0, column=3, sticky='we')

        self.ls2 = ttk.Treeview(self.fr2c, show='tree', height=14)
        self.ls2.grid(row=2, column=2, sticky='we', padx=(4, 0), pady=(4, 0))

        self.ls3 = ttk.Treeview(self.fr2c, show='tree', height=14)
        self.ls3.bind('<<TreeviewSelect>>', lambda event: self.getls3())
        self.ls3.grid(row=2, column=3, sticky='we', padx=(4, 0), pady=(4, 0))
        self.fr2c.grid(row=0, column=2, rowspan=2, sticky='we')

        self.fr2.grid(row=1, column=0, sticky=W, ipadx=2, ipady=2)
        self.fr1.grid(padx=10, pady=10)

    def getls3(self):
        pass

    def getls1(self):
        query1 = 'select * from vw_sc where id in (select id_sc from vw_scu_disponiveis where id_u = ' + str(
            self.ls1.item(self.ls1.focus())['values'][0]) + ')'
        query2 = 'select * from vw_sc where id in (select id_sc from vw_scu_liberados where id_u = ' + str(
            self.ls1.item(self.ls1.focus())['values'][0]) + ')'
        self.carrega_controle(query1, self.ls2)
        self.carrega_controle(query2, self.ls3)

    def carrega_controle(self, query, controle):
        b = cnx.sqlquery(cnx(), query)
        if controle.exists(1):
            for i in controle.get_children():
                controle.delete(i)
        qt = 1
        for row in b:
            if row[0] == 0:
                idx = controle.insert('', END, iid=qt, text=row[3], values=row)
            else:
                controle.insert(idx, END, iid=qt, text=row[3], values=row)
            qt += 1

    def carcb1(self):
        self.cb1['values'] = cnx.qcb(cnx(), 'cd', 'nm', 'vw_usrs_colab', 'nm', f'concat(cd, nm) like "%{self.en1.get()}%"')

    def tvhead(self, tab, controle):
        nomes = 'SELECT col, tam, anc FROM listab WHERE tab = "' + tab + '"'
        a = cnx()
        b = a.sqllist(nomes)
        qt = 1
        vis = []
        for i in b:
            if b[qt][1] != 0:
                vis.append(qt)
            qt += 1
        controle.configure(columns=list(b.keys()), displaycolumns=vis, selectmode='browse', show='headings')
        qt = 1
        for i in b:
            controle.heading(qt, text=b[qt][0], anchor=b[qt][2])
            controle.column(qt, stretch=False, minwidth=0, width=b[qt][1], anchor=b[qt][2])
            qt += 1

    def carrega_lista(self, tp, tab, controle, filtro='', valor=0):  # tp: 0=cabeçalho e itens / 1=cabeçalho / 2=itens
        if tp in (0, 1):
            try:
                test = controle.heading(1)
            except:
                self.tvhead(tab, controle)
        if tp in (0, 2):
            if filtro == '':
                itens = 'select * from ' + tab
            else:
                itens = 'select * from ' + tab + ' where ' + filtro + ' like "%' + str(valor) + '%"'
            a = cnx()
            c = a.sqlquery(itens)
            if controle.exists(1):
                for i in controle.get_children():
                    controle.delete(i)
            idx = 1
            for row in c:
                controle.insert('', END, iid=idx, values=row)
                idx += 1

class mprt():
    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 960, 660, 'Importações para', vNm_r)
        sf.frm = frm(master, 0, 0)
        sf.fr1 = fr(sf.frm, 0, 0)
        sf.en1 = en(sf.fr1, 0, 0, 50, [], 'we', state='readonly')
        sf.bt1 = bt(sf.fr1, 0, 1, 'Arquivo', sf.prsbt1, 7, W, state='disable')
        sf.cb1 = cb(sf.fr1, 0, 2, 25, [], 'we', state='disable')
        sf.bt2 = bt(sf.fr1, 0, 3, 'Importar', sf.prsbt2, 7, W, state='disable')
        sf.bt3 = bt(sf.fr1, 0, 4, 'Cancelar', sf.prsbt3, 7, W, state='disable')
        sf.ls1 = ls(sf.fr1, 1, 0, 10, [('<<TreeviewSelect>>', sf.getls1), ], cs=5)
        carrega_lista(0, 'vw_import', sf.ls1)
        sf.fr2 = fr(sf.frm, 1, 0)
        sf.bt4 = bt(sf.fr2, 0, 0, 'Incluir', sf.prsbt4, 7, W, state='disable')
        sf.bt5 = bt(sf.fr2, 0, 1, 'Editar', sf.prsbt5, 7, W, state='disable')
        sf.en1 = en(sf.fr2, 0, 2, 20, [], W)
        sf.ls2 = ls(sf.fr2, 1, 0, 10, [('<<TreeviewSelect>>', sf.getls2), ], cs=3)
        carrega_lista(0, 'vw_import_cadastros', sf.ls2)
        sf.ls3 = ls(sf.fr2, 1, 4, 10, [])
        carrega_lista(1, 'import_detalhes', sf.ls3)
        sf.ls4 = ls(sf.fr2, 1, 5, 10, [])


    def getls1(sf, ev):
        if len(sf.ls1.selection()) > 0:
            sf.bt3.configure(state='normal')
            sf.ls1.configure(selectmode='none')
            sf.ls1var = int(sf.ls1.item(sf.ls1.focus())['values'][6])
            sf.en1.configure(state='normal')
            sf.en1.delete(0, END)
            sf.en1.configure(state='readonly')
            sf.bt1.configure(state='normal')
        else:
            sf.en1.configure(state='normal')
            sf.en1.delete(0, END)
            sf.en1.configure(state='readonly')
            sf.bt1.configure(state='disable')

    def prsbt1(sf):
        arq = (('Excel', '*.xls*'),)
        local = open_file('./', 'Selecione o arquivo para importação...', arq)
        sf.en1.configure(state='normal')
        sf.en1.insert(0, local[1])
        sf.en1.configure(state='readonly')
        sf.bt1.configure(state='disable')
        abas = abre_arquivo_xl(local[0])
        sf.cb1.configure(state='normal')
        if len(abas) > 1:
            sf.cb1['values'] = list(abas)
        else:
            sf.cb1.set(abas[0])
            sf.cb1.configure(state='disable')
            if verifica_layout_xl(sf.cb1.get(), int(sf.ls1.item(sf.ls1.focus())['values'][6])):
                sf.bt2.configure(state='normal')
            else:
                messagebox.showerror('Importação', 'Layout inválido!')

    def prsbt2(sf):
        resp = importa_arquivo_xl(int(sf.ls1.item(sf.ls1.focus())['values'][6]),
                                  sf.ls1.item(sf.ls1.focus())['values'][9],
                                  sf.ls1.item(sf.ls1.focus())['values'][10])
        if resp:
            cnx.sqlcmd(cnx(), 'update import set ss=0, tp=0, idr=' + str(vId) + ' where id=' + getpls(sf.ls1, 0))
            cnx.sqlcmd(cnx(), 'call prcImportacoes(' + str(sf.ls1.item(sf.ls1.focus())['values'][6]) + ', ' + str(
                vId) + ', "' +
                       sf.ls1.item(sf.ls1.focus())['values'][10] + '")')
            carrega_lista(2, 'vw_import', sf.ls1)
        sf.prsbt3()

    def prsbt3(self):
        self.en1.configure(state='normal')
        self.en1.delete(0, END)
        self.en1.configure(state='readonly')
        self.bt1.configure(state='disable')
        self.cb1.configure(state='normal')
        self.cb1['values'] = []
        self.cb1.set('')
        self.cb1.configure(state='disable')
        self.bt2.configure(state='disable')
        self.bt3.configure(state='disable')
        self.ls1.configure(selectmode='browse')
        fecha_arquivo_xl()

    def prsbt4(sf):
        sf.popup = Toplevel(sf.master)
        win(sf.popup, sf.master, 500, 165, 'Incluir/Editar Importação')
        sf.fm1 = frm(sf.popup, 0, 0)
        sf.f1 = fr(sf.fm1, 0, 0)
        sf.e1 = en(sf.f1, 0, 0, 50, [], W, state='readonly')
        sf.b1 = bt(sf.f1, 0, 1, 'Arquivo', sf.prsb1, 7, W)
        sf.f1a = fr(sf.f1, 1, 0, cs=2)
        sf.c1 = cb(sf.f1a, 0, 0, 25, [], W, state='disable')
        lb(sf.f1a, 0, 1, 'Cab.:')
        sf.e2 = en(sf.f1a, 0, 2, 9, [], W, state='readonly')
        lb(sf.f1a, 0, 3, 'Dad.:')
        sf.e3 = en(sf.f1a, 0, 4, 9, [], W, state='readonly')
        sf.f1b = fr(sf.f1, 2, 0, cs=2)
        lb(sf.f1b, 0, 0, 'Cel. Ini. Cab.:')
        sf.e4 = en(sf.f1b, 0, 1, 4, [], W)
        lb(sf.f1b, 0, 2, 'Cel. Ini. Dad.:')
        sf.e5 = en(sf.f1b, 0, 3, 4, [], W)
        lb(sf.f1b, 0, 4, 'Tam.:')
        sf.e6 = en(sf.f1b, 0, 5, 4, [], W)
        sf.f1c = fr(sf.f1, 3, 0, cs=2)
        lb(sf.f1c, 0, 0, 'Tabela:')
        sf.c2 = cb(sf.f1c, 0, 1, 25, [], W)
        sf.c2['values'] = cnx.sqlcb2(cnx(), 'ds', '', 'vw_tabs_imp')
        sf.b2 = bt(sf.f1, 4, 0, 'Cancelar', sf.prsb2, 7, E)
        sf.b3 = bt(sf.f1, 4, 1, 'Salvar', sf.prsb3, 7, E)

    def prsb2(sf):
        sf.popup.destroy()

    def prsb3(sf):
        r = monta_range_imp(sf.e4.get(), sf.e5.get(), + int(sf.e6.get()))
        sf.e2.configure(state='normal')
        sf.e2.insert(0, r[0])
        sf.e2.configure(state='disable')
        sf.e3.configure(state='normal')
        sf.e3.insert(0, r[1])
        sf.e3.configure(state='disable')
        
    def prsb1(sf):
        arq = (('Excel', '*.csv*'),)
        local = open_file('./', 'Selecione o arquivo para importação...', arq)
        sf.e1.configure(state='normal')
        sf.e1.insert(0, local[1])
        sf.e1.configure(state='readonly')
        abas = abre_arquivo_xl(local[0])
        fecha_arquivo_xl()
        sf.c1.configure(state='normal')
        if len(abas) > 1:
            sf.c1['values'] = list(abas)
        else:
            sf.c1.set(abas[0])
            sf.c1.configure(state='disable')

    def prsbt5(sf):
        pass

    def getls2(sf, ev):
        if getpls(sf.ls2, 3) == '-':
            sf.bt4.configure(state='normal')
            sf.bt5.configure(state='disable')
            limpa_lista(sf.ls3)
            limpa_lista(sf.ls4)
        else:
            sf.bt4.configure(state='disable')
            sf.bt5.configure(state='normal')
            carrega_lista(3, 'select * from vw_import_detalhes where `or` = ' + getpls(sf.ls2, 0), sf.ls3)
            carrega_lista(3, 'SELECT ordinal_position, column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = "sistema" AND TABLE_NAME = ' + getpls(sf.ls2, 3) + ' order by 1', sf.ls4)

class ccpt():
    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 960, 660, 'Centros de Cutos e Postos de Trabalho')
        sf.frm = frm(sf.master, 0, 0)
        
        sf.fr1 = fr(sf.frm, 0, 0)
        lb(sf.fr1, 0, 0, 'Centros de Custos')
        sf.en1 = en(sf.fr1, 0, 1, 15)
        sf.bt1 = bt(sf.fr1, 0, 2, 'Editar', sf.prsbt1)
        sf.fr1a = fr(sf.frm, 1, 0)
        sf.ls1 = ls(sf.fr1a, 0, 0, 12)
        carrega_lista(0, 'vw_at_centrocusto', sf.ls1)

        sf.fr2 = fr(sf.frm, 2, 0)
        lb(sf.fr2, 0, 0, 'Postos de Trabalho')
        sf.en2 = en(sf.fr2, 0, 1, 15)
        sf.bt2 = bt(sf.fr2, 0, 2, 'Criar', sf.prsbt2)
        sf.ls2 = ls(sf.fr2, 1, 0, 13, cs=2)

    def prsbt1(sf):
        if len(sf.ls1.selection()) > 0:
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 450, 200, 'Centro de Custo/Edição')
            sf.f = frm(sf.popup, 0, 0)
            lb(sf.f, 0, 0, 'Movimentar')
            sf.c1 = cb(sf.f, 0, 1, 18)
            sf.c1['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'atividades_status', f'where id in {cnx.sqlpss(cnx(), getpls(sf.ls1, 9), getpls(sf.ls1, 8))}')
            lb(sf.f, 1, 0, 'Código')
            sf.e1 = en(sf.f, 1, 1, 22, state='readonly')
            insen(sf.e1, getpls(sf.ls1, 1))
            lb(sf.f, 2, 0, 'Descrição')
            sf.e2 = en(sf.f, 2, 1, 42)
            insen(sf.e2, getpls(sf.ls1, 2))
            lb(sf.f, 3, 0, 'Nome')
            sf.e3 = en(sf.f, 3, 1, 18, [('<FocusOut>', sf.oute3)])
            insen(sf.e3, getpls(sf.ls1, 3))
            lb(sf.f, 4, 0, 'Segmento')
            sf.c2 = cb(sf.f, 4, 1, 18)
            sf.c2['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'gestao_segmentos')
            sf.c2.set(cnx.sqlcid(cnx(), 'id', 'ds', getpls(sf.ls1, 10), 'gestao_segmentos'))
            lb(sf.f, 5, 0, 'Cliente')
            sf.c3 = cb(sf.f, 5, 1, 18)
            sf.c3['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'gestao_clientes')
            sf.c3.set(cnx.sqlcid(cnx(), 'id', 'ds', getpls(sf.ls1, 11), 'gestao_clientes'))
            sf.b1 = bt(sf.f, 6, 1, 'Salvar', sf.prsb1, 8, E)
        else:
            msgb(2, 'Centro de Custo/Edição', 'É preciso selecionar um CC para edição!', sf.master)

    def prsb1(sf):
        if getvct(sf.c1) and getvct(sf.e2) and getvct(sf.e3) and getvct(sf.c2) and getvct(sf.c3):
            cnx.sqlcmd(cnx(), f'update at_centrocusto set ds = {getven(sf.e2)}, nm = {getven(sf.e3)}, ss = fncGetIdSs({getpls(sf.ls1, 8)}, {getpcb(sf.c1)}), id_gs = {getpcb(sf.c2)}, id_gc = {getpcb(sf.c3)}, rg = {str(vId)}, o = "Desc: {getven(sf.e2, 2)} | Nome: {getven(sf.e3, 2)} | Seg: {getdscb(sf.c2)} | Cli: {getdscb(sf.c3)}" where id = {getpls(sf.ls1, 0)}')
            if getvct(sf.c1, v=2):
                a = cnx.csql1(cnx(), f'select ds, ds1, ss, if(status="ATIVO", 2, 0) as ss1, id_gs, id_gs1 from at_centrocusto where id = {getpls(sf.ls1, 0)}')
                r = ''
                if a[1] == None:
                    r = ' Não cadastrado'
                else:
                    if a[0] != a[1]:
                        r = ' -De'
                    if a[2] != a[3]:
                        r = r + ' -St'
                    if a[4] != a[5]:
                        r = r + ' -Se'
                if len(r) > 0:
                    cnx.sqlcmd(cnx(), f'update at_centrocusto set ssp = 1, rg = 0, op = "{r[1:]}" where id = {getpls(sf.ls1, 0)}')
            chrls(sf.ls1, 'select * from vw_at_centrocusto', 2)
            sf.popup.destroy()
        else:
            msgb(2, 'Centro de Custo/Edição', 'Nenhum campo pode estar em branco!', sf.popup)

    def oute3(sf, ev):
        if len(sf.e3.get()) > 0:
            txt = lmpchar(sf.e3.get())[:4]
            txt = txt.replace(' ', '').upper()
            sf.e3.delete(0, END)
            sf.e3.insert(0, txt)

    def prsbt2(sf):
        if len(sf.ls1.selection()) > 0:
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 450, 200, 'Posto de Trabalho/Criação')
            sf.f = frm(sf.popup, 0, 0)
            lb(sf.f, 0, 0, 'C. Custo')
            sf.e1 = en(sf.f, 0, 1, 22, state='readonly')
            insen(sf.e1, getpls(sf.ls1, 1))
            sf.e2 = en(sf.f, 0, 2, 6, state='readonly')
            insen(sf.e2, getpls(sf.ls1, 3))
            lb(sf.f, 1, 0, 'Segmento')
            sf.e3 = en(sf.f, 1, 1, 22, state='readonly')
            insen(sf.e3, cnx.sqlcid(cnx(), 'id', 'ds', getpls(sf.ls1, 10), 'gestao_segmentos'))
            lb(sf.f, 2, 0, 'Cliente')
            sf.e4 = en(sf.f, 2, 1, 22, state='readonly')
            insen(sf.e4, cnx.sqlcid(cnx(), 'id', 'ds', getpls(sf.ls1, 11), 'gestao_clientes'))

        else:
            msgb(2, 'Posto de Trabalho/Criação', 'É preciso selecionar um CC!', sf.master)

class cnat():
    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 975, 670, 'Controle de Atividades')
        sf.frm = frm(master, 0, 0)

        sf.fr1 = fr(sf.frm, 0, 0)
        lb(sf.fr1, 0, 0, 'Cadastro Geral', 'ws')
        sf.fr1a = fr(sf.fr1, 0, 1, E)
        sf.en1 = en(sf.fr1a, 0, 0, 12, [('<Tab>', sf.chrls1)])
        bt(sf.fr1a, 0, 1, 'Incluir', sf.prsbt1, 5)
        sf.ls1 = ls(sf.fr1, 1, 0, 13, [('<<TreeviewSelect>>', sf.clkls1), ], cs=2)
        carrega_lista(0, 'vw_atividades', sf.ls1)

        sf.fr2 = fr(sf.frm, 0, 1)
        lb(sf.fr2, 0, 0, 'Cadastro Detahe', 'ws')
        sf.fr2a = fr(sf.fr2, 0, 1, E)
        sf.en2 = en(sf.fr2a, 0, 0, 8, [('<Tab>', sf.chrls2), ])
        sf.bt2 = bt(sf.fr2a, 0, 1, 'Incluir', sf.prsbt2, 5)
        sf.bt2a = bt(sf.fr2a, 0, 2, 'Editar', sf.prsbt2a, 5)
        sf.ls2 = ls(sf.fr2, 1, 0, 13, [('<<TreeviewSelect>>', sf.clkls2), ], cs=2)
        carrega_lista(1, 'vw_atividades_cadastros', sf.ls2)

        sf.fr3 = fr(sf.frm, 0, 2)
        lb(sf.fr3, 0, 0, 'Vínculo Status', 'ws')
        sf.fr3a = fr(sf.fr3, 0, 1, E)
        sf.bt3a = bt(sf.fr3a, 0, 0, 'Prx', sf.prsbt3a, 3, state='disable')
        sf.bt3b = bt(sf.fr3a, 0, 1, 'Alt', sf.prsbt3b, 3, state='disable')
        sf.ls3 = ls(sf.fr3, 1, 0, 13, [('<<TreeviewSelect>>', sf.clkls3), ('<Double-Button-1>', sf.dblls3)], cs=2)
        carrega_lista(1, 'vw_atividades_status_v', sf.ls3, sel=2)

        sf.fr4 = fr(sf.frm, 1, 0)
        lb(sf.fr4, 0, 0, 'Cadastro Status', 'ws')
        sf.fr4a = fr(sf.fr4, 0, 1, E)
        sf.en4 = en(sf.fr4a, 0, 0, 8, [('<Tab>', sf.chrls2)])
        sf.bt4 = bt(sf.fr4a, 0, 1, 'Incluir', sf.prsbt4, 5)
        sf.bt4a = bt(sf.fr4a, 0, 2, 'Editar', lambda a=1: sf.prsbt4(a), 5)
        sf.ls4 = ls(sf.fr4, 1, 0, 13, [('<<TreeviewSelect>>', sf.clkls4), ('<Double-Button-1>', sf.dblls4)], 'we', cs=2)
        carrega_lista(0, 'vw_atividades_status', sf.ls4)

        sf.fr5 = fr(sf.frm, 1, 1)
        lb(sf.fr5, 0, 0, 'Cadastro Pendência', 'ws')
        sf.fr5a = fr(sf.fr5, 0, 1, E)
        sf.en5 = en(sf.fr5a, 0, 0, 8, [('<Tab>', sf.chrls5)])
        sf.bt5 = bt(sf.fr5a, 0, 1, 'Incluir', sf.prsbt5, 5)
        sf.bt5a = bt(sf.fr5a, 0, 2, 'Editar', lambda a=1: sf.prsbt5(a), 5)
        sf.ls5 = ls(sf.fr5, 1, 0, 13, [('<Double-Button-1>', sf.dblls5)], 'we', cs=2)
        carrega_lista(0, 'vw_atividades_pendencia', sf.ls5)

        sf.fr6 = fr(sf.frm, 1, 2)
        lb(sf.fr6, 0, 0, 'Vínculo Pendência', 'ws')
        sf.ls6 = ls(sf.fr6, 1, 0, 13, [('<Double-Button-1>', sf.dclls6), ], cs=2)
        carrega_lista(1, 'vw_atividades_pendencia_v', sf.ls6)

    def chrls1(sf, ev):
        carrega_lista(2, 'vw_atividades', sf.ls1, 'ds', sf.en1.get())

    def prsbt1(sf):
        sf.popup = Toplevel(sf.master)
        win(sf.popup, sf.master, 418, 128, 'Nova Atividade/Cadastro')
        sf.f = frm(sf.popup, 0, 0)
        lb(sf.f, 0, 0, 'Nome:', )
        sf.e1 = en(sf.f, 0, 1, 18, [('<FocusOut>', sf.oute1)], 'we', cs=2)
        lb(sf.f, 1, 0, 'Tabela:')
        sf.e2 = en(sf.f, 1, 1, 18, [('<FocusOut>', sf.oute2)], 'we', cs=2)
        lb(sf.f, 2, 0, 'Comando:')
        sf.e3 = en(sf.f, 2, 1, 6, [('<Tab>', sf.oute3)])
        sf.c1 = cb(sf.f, 2, 2, 30)
        bt(sf.f, 3, 2, 'Salvar', sf.prsb1, 6, E, cs=2)

    def oute1(sf, ev):
        if len(sf.e1.get()) > 0:
            if cnx.sqlexist(cnx(), 'nm', 'atividades', f'"{sf.e1.get()}"'):
                msgb(2, 'Nova Atividade/Cadastro', 'Nome já cadastrado!', sf.master)
                sf.e1.focus_force()

    def oute2(sf, ev):
        if len(sf.e2.get()) > 0:
            txt = f'at_{lmpchar(sf.e2.get())}'
            txt = txt.replace(' ', '_')
            sf.e2.delete(0, END)
            sf.e2.insert(0, txt)
            if cnx.sqlexist(cnx(), 'tab', 'vw_tabs', f'"{sf.e2.get()}"'):
                msgb(2, 'Nova Atividade/Cadastro', 'Tabela já cadastrada!', sf.master)
                sf.e2.focus_force()

    def oute3(sf, ev):
        sf.c1['values'] = ''
        sf.c1['values'] = cnx.qcb(cnx(), 'cd', 'ds', 'vw_sist_cmd', 2, f'concat(cd, ds) like "%{sf.e3.get()}%"')

    def prsb1(sf):
        if len(sf.e1.get()) > 0 or len(sf.e2.get()) > 0 or len(sf.c1.get()) > 0 or len(sf.c2.get()) > 0:
            cmd = str(getpcb(sf.c1, 1)).replace('(', '').replace(')', '')
            cnx.sqlcmd(cnx(), f'call prcInsAtivTab("{sf.e1.get()}", "{sf.e2.get()}", "{cmd}")')
            criaTrigger(sf.e2.get())
            sf.en1.delete(0, END)
            sf.chrls1(1)
            locsells(sf.ls1, 3, sf.e1.get())
            sf.popup.destroy()            
        else:
            msgb(2, 'Nova Atividade/Cadastro', 'Nenhum campo do cadastro pode ser vazio!', sf.popup)

    def prsbt5(sf, ed=0):
        sf.popup = Toplevel(sf.master)
        win(sf.popup, sf.master, 292, 126, 'Nova Pendência')
        sf.f = frm(sf.popup, 0, 0)
        lb(sf.f, 0, 0, 'Descrição:')
        sf.e1 = en(sf.f, 0, 1, 18, [], 'we')
        lb(sf.f, 1, 0, 'Cód. Externo:')
        sf.e2 = en(sf.f, 1, 1, 8, justify=RIGHT)
        lb(sf.f, 2, 0, 'Origem:')
        sf.c1 = cb(sf.f, 2, 1, 18)
        sf.c1['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'atividades_pendencia_origem')
        bt(sf.f, 3, 1, 'Salvar', sf.prsb15, 6, E)

    def prsb15(sf):
        if getvct(sf.e1) and getvct(sf.c1):
            if getvct(sf.e2):
                w = f'where ds = {getven(sf.e1)} and ex = {getven(sf.e2)} and id_apo = {getpcb(sf.c1)}'
            else:
                w = f'where ds = {getven(sf.e1)} and id_apo = {getpcb(sf.c1)}'
            if not cnx.sqlexist3(cnx(), 'id', 'atividades_pendencia', w):
                cnx.sqlcmd(cnx(), f'call prcInsAtivPd({getven(sf.e1)}, {getven(sf.e2, 2)}, {getpcb(sf.c1)})')
                sf.chrls5(1)
                if getvct(sf.e2):
                    locsells(sf.ls5, 1, sf.e1.get() + '/' + getdscb(sf.c1) + '/' + sf.e2.get())
                else:
                    locsells(sf.ls5, 1, sf.e1.get() + '/' + getdscb(sf.c1))
                sf.popup.destroy()
            else:
                msgb(3, 'Nova Atividade/Pendência', 'Já existe uma Pendência cadastrada com a mesma descrição e origem!', sf.popup)
        else:
            msgb(3, 'Nova Atividade/Pendência', 'Somente o Cód. Externo pode estar em branco!', sf.popup)

    def chrls2(sf):
        chrls(sf.ls2, f'select id, ds from vw_atividades_cadastros where og = {getpls(sf.ls1, 0)} and ds like "%{sf.en2.get()}%"')

    def clkls1(sf, ev):
        sf.chrls2()
        clrls(sf.ls3)
        sf.chrls4(1)
        sf.chrls5(1)
        clrls(sf.ls6)

    def clkls3(sf, ev):
        if len(sf.ls3.selection()) > 0:
            sf.bt3a.configure(state='normal')
        else:
            sf.bt3a.configure(state='disable')
        if len(sf.ls3.selection()) == 2:
            sf.bt3b.configure(state='normal')
        else:
            sf.bt3b.configure(state='disable')
        sf.chrls5(2)
        sf.chrls6(1)

    def prsbt4(sf, ed=0):
        sf.popup = Toplevel(sf.master)
        win(sf.popup, sf.master, 630, 174, 'Nova Atividade/Status')
        sf.f = frm(sf.popup, 0, 0)
        lb(sf.f, 0, 0, 'Descrição:')
        sf.e1 = en(sf.f, 0, 1, 18, [], 'we', cs=2)
        lb(sf.f, 2, 0, 'Início:')
        sf.c1 = cb(sf.f, 2, 1, 14, [('<<ComboboxSelected>>', sf.clkc1)])
        sf.c1['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'atividades_inicio')
        lb(sf.f, 2, 2, 'Hora:')
        sf.e2 = en(sf.f, 2, 3, 6, [('<FocusOut>', sf.oute24)], state='disable', justify=RIGHT)
        lb(sf.f, 3, 0, 'Responsável:')
        sf.c2 = cb(sf.f, 3, 1, 14, [('<<ComboboxSelected>>', sf.clkc2)])
        sf.c2['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'atividades_responsavel')
        sf.e3 = en(sf.f, 3, 2, 6, [('<FocusOut>', sf.oute34)], 'we', state='disable')
        sf.c3 = cb(sf.f, 3, 3, 32, [], state='disable')
        lb(sf.f, 4, 0, 'Prazo:')
        sf.c4 = cb(sf.f, 4, 1, 14, [('<<ComboboxSelected>>', sf.clkc4)])
        sf.c4['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'atividades_prazo')
        lb(sf.f, 4, 2, 'Dia(s)/Hr(s):')
        sf.e4 = en(sf.f, 4, 3, 6, state='disable', justify=RIGHT)
        lb(sf.f, 5, 0, 'Tempo:')
        sf.c5 = cb(sf.f, 5, 1, 14, state='disable')
        sf.c5['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'atividades_tempo')
        lb(sf.f, 5, 2, 'Chamada:')
        sf.e5 = en(sf.f, 5, 3, 33, [], 'we')
        bt(sf.f, 6, 2, 'Salvar', lambda a=ed: sf.prsb4a(a), 6, E, cs=2)
        if ed == 1:
            nm = getpls(sf.ls4, 1)
            sf.e1.insert(0, nm[0:nm.find('/')])
            sf.c1.set(getpls(sf.ls4, 7))
            sf.clkc1(1)
            sf.c2.set(getpls(sf.ls4, 6))
            sf.clkc2(1)
            sf.e2.insert(0, getpls(sf.ls4, 8))
            sf.c3.set(getpls(sf.ls4, 2))
            sf.clkc3(1)
            sf.c4.set(getpls(sf.ls4, 3))
            sf.c5.set(getpls(sf.ls4, 4))
            sf.clkc5(1)
            sf.e4.insert(0, getpls(sf.ls4, 9))
            sf.c6.set(getpls(sf.ls4, 5))
            sf.e5.insert(0, getpls(sf.ls4, 14))

    def chke4(sf, d, v):
        if d != '1':
            return True
        try:
            return v.isnumeric()
        except ValueError:
            return False

    def clkc4(sf, ev):
        if getpcb(sf.c4) == 1:
            sf.e4.delete(0, END)
            sf.e4.configure(state='disable')
            sf.c5.set('')
            sf.c5.configure(state='disable')
        else:
            sf.e4.configure(state='normal')
            sf.c5.configure(state='readonly')

    def clkc2(sf, ev):
        if getpcb(sf.c2) == 1:
            sf.e3.configure(state='normal')
            sf.c3.configure(state='readonly')
        else:
            sf.e3.delete(0, END)
            sf.e3.configure(state='disable')
            sf.c3.set('')
            sf.c3.configure(state='disable')

    def oute34(sf, ev):
        sf.c3['values'] = ''
        sf.c3['values'] = cnx.sqlcb(cnx(), 'id', 'ds', 'vw_postonmr', ' where ds like "%' + sf.e3.get() + '%"')

    def oute24(sf, ev):
        try:
            hr = datetime.strptime(sf.e2.get(), '%H:%M')
            sf.e2.delete(0, END)
            sf.e2.insert(0, hr.strftime('%H:%M'))
        except:
            sf.e2.focus_force()

    def clkc1(sf, ev):
        if getpcb(sf.c1) == 1:
            sf.e2.configure(state='normal')
        else:
            sf.e2.delete(0, END)
            sf.e2.configure(state='disable')

    def prsb4a(sf, ed):
        if getvct(sf.e1) and ((getvct(sf.c1, 1, 1) and getvct(sf.e2)) or (getvct(sf.c1, 1, 2) and getvct(sf.e2, v=0))) and ((getvct(sf.c2, 1, 1) and getvct(sf.c3)) or (getvct(sf.c2, 2, 1) and getvct(sf.c3, v=0))) and ((getvct(sf.c4, 1, 1) and getvct(sf.e4, v=0) and getvct(sf.c5, v=0)) or (getvct(sf.c4, 2, 1) and getvct(sf.e4) and getvct(sf.c5))):
            if getpcb(sf.c2) == 1:
                w = f'where ds = {getven(sf.e1)} and id_ar = {getpcb(sf.c2)} and idp = {getpcb(sf.c3)}'
            else:
                w = f'where ds = {getven(sf.e1)} and id_ar = {getpcb(sf.c2)}'
            if not cnx.sqlexist3(cnx(), 'ds', 'atividades_status', w):
                if ed == 0:
                    cnx.sqlcmd(cnx(), f'call prcInsAtivSs({getven(sf.e1)}, {getpcb(sf.c1)}, {getven(sf.e2)}, {getpcb(sf.c2)}, {getpcb(sf.c3)}, {getpcb(sf.c4)}, {getven(sf.e4, 2)}, {getpcb(sf.c5)}, {getven(sf.e5)})')
                sf.chrls4(1)
                if getpcb(sf.c2) == 1:
                    locsells(sf.ls4, 1, sf.e1.get() + '/' + getdscb(sf.c2) + '/' + getdscb(sf.c3))
                else:
                    locsells(sf.ls4, 1, sf.e1.get() + '/' + getdscb(sf.c2))
                sf.popup.destroy()
            else:
                msgb(3, 'Nova Atividade/Status', 'Já existe um Status cadastrado com a mesma descrição e responsabilidade!', sf.popup)
        else:
            msgb(3, 'Nova Atividade/Status', 'Todos os campos desbloqueados devem ser preenchidos!', sf.popup)

    def clkc21(sf, ev):
        if getpcb(sf.c2) == 3:
            sf.c3.configure(state='readonly')
        else:
            sf.c3.configure(state='disable')
            sf.c3.set('')

    def clkls2(sf, ev):
        sf.chrls3(1)
        sf.chrls4(2)

    def chrls3(sf, ev):
        sf.bt3a.configure(state='disable')
        sf.bt3b.configure(state='disable')
        chrls(sf.ls3, f'select * from vw_atividades_status_v where og = {getpls(sf.ls2, 0)}')

    def chrls4(sf, op): #op opção: 1=seleciona tudo / 2=seleciona com base no cadastro
        a = 'select * from vw_atividades_status'
        if op == 2:
            a = f'{a} where id not in (select id_as from atividades_status_v where og = {getpls(sf.ls2, 0)})'
        chrls(sf.ls4, a)

    def chrls5(sf, op): #op opção: 1=seleciona tudo / 2=seleciona com base no cadastro
        a = 'select * from vw_atividades_pendencia'
        if op == 2:
            a = f'{a} where id not in (select id_ap from atividades_pendencia_v where og = {getpls(sf.ls2, 0)} and id_as = {getpls(sf.ls3, 5)})'
        chrls(sf.ls5, a)

    def chrls6(sf, ev):
        chrls(sf.ls6, f'select * from vw_atividades_pendencia_v where og = {getpls(sf.ls2, 0)} and id_as = {getpls(sf.ls3, 5)}')

    def prsbt2a(sf):
        pass

    def prsbt2(sf):
        if len(sf.ls1.selection()) > 0:
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 446, 202, 'Nova Atividade/Detalhe')
            sf.f = frm(sf.popup, 0, 0)
            lb(sf.f, 0, 0, 'Nome:')
            sf.e1 = en(sf.f, 0, 1, 18, [], 'we')
            sf.fa = fr(sf.f, 1, 0, cs=2)
            lb(sf.fa, 0, 0, 'Grupo Ativ.:')
            sf.c1 = cb(sf.fa, 1, 0, 14)
            sf.c1['values'] = cnx.qcb(cnx(), 'id', 'ds', 'gestao_atividades')
            lb(sf.fa, 0, 1, 'Cliente:')
            sf.c2 = cb(sf.fa, 1, 1, 15)
            sf.c2['values'] = cnx.qcb(cnx(), 'id', 'ds', 'gestao_clientes')
            lb(sf.fa, 0, 2, 'Segmento:')
            sf.c3 = cb(sf.fa, 1, 2, 14)
            sf.c3['values'] = cnx.qcb(cnx(), 'id', 'ds', 'gestao_segmentos')
            lb(sf.f, 2, 0, 'Subatividade de:')
            sf.c4 = cb(sf.f, 2, 1, 34, [], 'we')
            sf.c4['values'] = cnx.qcb(cnx(), 'id', 'nm', 'atividades_cadastros')
            lb(sf.f, 3, 0, 'Periodicidade:')
            sf.c5 = cb(sf.f, 3, 1, 34, [], 'we')
            sf.c5['values'] = cnx.qcb(cnx(), 'id', 'ds', 'atividades_peoridicidade')
            lb(sf.f, 4, 0, 'Ref. Externa.:')
            sf.e2 = en(sf.f, 4, 1, 18, [], 'we')
            sf.prsb2 = bt(sf.f, 5, 1, 'Salvar', sf.prsb2, 6, E)
        else:
            msgb(3, 'Nova Atividade/Detalhe', 'É necessário selecionar uma Macro Atividade!', sf.master)

    def prsb2(sf):
        if len(sf.e1.get()) > 0 or len(sf.c1.get()) > 0 or len(sf.c2.get()) > 0 or len(sf.c3.get()) > 0 or len(sf.c5.get()) > 0 or len(sf.e2.get()) > 0:
                a = sf.c1.get()
                a = a[a.find('-')+2:]
                b = sf.c2.get()
                b = b[b.find('-')+2:]
                c = sf.c3.get()
                c = c[c.find('-')+2:]
                d = f'{sf.e1.get()}/{a}/{b}/{c}'
                if not cnx.sqlexist3(cnx(), 'ds', 'vw_atividades_cadastros', f'where og = {getpls(sf.ls1, 0)} and ds = "{d}"'):
                    cnx.sqlcmd(cnx(), f'call prcInsAtivCad({getpls(sf.ls1, 0)}, "{sf.e1.get()}", {getpcb(sf.c4, 1)}, {getpcb(sf.c5, 1)}, {getpcb(sf.c1, 1)}, {getpcb(sf.c2, 1)}, {getpcb(sf.c3, 1)}, "{sf.e2.get()}")')
                    sf.en2.delete(0, END)
                    sf.chrls2()
                    locsells(sf.ls2, 1, d)
                    sf.popup.destroy()
                else:
                    msgb(3, 'Nova Atividade/Detalhe', f'Já existe uma Micro Atividade cadastrada com o nome {d}!', sf.popup)
        else:
            msgb(3, 'Nova Atividade/Detalhe', 'Apenas o campo "Subatividade de" pode ser vazio!', sf.popup)

    def clkls4(sf, ev):
        try:
            if getpls(sf.ls4, 1) != '':
                sf.bt4a.configure(state='normal')
        except:
            sf.bt4a.configure(state='disable')

    def dblls5(sf, ev):
        if len(sf.ls2.selection()) > 0 and len(sf.ls3.selection()) > 0:
            cnx.sqlcmd(cnx(), f'call prcInsAtivPdV({getpls(sf.ls2, 0)}, {getpls(sf.ls3, 5)}, {getpls(sf.ls5, 0)})')
            sf.clkls3(1)
        else:
            msgb(3, 'Vínculo de Pendências', 'É necessário selecionar um Cadastro Detalhe e um Vínculo Status!', sf.master)

    def dblls4(sf, ev):
        if len(sf.ls2.selection()) > 0:
            cnx.sqlcmd(cnx(), f'call prcInsAtivSsOd({getpls(sf.ls2, 0)}, {getpls(sf.ls4, 0)})')
            sf.clkls2(1)
        else:
            msgb(3, 'Vincular status', 'Nenhum cadastro detalhe selecionado!', sf.master)

    def dblls3(sf, ev):
        cnx.sqlcmd(cnx(), f'call prcInsAtivSsOdD({getpls(sf.ls3, 0)}, {getpls(sf.ls3, 4)})')
        sf.clkls2(1)

    def dclls6(sf, ev):
        cnx.sqlcmd(cnx(), 'delete from ' + getpls(sf.ls1, 2) + '_pd_v where id =' + getpls(sf.ls6, 0))
        f = len(sf.ls6.get_children())
        n = int(sf.ls6.selection()[0])
        sf.chrls6(1)
        if n == f:
            n -=1
        if n > 0:
            sf.ls6.selection_set(n)
            sf.ls6.focus(n)
            sf.ls6.see(n)

    def pressbt2(sf):
        pass

    def prsbt3a(sf):
        sf.popup = Toplevel(sf.master)
        win(sf.popup, sf.master, 330, 270, 'Ordem Status/Próximos')
        sf.f = frm(sf.popup, 0, 0)
        lb(sf.f, 0, 0, getpls(sf.ls3, 2))
        sf.l31 = ls(sf.f, 1, 0, 8)
        carrega_lista(1, 'vw_atividades_status_v', sf.l31, sel=2)
        chrls(sf.l31, f'select * from vw_atividades_status_v where og = {getpls(sf.ls2, 0)}')
        bt(sf.f, 2, 0, 'Salvar', sf.prsb31, 6, E, cs=2)
    
    def prsb31(sf):
        if len(sf.l31.selection()) > 0:
            if len(sf.l31.selection()) == 1 and getpls(sf.ls3, 1) == getpls(sf.l31, 1):
                cnx.sqlcmd(cnx(), f'update atividades_status_v set p = "-" where id = {getpls(sf.ls3, 0)}')
            else:
                a = str(getlls(sf.l31, 1)).replace("'", '').replace('[', '').replace(']', '').replace(' ', '')
                cnx.sqlcmd(cnx(), f'update atividades_status_v set p = "{a}" where id = {getlls(sf.ls3, 0)[0]}')
            sf.chrls3(1)
            sf.popup.destroy()
        else:
            msgb(3, 'Ordem Status/Próximos', 'Selecione pelo menso um status!', sf.popup)

    def prsbt3b(sf):
        a = getlls(sf.ls3, 0)
        b = getlls(sf.ls3, 1)
        cnx.sqlcmd(cnx(), f'call prcInsAtivSsOdDA({a[0]}, {a[1]}, {b[0]}, {b[1]})')
        sf.chrls3(1)

    def canen1(self):
        if self.bt1['state']:
            self.bt1.configure(text='Editar')
            self.bt1.configure(state='disable')
            self.en2.delete(0, END)

    def canen6(self):
        if self.bt2['state']:
            self.bt2.configure(text='Editar')
            self.bt2.configure(state='disable')
            self.en6.delete(0, END)

    def carregals3(self):
        carrega_lista(3, 'select b.id, b.id_ss, a.ds, b.od from ' + str(
            self.ls1.item(self.ls1.focus())['values'][2]) + '_ss a join ' + str(
            self.ls1.item(self.ls1.focus())['values'][2]) + '_od b on (a.id = b.id_ss) where b.`or` = ' + str(
            self.ls2.item(self.ls2.focus())['values'][0]) + ' order by b.od', self.ls3)

    def getls4(self):
        self.bt3.configure(state='normal')
        if self.bt3['text'] == 'Salvar':
            self.bt3.configure(text='Editar')
        self.editdis()
        self.cb3.set(self.ls4.item(self.ls4.focus())['values'][2])
        self.cb4.set(self.ls4.item(self.ls4.focus())['values'][3])
        self.cb5.set(self.ls4.item(self.ls4.focus())['values'][4])
        self.cb6.set(self.ls4.item(self.ls4.focus())['values'][5])
        self.cb2.set(self.ls4.item(self.ls4.focus())['values'][6])
        self.cb1.set(self.ls4.item(self.ls4.focus())['values'][7])
        self.en3.configure(state='normal')
        self.en3.delete(0, END)
        self.en3.insert(0, self.ls4.item(self.ls4.focus())['values'][8])
        self.en3.configure(state='disable')
        self.en5.configure(state='normal')
        self.en5.delete(0, END)
        self.en5.insert(0, self.ls4.item(self.ls4.focus())['values'][9])
        self.en5.configure(state='disable')
        self.ckvar.set(int(self.ls4.item(self.ls4.focus())['values'][11]))
        self.ckvar1.set(int(self.ls4.item(self.ls4.focus())['values'][10]))
        self.en7.configure(state='normal')
        self.en7.delete(0, END)
        self.en7.insert(0, self.ls4.item(self.ls4.focus())['values'][12])
        self.en7.configure(state='disable')

    def editdis(self):
        self.cb1.configure(state='disable')
        self.cb2.configure(state='disable')
        self.cb3.configure(state='disable')
        self.cb4.configure(state='disable')
        self.cb5.configure(state='disable')
        self.cb6.configure(state='disable')
        self.en3.configure(state='disable')
        self.en4.configure(state='disable')
        self.en5.configure(state='disable')
        self.en7.configure(state='disable')
        self.ck1.configure(state='disable')
        self.ck2.configure(state='disable')
        self.ck3.configure(state='disable')

    def selcb1(self):
        try:
            v10 = int(self.ls4.item(self.ls4.focus())['values'][10])
        except:
            v10 = 0
        try:
            v11 = int(self.ls4.item(self.ls4.focus())['values'][11])
        except:
            v11 = 0
        try:
            v13 = int(self.ls4.item(self.ls4.focus())['values'][12])
        except:
            v13 = 0
        try:
            v6 = str(self.ls4.item(self.ls4.focus())['values'][6])
        except:
            v6 = '- - -'
        try:
            vcb1 = int(self.cb1.get()[:self.cb1.get().find('-') - 1])
        except:
            vcb1 = 0
        if vcb1 == 0:
            self.ckvar.set(False)
            self.ck1.configure(state='disable')
            self.ckvar1.set(False)
            self.ck2.configure(state='disable')
            self.ckvar2.set(False)
            self.ck3.configure(state='disable')
        elif vcb1 == 1:
            self.ckvar.set(False)
            self.ck1.configure(state='disable')
            self.ckvar1.set(False)
            self.ck2.configure(state='disable')
            self.ckvar2.set(False)
            self.ck3.configure(state='disable')
            self.cb2.configure(state='disable')
            self.cb2.set('2 - Atual')
            self.selcb2()
        elif vcb1 == 2:
            self.ckvar.set(v11)
            self.ck1.configure(state='normal')
            self.ckvar1.set(v10)
            self.ck2.configure(state='normal')
            self.ckvar2.set(v13)
            self.ck3.configure(state='normal')
            self.cb2.configure(state='normal')
            self.cb2.set(v6)
            self.selcb2()

    def selcb2(self):
        try:
            v8 = str(self.ls4.item(self.ls4.focus())['values'][8])
        except:
            v8 = ''
        try:
            vcb2 = int(self.cb2.get()[:self.cb2.get().find('-') - 1])
        except:
            vcb2 = 0
        if vcb2 == 0 or vcb2 == 1:
            self.en3.configure(state='normal')
            self.en3.delete(0, END)
            self.en3.insert(0, v8)
        else:
            self.en3.delete(0, END)
            self.en3.configure(state='disable')

    def selcb3(self):
        try:
            v3 = str(self.ls4.item(self.ls4.focus())['values'][3])
        except:
            v3 = '- - -'
        try:
            vcb3 = int(self.cb3.get()[:self.cb3.get().find('-') - 1])
        except:
            vcb3 = 0
        if vcb3 == 0 or vcb3 == 1:
            self.en4.configure(state='normal')
            self.cb4.set(v3)
            self.cb4.configure(state='normal')
        else:
            self.en4.configure(state='normal')
            self.en4.delete(0, END)
            self.en4.configure(state='disable')
            self.cb4.set('- - -')
            self.cb4.configure(state='disable')

    def selcb5(self):
        try:
            v9 = str(self.ls4.item(self.ls4.focus())['values'][9])
        except:
            v9 = ''
        try:
            v5 = str(self.ls4.item(self.ls4.focus())['values'][5])
        except:
            v5 = ''
        try:
            vcb5 = int(self.cb5.get()[:self.cb5.get().find('-') - 1])
        except:
            vcb5 = 0
        if vcb5 == 0 or vcb5 == 1:
            self.en5.configure(state='normal')
            self.en5.delete(0, END)
            self.en5.configure(state='disable')
            self.cb6.configure(state='normal')
            self.cb6.set('- - -')
            self.cb6.configure(state='disable')
        else:
            self.en5.configure(state='normal')
            self.en5.delete(0, END)
            self.en5.insert(0, v9)
            self.cb6.configure(state='normal')
            self.cb6.set(v5)

    def carcb4(self):
        self.cb4.set('')
        self.cb4['values'] = cnx.sqlcb1(cnx(), 'id', 'ds', 'vw_postonmr', self.en4.get())
        self.en4.delete(0, END)

class ctmt():
    def __init__(self, master, root):
        self.ls1var = IntVar()
        self.style = ttk.Style()
        self.style.configure('Treeview.Heading', font=font3)
        self.master = master
        self.master['bg'] = cor_f
        l_tela = self.master.winfo_screenwidth()
        a_tela = self.master.winfo_screenheight()
        l_ws = 960  # self.master.winfo_width()
        a_ws = 660  # self.master.winfo_height()
        posx = l_tela / 2 - l_ws / 2
        posy = a_tela / 2 - a_ws / 1.85
        self.master.resizable(width=0, height=0)
        self.master.transient(root)
        self.master.focus_force()
        self.master.grab_set()
        self.master.geometry("%dx%d+%d+%d" % (l_ws, a_ws, posx, posy))
        self.master.iconphoto(False, tk.PhotoImage(file=icon))
        self.master.title('Controle de Materiais para ' + vNm_r + ' | lvflwX ' + vVer1)

        self.fr1 = Frame(self.master, bg=cor_f)
        self.fr2 = Frame(self.fr1, borderwidth=1, relief='ridge', bg=cor_f)

        self.lb1 = Label(self.fr2, text='Pesquisar', bg=cor_f, font=font2).grid(row=0, column=0, sticky=W,
                                                                                padx=(4, 0))
        self.en1 = Entry(self.fr2, font=font2, width=22)
        self.en1.bind('<Tab>', lambda event: self.carls1())
        self.en1.grid(row=1, column=0, sticky='we', padx=(4, 0))
        self.lb2 = Label(self.fr2, text='Ação', bg=cor_f, font=font2).grid(row=0, column=1, sticky=W,
                                                                           padx=(4, 0))
        self.cb1 = ttk.Combobox(self.fr2, width=16)
        self.cb1['values'] = cnx.sqlcb(cnx(), 'id', 'ds', 'estoque_acao')
        self.cb1.grid(row=1, column=1, sticky=W, padx=(4, 0))
        self.lb3 = Label(self.fr2, text='Destinatário', bg=cor_f, font=font2).grid(row=0, column=2, sticky=W,
                                                                                   padx=(4, 0))
        self.cb2 = ttk.Combobox(self.fr2, width=16)
        self.cb2.grid(row=1, column=2, sticky=W, padx=(4, 0))
        self.ls1 = ttk.Treeview(self.fr2, height=12)
        carrega_lista(1, 'vw_estoque_saldo', self.ls1)
        self.ls1.bind('<<TreeviewSelect>>', lambda event: self.getls1())
        self.ls1.grid(row=2, column=0, columnspan=4, sticky='nswe', padx=(4, 0), pady=(4, 0))

        self.fr2.grid(row=0, column=0, sticky=W, ipadx=2, ipady=2)
        self.fr1.grid(padx=10, pady=10)

    def carls1(self):
        pass

class gspo():
    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 960, 660, 'Gestão de Projetos e Obras')
        sf.frm = frm(master, 0, 0)
        sf.fr1 = fr(sf.frm, 0, 0)
        sf.bt1 = bt(sf.fr1, 0, 0, 'Passivo', lambda a=1: sf.prsbt(a))
        sf.en1 = en(sf.fr1, 0, 1, 6, font=font3, state='readonly', justify=CENTER)
        a1 = cnx.q(cnx(), 'select * from vw_b2b_base_qt_f')
        insen(sf.en1, a1)
        sf.bt2 = bt(sf.fr1, 0, 2, 'Novas', lambda a=2: sf.prsbt(a))
        sf.en2 = en(sf.fr1, 0, 3, 6, font=font3, state='readonly', justify=CENTER)
        a2 = cnx.q(cnx(), 'select * from vw_b2b_base_qt_d')
        insen(sf.en2, a2)
        sf.bt3 = bt(sf.fr1, 0, 4, 'Erros', lambda a=3: sf.prsbt(a))
        sf.en3 = en(sf.fr1, 0, 5, 6, font=font3, state='readonly', justify=CENTER)
        a3 = cnx.q(cnx(), 'select * from vw_b2b_base_qt_e')
        insen(sf.en3, a3)
        #sf.fr1a = fr(sf.frm, 0, 1)
        sf.bt4 = bt(sf.frm, 0, 1, 'Tratar', sf.prsbt4, 8, E, state='disable')
        sf.fr2 = fr(sf.frm, 1, 0, cs=2)
        sf.ls1 = ls(sf.fr2, 1, 0, 1, [('<<TreeviewSelect>>', sf.prsls1)], 'we')
        carrega_lista(1, 'vw_b2b_base1_c', sf.ls1)
        chrls(sf.ls1, f'select * from vw_b2b_base1_c where idp = {vPs}')
    
    def prsls1(sf, e):
        if len(sf.ls1.selection()) > 0:
            sf.bt4.configure(state='normal')

    def prsbt4(sf):
        if getpls(sf.ls1, 7) == '-' or getpls(sf.ls1, 8) == 'NA' or getpls(sf.ls1, 9) == '-':
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 318, 200, 'Tratar Projeto/Obra')
            sf.f = frm(sf.popup, 0, 0)
            sf.f1 = fr(sf.f, 0, 0)
            sf.l1 = lb(sf.f1, 0, 0, 'Serviço:')
            sf.e1 = en(sf.f1, 0, 1, 26)
            insen(sf.e1, getpls(sf.ls1, 4))
            sf.l2 = lb(sf.f1, 1, 0, 'GRAM:')
            sf.e2 = en(sf.f1, 1, 1, 26)
            insen(sf.e2, getpls(sf.ls1, 7))
            sf.l3 = lb(sf.f1, 2, 0, 'Protocolo:')
            sf.e3 = en(sf.f1, 2, 1, 26)
            insen(sf.e3, getpls(sf.ls1, 8))
            sf.l4 = lb(sf.f1, 3, 0, 'Data/Hora:')
            sf.e4 = en(sf.f1, 3, 1, 26)
            insen(sf.e4, getpls(sf.ls1, 9))
        

    def prsbt(sf, op):
        t = cnx.q(cnx(), f'select count(*) from b2b_base1 where idp = {vPs}')
        if t == 0:
            cnx.sqlcmd(cnx(), f'call prcNovoProjeto({op}, {vPs})')
            if op == 1:
                a1 = cnx.q(cnx(), 'select * from vw_b2b_base_qt_f')
                insen(sf.en1, a1)
            elif op == 2:
                a2 = cnx.q(cnx(), 'select * from vw_b2b_base_qt_d')
                insen(sf.en2, a2)
            else:
                a3 = cnx.q(cnx(), 'select * from vw_b2b_base_qt_e')
                insen(sf.en3, a3)
            chrls(sf.ls1, f'select * from vw_b2b_base1_c where idp = {vPs}')
        else:
            msgb(3, 'Projeto/Obra', 'Já existe um projeto/obra selecionado para tratamento!', sf.master)

class qntc():
    def __init__(self, master, root):
        self.ls1var = IntVar()
        self.style = ttk.Style()
        self.style.configure('Treeview.Heading', font=font3)
        self.master = master
        self.master['bg'] = cor_f
        l_tela = self.master.winfo_screenwidth()
        a_tela = self.master.winfo_screenheight()
        l_ws = 960  # self.master.winfo_width()
        a_ws = 660  # self.master.winfo_height()
        posx = l_tela / 2 - l_ws / 2
        posy = a_tela / 2 - a_ws / 1.85
        self.master.resizable(width=0, height=0)
        self.master.transient(root)
        self.master.focus_force()
        self.master.grab_set()
        self.master.geometry("%dx%d+%d+%d" % (l_ws, a_ws, posx, posy))
        self.master.iconphoto(False, tk.PhotoImage(file=icon))
        self.master.title('Quantificação para ' + vNm_r + ' | lvflwX ' + vVer1)

        self.fr1 = Frame(self.master, bg=cor_f)
        self.fr2 = Frame(self.fr1, borderwidth=1, relief='ridge', bg=cor_f)
        self.tx1 = Text(self.fr2)
        self.tx1.grid(row=0, column=0, sticky='nswe', padx=(4, 0))
        self.bt1 = Button(self.fr2, text='Teste', font=font2, width=6, command=self.pressbt1)
        self.bt1.grid(row=2, column=0, sticky='en', padx=(4, 0), pady=(4, 0))
        self.fr2.grid(row=0, column=0, sticky=W, ipadx=2, ipady=2)
        self.fr1.grid(padx=10, pady=10)

    def pressbt1(self):
        while self.tx1.get(1.0, '1.end') != '':
            print(self.tx1.get(1.0, '1.end'))
            self.tx1.delete(1.0, 2.0)

class rspl():

    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 960, 660, 'Responsabilidade Planta', vNm_r)
        sf.frm = frm(master, 0, 0)
        sf.fr1 = fr(sf.frm, 0, 0, cs=2)
        
        lb(sf.fr1, 0, 0, 'Agrupamento')
        sf.cb1 = cb(sf.fr1, 1, 0, 20, [('<<ComboboxSelected>>', sf.prscb1)])
        sf.cb1['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'vw_planta_grupo_resp')
        
        lb(sf.fr1, 0, 1, 'Cliente')
        sf.cb2 = cb(sf.fr1, 1, 1, 20, [('<<ComboboxSelected>>', sf.prscb2)])
        
        lb(sf.fr1, 0, 2, 'Planta')
        sf.cb3 = cb(sf.fr1, 1, 2, 20, [('<<ComboboxSelected>>', sf.prscb3)])
        
        lb(sf.fr1, 0, 3, 'Conjunto')
        sf.cb4 = cb(sf.fr1, 1, 3, 20, [('<<ComboboxSelected>>', sf.prscb4)])
        
        lb(sf.fr1, 0, 4, 'Responsável')
        sf.cb5 = cb(sf.fr1, 1, 4, 21)
        sf.cb5['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'vw_planta_resp_posto')
        
        sf.fr2 = fr(sf.frm, 1, 0)
        lb(sf.fr2, 0, 0, 'Disponíveis')
        sf.ls1 = ls(sf.fr2, 1, 0, 18, [('<Double-1>', sf.dplls1)])
        carrega_lista(1, 'vw_planta_conj', sf.ls1)
        sf.fr3 = fr(sf.frm, 1, 1)
        lb(sf.fr3, 0, 0, 'Vinculados')
        sf.ls2 = ls(sf.fr3, 1, 0, 18)
        carrega_lista(1, 'vw_planta_resp', sf.ls2)

    def prscb1(sf, ev):
        sf.cb2['values'] = ''
        sf.cb2.set('')
        sf.cb3['values'] = ''
        sf.cb3.set('')
        sf.cb4['values'] = ''
        sf.cb4.set('')
        sf.carrega_ls2()
        sf.cb2['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'vw_planta_cliente_resp')

    def prscb2(sf, ev):
        sf.cb3['values'] = ''
        sf.cb3.set('')
        sf.cb4['values'] = ''
        sf.cb4.set('')
        sf.carrega_ls2()
        sf.cb3['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'vw_planta_tipo_resp')

    def prscb3(sf, ev):
        sf.cb4['values'] = ''
        sf.cb4.set('')
        sf.carrega_ls2()
        sf.cb4['values'] = cnx.sqlcb2(cnx(), 'id', 'ds', 'planta_resp_conj')

    def prscb4(sf, ev):
        clrls(sf.ls1)
        v = getpcb(sf.cb4)
        if v == 1:
            carrega_lista(3, 'select id, ds from vw_planta_conj_gram where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ' and id not in (select coalesce(gram, "-") from planta_resp where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ')', sf.ls1)
        elif v == 2:
            carrega_lista(3, 'select id, ds, gram from vw_planta_conj_gra where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ' and id not in (select coalesce(gra, "-") from planta_resp where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ') and gram not in (select coalesce(gram, "-") from planta_resp where id_prc = 1 and id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ')', sf.ls1)
        elif v == 3:
            carrega_lista(3, 'select id, ds, loc, gra, gram from `vw_planta_conj_gra-loc` where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ' and loc not in (select coalesce(loc, "-") from planta_resp where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ') and gra not in (select coalesce(gra, "-") from planta_resp where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ') and gram not in (select coalesce(gram, "-") from planta_resp where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ')', sf.ls1)
        else:
            carrega_lista(3, 'select id, ds, gra, gram from vw_planta_conj_loc where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ' and id not in (select coalesce(loc, "-") from planta_resp where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ') and gra not in (select coalesce(gra, "-") from planta_resp where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ') and gram not in (select coalesce(gram, "-") from planta_resp where id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1) + ')', sf.ls1)
    
    def dplls1(sf, ev):
        if len(sf.cb1.get()) > 0 and len(sf.cb2.get()) > 0 and len(sf.cb3.get()) > 0 and len(sf.cb4.get()) > 0 and len(sf.cb5.get()) > 0:
            v = getpcb(sf.cb4)
            if v == 1:
                cnx.sqlcmd(cnx(), 'insert into planta_resp(id_sr, id_gc, id_pt, id_prc, idp, c, gram) values(' + getpcb(sf.cb1, 1) + ', ' + getpcb(sf.cb2, 1) + ', ' + getpcb(sf.cb3, 1) + ', ' + getpcb(sf.cb4, 1) + ', ' + getpcb(sf.cb5, 1) + ', "' + getpls(sf.ls1, 0) + '", "' + getpls(sf.ls1, 0) + '")')
            elif v == 2:
                cnx.sqlcmd(cnx(), 'insert into planta_resp(id_sr, id_gc, id_pt, id_prc, idp, c, gra, gram) values(' + getpcb(sf.cb1, 1) + ', ' + getpcb(sf.cb2, 1) + ', ' + getpcb(sf.cb3, 1) + ', ' + getpcb(sf.cb4, 1) + ', ' + getpcb(sf.cb5, 1) + ', "' + getpls(sf.ls1, 0) + '", "' + getpls(sf.ls1, 0) + '", "' + getpls(sf.ls1, 2) + '")')
            else:
                cnx.sqlcmd(cnx(), 'insert into planta_resp(id_sr, id_gc, id_pt, id_prc, idp, c, loc, gra, gram) values(' + getpcb(sf.cb1, 1) + ', ' + getpcb(sf.cb2, 1) + ', ' + getpcb(sf.cb3, 1) + ', ' + getpcb(sf.cb4, 1) + ', ' + getpcb(sf.cb5, 1) + ', "' + getpls(sf.ls1, 2) + '", "' + getpls(sf.ls1, 2) + '", "' + getpls(sf.ls1, 3) + '", "' + getpls(sf.ls1, 4) + '")')
            sf.prscb4(1)
            carrega_lista(2, 'vw_planta_resp', sf.ls2)
        else:
            msgb(1, 'Responsabilidade Planta', 'Nenhum campo pode estar vazio!', sf.master)

    def carrega_ls2(sf):
        if sf.cb1.get() != '' and sf.cb2.get() == ''  and sf.cb3.get() == '':
            chrls(sf.ls2, 'select * from vw_planta_resp where id_sr = ' + getpcb(sf.cb1, 1))
        elif sf.cb1.get() != '' and sf.cb2.get() != ''  and sf.cb3.get() == '':
            chrls(sf.ls2, 'select * from vw_planta_resp where id_sr = ' + getpcb(sf.cb1, 1) + ' and id_gc = ' + getpcb(sf.cb2, 1))
        elif sf.cb1.get() != '' and sf.cb2.get() != ''  and sf.cb3.get() != '':
            chrls(sf.ls2, 'select * from vw_planta_resp where id_sr = ' + getpcb(sf.cb1, 1) + ' and id_gc = ' + getpcb(sf.cb2, 1) + ' and id_pt = ' + getpcb(sf.cb3, 1))
        else:
            pass

class flrg():
    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 960, 660, 'Falta registro', vNm_r)
        sf.frm = frm(master, 0, 0)
        
        sf.fr1 = fr(sf.frm, 0, 0)
        sf.ls1 = ls(sf.fr1, 0, 0, 6, [('<<TreeviewSelect>>', sf.prsls1)])
        carrega_lista(0, 'vw_ponto_falta_registro_data1', sf.ls1)
        
        sf.fr2 = fr(sf.frm, 0, 1)
        
        sf.fr3 = fr(sf.frm, 1, 0, cs=2)
        sf.ls2 = ls(sf.fr3, 0, 0, 12)
        carrega_lista(1, 'vw_ponto_falta_registro', sf.ls2)
    
    def prsls1(sf, ev):
        chrls(sf.ls2, 'select * from vw_ponto_falta_registro where dt = "' + getpls(sf.ls1, 3) + '"')

class atjs():
    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 960, 660, 'Atividades e Justificativas')
        sf.frm = frm(master, 0, 0)
        sf.fr1 = fr(sf.frm, 0, 0)
        sp(sf.fr1, 0, 0, width=160)
        sf.ls1 = ls(sf.fr1, 1, 0, 3, [('<<TreeviewSelect>>', sf.prsls1)], 'we')
        carrega_lista(1, 'vw_atvd_datas', sf.ls1)
        sf.chrls1()
        sp(sf.fr1, 0, 1, width=160)
        sf.ls8 = ls(sf.fr1, 1, 1, 3, [('<<TreeviewSelect>>', sf.prsls8)], 'we')
        carrega_lista(1, 'vw_atvd_datas_fec', sf.ls8)
        sf.chrls8()
        sf.bt1 = bt(sf.fr1, 1, 2, 'Nova Ativ.', lambda a=1: sf.prsbt1(a))
        sf.bt6 = bt(sf.fr1, 1, 3, 'Incluir', lambda a=12: sf.prsbt1(a), state='disable')
        sf.bt2 = bt(sf.fr1, 1, 4, 'Encerrar', lambda a=2: sf.prsbt1(a), state='disable')
        sf.bt3 = bt(sf.fr1, 1, 5, 'Continuar', lambda a=3: sf.prsbt1(a), state='disable')
        sf.bt4 = bt(sf.fr1, 1, 6, 'Fluxo Pres.', sf.prsbt4)
        sf.bt5 = bt(sf.fr1, 1, 7, 'Finaliza Dia', sf.prsbt5)
        sf.fr2 = fr(sf.frm, 1, 0)
        sp(sf.fr2, 0, 0, width=160)
        sf.ls2 = ls(sf.fr2, 1, 0, 12, [('<<TreeviewSelect>>', sf.prsls2)], 'we', 2)
        carrega_lista(1, 'vw_atvd_pessoal_livre', sf.ls2)
        sp(sf.fr2, 0, 1, width=585)
        sf.ls3 = ls(sf.fr2, 1, 1, 12, [('<<TreeviewSelect>>', sf.prsls3)], 'we', 2)
        carrega_lista(1, 'vw_atvd', sf.ls3)
        sp(sf.fr2, 0, 2, width=160)
        sf.ls4 = ls(sf.fr2, 1, 2, 5, [], 'wens')
        carrega_lista(1, 'vw_atvd_pessoal_equip', sf.ls4)
        sf.ls7 = ls(sf.fr2, 2, 2, 5, [], 'wens')
        carrega_lista(1, 'vw_atvd_pessoal_equip_enc', sf.ls7)
        sf.fr3 = fr(sf.frm, 2, 0)
        sp(sf.fr3, 0, 0, width=460)
        lb(sf.fr3, 1, 0, 'Atividades disponíveis para agendamento', font=font3)
        sf.ls5 = ls(sf.fr3, 2, 0, 9, [], 'we')
        sp(sf.fr3, 0, 1, width=460)
        lb(sf.fr3, 1, 1, 'Ajustes necessários no RM', font=font3)
        sf.ls6 = ls(sf.fr3, 2, 1, 9, [], 'we')        

    def chrls1(sf):
        chrls(sf.ls1, f'select * from vw_atvd_datas where dt not in (select dt from atvd_fec where cd_pes = {str(vCd)})')

    def chrls8(sf):
        chrls(sf.ls8, f'select * from vw_atvd_datas_fec where cd_pes = {str(vCd)}')

    def prsbt5(sf):
        if len(sf.ls1.selection()) > 0:
            q1 = 'select count(id) from atvd where '
            q2 = f'ss = 1 and date_format(dthri, "%d/%m/%Y") = "{getpls(sf.ls1, 0)}"'
            a = cnx.csql(cnx(), q1 + q2)
            if int(a[0][0]) == 0:
                b = cnx.csql(cnx(), f'select date_format(min(dt), "%Y-%m-%d") from vw_atvd_datas where dt not in (select dt from atvd_fec where cd_pes = {str(vCd)})')
                if getpls(sf.ls1, 1) == b[0][0]:
                    if msgb(4, 'Finaliza o dia', f'Confirma a finalização do dia {getpls(sf.ls1, 0)}?', sf.master):
                        cnx.sqlcmd(cnx(), f'insert into atvd_fec(cd_pes, dt) values({str(vCd)}, "{getpls(sf.ls1, 1)}")')
                        sf.chrls1()
                        sf.chrls8()
                else:
                    c = datetime.strptime(a[0][0], '%Y-%m-%d')
                    c = c.strftime('%d/%m/%Y')
                    msgb(3, 'Finaliza o dia', f'É necessário finalizar a data {c} primeiro!', sf.master)
            else:
                msgb(3, 'Finaliza o dia', f'Existem {a[0][0]} atividades abertas em {getpls(sf.ls1, 0)}, para finalizar o dia é necessário encerrar estas atividades!', sf.master)    
        else:
            msgb(3, 'Finaliza o dia', 'É necessário selecionar uma data aberta para finalização!', sf.master)
            
    def prsbt4(sf):
        if len(sf.ls1.selection()) > 0 and len(sf.ls2.selection()) > 0:
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 372, 194, 'Informar ausência')
            sf.f = frm(sf.popup, 0, 0)
            sf.f1 = fr(sf.f, 0, 0)
            lb(sf.f1, 0, 0, 'Colaborador:')
            sf.e1 = en(sf.f1, 0, 1, 30, state='readonly')
            insen(sf.e1, getpls(sf.ls2, 1))
            lb(sf.f1, 1, 0, 'Ausência:')
            sf.c1 = cb(sf.f1, 1, 1, 24, [('<<ComboboxSelected>>', sf.clkc41)])
            sf.c1['values'] = cnx.qcb(cnx(), 'id', 'ds', 'ponto_comp', 'ds')
            lb(sf.f1, 2, 0, 'Data/Hora I:')
            lb(sf.f1, 3, 0, 'Data/Hora F:')
            sf.f1b = fr(sf.f1, 2, 1, rs=2)
            sf.e2 = en(sf.f1b, 0, 1, 10, state='readonly')
            insen(sf.e2, getpls(sf.ls1, 0))
            sf.e4 = en(sf.f1b, 0, 2, 5, [('<FocusOut>', lambda e: isdthr(2, sf.e4, sf.popup))], state='readonly')
            sf.e5 = en(sf.f1b, 1, 1, 10, state='readonly')
            insen(sf.e5, getpls(sf.ls1, 0))
            sf.e6 = en(sf.f1b, 1, 2, 5, [('<FocusOut>', lambda e: isdthr(2, sf.e6, sf.popup))], state='readonly')
            sf.b43 = bt(sf.f1b, 1, 3, '-1', lambda: sf.prsb43(-1), 2, state='disable')
            sf.b44 = bt(sf.f1b, 1, 4, '+1', lambda: sf.prsb43(+1), 2, state='disable')
            sf.f1a = fr(sf.f1, 4, 0, cs=2)
            lb(sf.f1a, 0, 0, 'Anexo:')
            sf.e3 = en(sf.f1a, 0, 1, 30, state='readonly')
            sf.b42 = bt(sf.f1a, 0, 2, 'Abrir', sf.prsb42, state='disable')
            sf.f2 = fr(sf.f, 1, 0, E)
            bt(sf.f2, 0, 0, 'Cancelar', sf.popup.destroy)
            sf.b41 = bt(sf.f2, 0, 1, 'Salvar', sf.prsb41)
        else:
            msgb(3, 'Nova Atividade', 'É necessário selecionar uma data aberta e um colaborador!', sf.master)

    def prsb43(sf, o):
        t = datetime.strptime(sf.e5.get(), '%d/%m/%Y') + timedelta(days=o)
        insen(sf.e5, t.strftime('%d/%m/%Y'))
        if sf.e2.get() == sf.e5.get():
            sf.b43.configure(state='disable')
        else:
            sf.b43.configure(state='normal')

    def clkc41(sf, e):
        a = getpcb(sf.c1)
        if a in (1, 2, 6, 8):
            sf.b42.configure(state='disable')
            insen(sf.e3, '')
        else:
            sf.b42.configure(state='normal')
        if a in (1, 2, 3, 4, 5, 6, 7, 11):
            sf.b44.configure(state='normal')
        else:
            sf.b44.configure(state='disable')
        if a in (8, 9, 10):
            sf.e4.configure(state='normal')
            sf.e6.configure(state='normal')
            insen(sf.e4, '')
            insen(sf.e6, '')
        else:
            sf.e4.configure(state='readonly')
            sf.e6.configure(state='readonly')
            insen(sf.e4, '00:00')
            insen(sf.e6, '23:59')
    
    def prsb42(sf):
        a = open_file('./', 'Abrir anexo', (('JPG', '*.jpg'), ('PNG', '*.png')))
        insen(sf.e3, a[0])
        sf.e3.xview_moveto(1)
    
    def prsb41(sf):
        if len(sf.c1.get()) > 0:
            if len(sf.e3.get()) > 0:
                with open(sf.e3.get(), 'rb') as f:
                    vAnexo = f.read()
            else:
                vAnexo = 'NULL'
            if len(vAnexo) < 2000001:
                cnx.sqlcmdt(cnx(), getpls(sf.ls2, 0), f'{sf.e2.get()} {sf.e4.get()}', f'{sf.e5.get()} {sf.e6.get()}', getpcb(sf.c1, 1), vAnexo)
                sf.popup.destroy()
                sf.prsls1(1)
            else:
                pass
        else:
            msgb(3, 'Informar ausência', 'É necessário selecionar uma ausência!', sf.popup)
    
    def chrls2(sf):
        q1 = 'select cd, ds, c, s, dt from vw_atvd_pessoal_livre where '
        if vS == None or vS == '':
            q2 = f'c = {str(vC)}'
        else:
            q2 = f's = {str(vS)} and cd <> {str(vCd)}'
        q3 = f' and concat(cd, to_days(date_format("{getpls(sf.ls1, 1)}", "%Y-%m-%d"))) not in (select ch1 from atvd where ch1 is not null and ss = 4)'
        chrls(sf.ls2, q1 + q2 + q3)

    def prsls1(sf, ev):
        sf.bt1.configure(state='normal')
        sf.bt2.configure(state='disable')
        sf.bt3.configure(state='disable')
        sf.bt4.configure(state='normal')
        sf.bt5.configure(state='normal')
        sf.chrls8()
        sf.chrls2()
        q1 = 'select * from vw_atvd_enc where '
        q1b = 'select * from vw_atvd_flp where '
        q1a = 'select * from vw_atvd_abe where '
        if vS == None or vS == '':
            q2 = f'c = {str(vC)}'
        else:
            q2 = f's = {str(vS)}'
        q3 = f' and cd_pes <> {str(vCd)} and "{getpls(sf.ls1, 1)}" >= dt and "{getpls(sf.ls1, 1)}" <= d'
        q3a = f' and cd_pes <> {str(vCd)} and "{getpls(sf.ls1, 1)}" >= dt'
        chrls(sf.ls3, f'{q1}{q2}{q3}\nunion all\n{q1a}{q2}{q3a}\nunion all\n{q1b}{q2}{q3}')
        clrls(sf.ls4)
        clrls(sf.ls7)

    def prsls8(sf, ev):
        sf.bt1.configure(state='disable')
        sf.bt2.configure(state='disable')
        sf.bt3.configure(state='disable')
        sf.bt4.configure(state='disable')
        sf.bt5.configure(state='disable')
        sf.chrls1()
        clrls(sf.ls2)
        q1 = 'select * from vw_atvd where '
        if vS == None or vS == '':
            q2 = f'c = {str(vC)}'
        else:
            q2 = f's = {str(vS)} and cd_pes <> {str(vCd)}'
        q3 = f' and dt = "{getpls(sf.ls8, 1)}" order by dti'
        chrls(sf.ls3, q1 + q2 + q3)
        clrls(sf.ls4)
        clrls(sf.ls7)

    def prsls2(sf, ev):
        if len(sf.ls2.selection()) > 0 and len(sf.ls3.selection()) > 0:
            if len(sf.ls2.selection()) > 0 and getpls(sf.ls3, 5) != '-' and getpls(sf.ls3, 7) == '-':
                sf.bt6.configure(state='normal')
            else:
                sf.bt6.configure(state='disable')

    def prsls3(sf, ev):
        if getpls(sf.ls3, 5) != '-' and getpls(sf.ls3, 7) == '-':
            sf.bt2.configure(state='normal')
        else:
            sf.bt2.configure(state='disable')
        if getpls(sf.ls3, 5) != '-' and getpls(sf.ls3, 6) != '-' and getpls(sf.ls3, 7) != '-':
            sf.bt3.configure(state='normal')
        else:
            sf.bt3.configure(state='disable')
        sf.prsls2(1)
        chrls(sf.ls4, 'select * from vw_atvd_pessoal_equip where og = ' + getpls(sf.ls3, 0))
        chrls(sf.ls7, 'select * from vw_atvd_pessoal_equip_enc where og = ' + getpls(sf.ls3, 0))

    def dblls2(sf, ev):
        if len(sf.ls3.selection()) > 0:
            if getpls(sf.ls3, 5) != '-' and getpls(sf.ls3, 7) == '-':
                cnx.sqlcmd(cnx(), 'call prcCopAtvd(' + getpls(sf.ls3, 0) + ', ' + getpls(sf.ls2, 0) + ')')
                sf.chrls2()
                chrls(sf.ls4, 'select * from vw_atvd_pessoal_equip where og = ' + getpls(sf.ls3, 0))
                chrls(sf.ls7, 'select * from vw_atvd_pessoal_equip_enc where og = ' + getpls(sf.ls3, 0))
            else:
                msgb(3, 'Nova Atividade', 'É necessário selecionar uma atividade não finalizada!', sf.master)
        else:
            msgb(3, 'Nova Atividade', 'É necessário selecionar uma atividade!', sf.master)

    def prsbt1(sf, op): #op opção 1=inclusão de nova atividade, 2=insetir data de finalização e 3=continuar uma atividade fechada para um dia posterior
        v = False
        global f
        f = False
        if op == 1:
            t = 'Nova Atividade'
            if len(sf.ls1.selection()) > 0 and len(sf.ls2.selection()) > 0:
                col = getpls(sf.ls2, 1)
                v = True
            else:
                msgb(3, t, 'É necessário selecionar uma data aberta e um colaborador!', sf.master)
        elif op == 12:
            t = 'Incluir na Atividade'
            col = getpls(sf.ls2, 1)
            v = True
        elif op == 2:
            t = 'Finalizar Atividade'
            if len(sf.ls4.selection()) > 0:
                col = getpls(sf.ls4, 1)
                f = True
            else:
                col = getpls(sf.ls3, 3)
            v = True
        elif op == 3:
            t = 'Continuar Atividade'
            a = cnx.csql(cnx(), f'select * from vw_atvd_pessoal_ocupado where cd_pes = {getpls(sf.ls3, 2)} limit 1')
            if len(a) > 0:
                msgb(3, t, f'O colaborador {getpls(sf.ls3, 3)} possui uma atividade aberta em {a[0][1]} e não é permitido manter mais de uma atividade aberta por colaborador.', sf.master)
            else:
                col = getpls(sf.ls3, 3)
                v = True
        if v:
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 665, 192, t)
            sf.v1 = StringVar()
            sf.v2 = StringVar()
            sf.f = frm(sf.popup, 0, 0)
            sf.f1 = fr(sf.f, 0, 0)
            lb(sf.f1, 0, 0, 'Colaborador:')
            sf.e1 = en(sf.f1, 0, 1, 36)
            sf.e1.insert(0, col)
            sf.e1.configure(state='readonly')
            sf.f2 = fr(sf.f, 1, 0)
            lb(sf.f2, 0, 0, 'Data I:')
            sf.e2 = en(sf.f2, 0, 1, 10, justify=RIGHT)
            if op == 1:
                sf.e2.insert(0, getpls(sf.ls1, 0))
                sf.e2.configure(state='readonly')
            elif op == 2:
                trat = datetime.strptime(getpls(sf.ls3, 8), '%Y-%m-%d')
                insen(sf.e2, trat.strftime('%d/%m/%Y'))
                sf.e2.configure(state='readonly')
            else:
                trat = datetime.strptime(getpls(sf.ls3, 8), '%Y-%m-%d') + timedelta(days=+1)
                insen(sf.e2, trat.strftime('%d/%m/%Y'))
            sf.b12 = bt(sf.f2, 0, 2, '+1', sf.prsb12, state='disable')
            lb(sf.f2, 0, 3, 'Hora I:')
            sf.e3 = en(sf.f2, 0, 4, 6, [('<FocusOut>', lambda ev, a=op: sf.oute3(ev, a))], justify=RIGHT)
            lb(sf.f2, 0, 5, 'Data F:')
            sf.e4 = en(sf.f2, 0, 6, 10, state='readonly', justify=RIGHT)
            lb(sf.f2, 0, 7, 'Hora F:')
            sf.e5 = en(sf.f2, 0, 8, 6, [('<FocusOut>', sf.oute5)], justify=RIGHT)
            sf.f3 = fr(sf.f, 2, 0)
            lb(sf.f3, 0, 0, 'Cliente:')
            sf.c1 = cb(sf.f3, 0, 1, 16)
            lb(sf.f3, 0, 2, 'Segmento:')
            sf.c2 = cb(sf.f3, 0, 3, 16, [('<<ComboboxSelected>>', sf.selc2)])
            lb(sf.f3, 0, 4, 'Tipo:')
            sf.c3 = cb(sf.f3, 0, 5, 16)
            if op == 1:
                sf.c1['values'] = cnx.qcb(cnx(), 'id', 'ds', 'gestao_clientes', 'id', 'id in (3, 4)')
                sf.c2['values'] = cnx.qcb(cnx(), 'id', 'ds', 'gestao_segmentos', 'id', 'id in (2, 3, 7)')
                sf.c3['values'] = cnx.qcb(cnx(), 'id', 'ds', 'atvd_tipo', 'id')
            sf.f4 = fr(sf.f, 3, 0)
            lb(sf.f4, 0, 0, 'Localidade:')
            sf.e6 = en(sf.f4, 0, 1, 6, [('<FocusOut>', sf.oute6)])
            sf.c4 = cb(sf.f4, 0, 2, 26)
            sf.f5 = fr(sf.f, 4, 0)
            lb(sf.f5, 0, 0, textvariable=sf.v1)
            sf.v1.set('BA/TA/Prot./Acion.:')
            sf.e7 = en(sf.f5, 0, 1, 16)
            lb(sf.f5, 0, 2, textvariable=sf.v2)
            sf.v2.set('Circuito/Estação:')
            sf.e8 = en(sf.f5, 0, 3, 16)
            sf.f6 = fr(sf.f, 5, 0, E)
            bt(sf.f6, 0, 0, 'Cancelar', sf.popup.destroy)
            sf.b11 = bt(sf.f6, 0, 1, 'Salvar', lambda a=op: sf.prsb11(a))
            if op > 1:
                if op == 2:
                    sf.e3.insert(0, getpls(sf.ls3, 6)[-5:])
                    sf.e3.configure(state='disable')
                if op == 12:
                    sf.e5.configure(state='disable')
                a = getpls(sf.ls3, 4)
                b = a.find('/')
                c = a[b+1:].find('/')
                d = a.rfind('/')
                sf.c1.set(cnx.qcb(cnx(), 'id', 'ds', 'gestao_clientes', 1, 'ds = "' + a[:b] + '"')[0])
                sf.c1.configure(state='disable')
                sf.c2.set(cnx.qcb(cnx(), 'id', 'ds', 'gestao_segmentos', 1, 'ds = "' + a[b+1:b+1+c] + '"')[0])
                sf.selc2(1)
                sf.c2.configure(state='disable')
                sf.c3.set(cnx.qcb(cnx(), 'id', 'ds', 'atvd_tipo', 1, 'ds = "' + a[d+1:] + '"')[0])
                sf.c3.configure(state='disable')
                a = getpls(sf.ls3, 5)
                b = a.find('/')
                c = a[b+1:].find('/')
                d = a.rfind('/')
                sf.c4.set(cnx.qcb(cnx(), 'id', 'nm', 'locs', 1, 'id = "' + a[:b] + '"')[0])
                sf.c4.configure(state='disable')
                sf.e6.configure(state='disable')
                sf.e7.insert(0, a[d+1:])
                sf.e7.configure(state='disable')
                sf.e8.insert(0, a[b+1:b+1+c])
                sf.e8.configure(state='disable')
            if op == 3:
                sf.b12.configure(state='normal')

    def prsb12(sf):
        trat = datetime.strptime(sf.e2.get(), '%d/%m/%Y') + timedelta(days=+1)
        insen(sf.e2, trat.strftime('%d/%m/%Y'))
        if len(sf.e3.get()) > 0:
            sf.e3.delete(0, END)

    def prsb11(sf, op):
        if op in (1, 3):
            if len(sf.e2.get()) > 0 and len(sf.e3.get()) > 0 and len(sf.c1.get()) > 0 and len(sf.c2.get()) > 0 and len(sf.c3.get()) > 0 and len(sf.c4.get()) > 0 and len(sf.e7.get()) > 0 and len(sf.e8.get()) > 0:
                if len(sf.e4.get()) > 0 and len(sf.e5.get()) > 0:
                    cnx.sqlcmd(cnx(), f'call prcInsAtvd({getpls(sf.ls2, 0)}, "{sf.e2.get()} {sf.e3.get()} ", "{sf.e4.get()} {sf.e5.get()}", {getpcb(sf.c1, 2)}, {getpcb(sf.c2, 2)}, {getpcb(sf.c3, 2)}, "{getpcb(sf.c4, 2)}", "{sf.e7.get()}", "{sf.e8.get()}")')
                else:
                    if op == 1:
                        a = getpls(sf.ls2, 0)
                    else:
                        a = sf.e1.get()
                        a = a[:a.find('-')]
                    cnx.sqlcmd(cnx(), f'call prcInsAtvd({a}, "{sf.e2.get()} {sf.e3.get()} ", NULL, {getpcb(sf.c1, 2)}, {getpcb(sf.c2, 2)}, {getpcb(sf.c3, 2)}, "{getpcb(sf.c4, 2)}", "{sf.e7.get()}", "{sf.e8.get()}", {str(vId)})')
                sf.popup.destroy()
                if op == 1:
                    sf.prsls1(1)
                else:
                    if len(sf.ls1.selection()) > 0:
                        sf.prsls1(1)
                    else:
                        sf.prsls8(1)
            else:
                msgb(1, 'Nova Atividade', 'Somente os campos Data F. e Hora F. podem estar vazios!', sf.popup)
        elif op == 12:
            if len(sf.e3.get()) > 0:
                cnx.sqlcmd(cnx(), f'call prcCopAtvd({getpls(sf.ls3, 0)}, {getpls(sf.ls2, 0)}, "{sf.e2.get()} {sf.e3.get()}", {str(vId)})')
                sf.popup.destroy()
                sf.chrls2()
                chrls(sf.ls4, f'select * from vw_atvd_pessoal_equip where og = {getpls(sf.ls3, 0)}')
                chrls(sf.ls7, f'select * from vw_atvd_pessoal_equip_enc where og = {getpls(sf.ls3, 0)}')
            else:
                msgb(1, 'Encerrar Atividade', 'O campo Hora I. não pode estar em branco!', sf.popup)
        elif op == 2:
            if len(sf.e3.get()) > 0 and len(sf.e4.get()) > 0:
                if f:
                    cnx.sqlcmd(cnx(), f'call prcFecAtvd({getpls(sf.ls4, 0)}, "{sf.e4.get()} {sf.e5.get()}", {str(vId)}, 1)')
                else:
                    cnx.sqlcmd(cnx(), f'call prcFecAtvd({getpls(sf.ls3, 0)}, "{sf.e4.get()} {sf.e5.get()}", {str(vId)}, 1)')
                    cnx.sqlcmd(cnx(), f'call prcFecAtvd({getpls(sf.ls3, 0)}, "{sf.e4.get()} {sf.e5.get()}", {str(vId)}, 2)')
                sf.popup.destroy()
                x = int(sf.ls3.selection()[0])
                sf.prsls1(1)
                selidls(sf.ls3, x)
            else:
                msgb(1, 'Encerrar Atividade', 'Os campos Data F. e Hora F. não podem estar em branco!', sf.popup)

    def selc2(sf, ev):
        a = getpcb(sf.c2)
        if a == 2:
            sf.v1.set('Protocolo:')
            sf.v2.set('Circuito:')
        elif a == 3:
            sf.v1.set('BA/TA:')
            sf.v2.set('Estação:')
        elif a == 7:
            sf.v1.set('Acionamento:')
            sf.v2.set('Circuito:')

    def oute3(sf, ev, op):
        if isdthr(2, sf.e3, sf.popup):
            if op in (1, 12):
                a = getpls(sf.ls2, 4)
                if len(a) == 19:
                    a = datetime.strptime(a, '%Y-%m-%d %H:%M:%S')
                    b = datetime.strptime(f'{sf.e2.get()} {sf.e3.get()}:00', '%d/%m/%Y %H:%M:%S')
                    c = a.strftime('%d/%m/%Y %H:%M')
                    if b <= a:
                        if op == 1:
                            t = 'Nova Atividade'
                        else:
                            t = 'Incluir na Atividade'
                        msgb(3, t, f'Não é possível criar atividade para o colaborador {sf.e1.get()} antes de {c}!', sf.popup)
                        sf.e3.focus_force()
                else:
                    if op == 12:
                        a = getpls(sf.ls3, 6)
                        if len(a) == 14:
                            a = datetime.strptime(f'{a}:00', '%d/%m/%y %H:%M:%S')
                            b = datetime.strptime(f'{sf.e2.get()} {sf.e3.get()}:00', '%d/%m/%Y %H:%M:%S')
                            c = a.strftime('%d/%m/%Y %H:%M')
                            if b < a:
                                msgb(3, 'Incluir na Atividade', f'Não é possível incluir nesta atividade horário antes de {c}!', sf.popup)
                                sf.e3.focus_force()
            elif op == 3:
                q1 = 'select count(id) from atvd where '
                q2 = f'ss = 4 and cd_pes = {getpls(sf.ls3, 2)} and date_format(dthri, "%d/%m/%Y") = "{sf.e2.get()}"'
                a = cnx.csql(cnx(), q1 + q2)
                if int(a[0][0]) > 0:
                    msgb(3, 'Continuar Atividade', f'Não é possível continuar a atividade para o colaborador {sf.e1.get()} no dia {sf.e2.get()} pois existe uma ausência registrada nesta data!', sf.popup)
                    sf.e3.focus_force()
                else:
                    q1 = 'select date_format(max(dthrf), "%H:%i") from atvd where '
                    q2 = f'ss = 2 and cd_pes = {getpls(sf.ls3, 2)} and date_format(dthri, "%d/%m/%Y") = "{sf.e2.get()}"'
                    a = cnx.csql(cnx(), q1 + q2)
                    if not a[0] == None and len(a) > 0:
                        if sf.e3.get() <= a[0][0]:
                            msgb(3, 'Continuar Atividade', f'Não é possível continuar a atividade para o colaborador {sf.e1.get()} no dia {sf.e2.get()} antes das {a[0][0]}!', sf.popup)
                            sf.e3.focus_force()
                        else:
                            pass

    def oute5(sf, ev):
        if len(sf.e5.get()) > 0:
            if isdthr(2, sf.e5, sf.popup):
                if sf.e3.get() < sf.e5.get():
                    insen(sf.e4, sf.e2.get())
                else:
                    trat = datetime.strptime(sf.e2.get(), '%d/%m/%Y') + timedelta(days=+1)
                    insen(sf.e4, trat.strftime('%d/%m/%Y'))
                a = datetime.strptime(f'{sf.e4.get()} {sf.e5.get()}', '%d/%m/%Y %H:%M')
                b = datetime.now()
                if a > b:
                    msgb(3, 'Encerrar Atividade', f'Não é possível encerrar a atividade com data superior à atual!', sf.popup)
                    sf.e5.focus_force()

    def oute6(sf, ev):
        sf.c4['values'] = ''
        sf.c4['values'] = cnx.qcb(cnx(), 'id', 'nm', 'locs', 1, f'concat(id, nm) like "%{sf.e6.get()}%"')

class atco():
    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 960, 660, 'Atividades CO')
        sf.frm = frm(master, 0, 0)
        sf.fr1 = fr(sf.frm, 0, 0)
        #sp(sf.fr1, 0, 0, width=160)
        sf.ls1 = ls(sf.fr1, 1, 0, 9, [('<<TreeviewSelect>>', sf.prsls1)], 'we')
        carrega_lista(1, 'vw_atvd_s', sf.ls1)
        sf.chrls1()
        #sp(sf.fr1, 0, 1, width=160)
        #sf.ls8 = ls(sf.fr1, 1, 1, 3, [('<<TreeviewSelect>>', sf.prsls8)], 'we')
        #carrega_lista(1, 'vw_atvd_datas_fec', sf.ls8)
        #sf.chrls8()
        sf.bt1 = bt(sf.fr1, 1, 2, 'Nova Ativ.', lambda a=1: sf.prsbt1(a))
        sf.bt6 = bt(sf.fr1, 1, 3, 'Incluir', lambda a=12: sf.prsbt1(a), state='disable')
        sf.bt2 = bt(sf.fr1, 1, 4, 'Encerrar', lambda a=2: sf.prsbt1(a), state='disable')
        #sf.bt3 = bt(sf.fr1, 1, 5, 'Continuar', lambda a=3: sf.prsbt1(a), state='disable')
        #sf.bt4 = bt(sf.fr1, 1, 6, 'Fluxo Pres.', sf.prsbt4)
        #sf.bt5 = bt(sf.fr1, 1, 7, 'Finaliza Dia', sf.prsbt5)
        sf.fr2 = fr(sf.frm, 1, 0)
        sp(sf.fr2, 0, 0, width=160)
        sf.ls2 = ls(sf.fr2, 1, 0, 19, [('<<TreeviewSelect>>', sf.prsls2)], 'we', 2)
        carrega_lista(1, 'vw_atvd_pessoal_livre', sf.ls2)
        sp(sf.fr2, 0, 1, width=585)
        sf.ls3 = ls(sf.fr2, 1, 1, 19, [('<<TreeviewSelect>>', sf.prsls3)], 'we', 2)
        carrega_lista(1, 'vw_atvd', sf.ls3)
        sp(sf.fr2, 0, 2, width=160)
        sf.ls4 = ls(sf.fr2, 1, 2, 8, [], 'wens')
        carrega_lista(1, 'vw_atvd_pessoal_equip', sf.ls4)
        sf.ls7 = ls(sf.fr2, 2, 2, 8, [], 'wens')
        carrega_lista(1, 'vw_atvd_pessoal_equip_enc', sf.ls7)
        sf.fr3 = fr(sf.frm, 2, 0)
        #sp(sf.fr3, 0, 0, width=460)
        #lb(sf.fr3, 1, 0, 'Atividades disponíveis para agendamento', font=font3)
        #sf.ls5 = ls(sf.fr3, 2, 0, 9, [], 'we')
        #sp(sf.fr3, 0, 1, width=460)
        #lb(sf.fr3, 1, 1, 'Ajustes necessários no RM', font=font3)
        #sf.ls6 = ls(sf.fr3, 2, 1, 9, [], 'we')        

    def chrls1(sf):
        chrls(sf.ls1, f'select * from vw_atvd_s')

    def prsbt5(sf):
        if len(sf.ls1.selection()) > 0:
            q1 = 'select count(id) from atvd where '
            q2 = f'ss = 1 and date_format(dthri, "%d/%m/%Y") = "{getpls(sf.ls1, 0)}"'
            a = cnx.csql(cnx(), q1 + q2)
            if int(a[0][0]) == 0:
                b = cnx.csql(cnx(), f'select date_format(min(dt), "%Y-%m-%d") from vw_atvd_datas where dt not in (select dt from atvd_fec where cd_pes = {str(vCd)})')
                if getpls(sf.ls1, 1) == b[0][0]:
                    if msgb(4, 'Finaliza o dia', f'Confirma a finalização do dia {getpls(sf.ls1, 0)}?', sf.master):
                        cnx.sqlcmd(cnx(), f'insert into atvd_fec(cd_pes, dt) values({str(vCd)}, "{getpls(sf.ls1, 1)}")')
                        sf.chrls1()
                        sf.chrls8()
                else:
                    c = datetime.strptime(a[0][0], '%Y-%m-%d')
                    c = c.strftime('%d/%m/%Y')
                    msgb(3, 'Finaliza o dia', f'É necessário finalizar a data {c} primeiro!', sf.master)
            else:
                msgb(3, 'Finaliza o dia', f'Existem {a[0][0]} atividades abertas em {getpls(sf.ls1, 0)}, para finalizar o dia é necessário encerrar estas atividades!', sf.master)    
        else:
            msgb(3, 'Finaliza o dia', 'É necessário selecionar uma data aberta para finalização!', sf.master)
            
    def prsbt4(sf):
        if len(sf.ls1.selection()) > 0 and len(sf.ls2.selection()) > 0:
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 372, 194, 'Informar ausência')
            sf.f = frm(sf.popup, 0, 0)
            sf.f1 = fr(sf.f, 0, 0)
            lb(sf.f1, 0, 0, 'Colaborador:')
            sf.e1 = en(sf.f1, 0, 1, 30, state='readonly')
            insen(sf.e1, getpls(sf.ls2, 1))
            lb(sf.f1, 1, 0, 'Ausência:')
            sf.c1 = cb(sf.f1, 1, 1, 24, [('<<ComboboxSelected>>', sf.clkc41)])
            sf.c1['values'] = cnx.qcb(cnx(), 'id', 'ds', 'ponto_comp', 'ds')
            lb(sf.f1, 2, 0, 'Data/Hora I:')
            lb(sf.f1, 3, 0, 'Data/Hora F:')
            sf.f1b = fr(sf.f1, 2, 1, rs=2)
            sf.e2 = en(sf.f1b, 0, 1, 10, state='readonly')
            insen(sf.e2, getpls(sf.ls1, 0))
            sf.e4 = en(sf.f1b, 0, 2, 5, [('<FocusOut>', lambda e: isdthr(2, sf.e4, sf.popup))], state='readonly')
            sf.e5 = en(sf.f1b, 1, 1, 10, state='readonly')
            insen(sf.e5, getpls(sf.ls1, 0))
            sf.e6 = en(sf.f1b, 1, 2, 5, [('<FocusOut>', lambda e: isdthr(2, sf.e6, sf.popup))], state='readonly')
            sf.b43 = bt(sf.f1b, 1, 3, '-1', lambda: sf.prsb43(-1), 2, state='disable')
            sf.b44 = bt(sf.f1b, 1, 4, '+1', lambda: sf.prsb43(+1), 2, state='disable')
            sf.f1a = fr(sf.f1, 4, 0, cs=2)
            lb(sf.f1a, 0, 0, 'Anexo:')
            sf.e3 = en(sf.f1a, 0, 1, 30, state='readonly')
            sf.b42 = bt(sf.f1a, 0, 2, 'Abrir', sf.prsb42, state='disable')
            sf.f2 = fr(sf.f, 1, 0, E)
            bt(sf.f2, 0, 0, 'Cancelar', sf.popup.destroy)
            sf.b41 = bt(sf.f2, 0, 1, 'Salvar', sf.prsb41)
        else:
            msgb(3, 'Nova Atividade', 'É necessário selecionar uma data aberta e um colaborador!', sf.master)

    def prsb43(sf, o):
        t = datetime.strptime(sf.e5.get(), '%d/%m/%Y') + timedelta(days=o)
        insen(sf.e5, t.strftime('%d/%m/%Y'))
        if sf.e2.get() == sf.e6.get():
            sf.b43.configure(state='disable')
        else:
            sf.b43.configure(state='normal')

    def clkc41(sf, e):
        a = getpcb(sf.c1)
        if a in (1, 2, 6, 8):
            sf.b42.configure(state='disable')
            insen(sf.e3, '')
        else:
            sf.b42.configure(state='normal')
        if a <= 7:
            sf.b44.configure(state='normal')
        else:
            sf.b44.configure(state='disable')
        if a > 7:
            sf.e4.configure(state='normal')
            sf.e6.configure(state='normal')
            insen(sf.e4, '')
            insen(sf.e6, '')
        else:
            sf.e4.configure(state='readonly')
            sf.e6.configure(state='readonly')
            insen(sf.e4, '00:00')
            insen(sf.e6, '23:59')
    
    def prsb42(sf):
        a = open_file('./', 'Abrir anexo', (('JPG', '*.jpg'), ('PNG', '*.png')))
        insen(sf.e3, a[0])
        sf.e3.xview_moveto(1)
    
    def prsb41(sf):
        if len(sf.c1.get()) > 0:
            if len(sf.e3.get()) > 0:
                with open(sf.e3.get(), 'rb') as f:
                    vAnexo = f.read()
            else:
                vAnexo = 'NULL'
            if len(vAnexo) < 2000001:
                cnx.sqlcmdt(cnx(), getpls(sf.ls2, 0), f'{sf.e2.get()} {sf.e4.get()}', f'{sf.e5.get()} {sf.e6.get()}', getpcb(sf.c1, 1), vAnexo)
                sf.popup.destroy()
                sf.prsls1(1)
            else:
                pass
        else:
            msgb(3, 'Informar ausência', 'É necessário selecionar uma ausência!', sf.popup)
    
    def chrls2(sf):
        q1 = 'select cd, ds, c, s, dt from vw_atvd_pessoal_livre '
        d = datetime.now().strftime('%Y-%m-%d')
        q3 = f'where cd <> {getpls(sf.ls1, 2)} and s = {getpls(sf.ls1, 1)} and concat(cd, to_days(date_format("{d}", "%Y-%m-%d"))) not in (select ch1 from atvd where ch1 is not null and ss = 4)'
        chrls(sf.ls2, q1 + q3)

    def prsls1(sf, ev):
        sf.bt1.configure(state='normal')
        sf.bt2.configure(state='disable')
        #sf.bt3.configure(state='disable')
        #sf.bt4.configure(state='normal')
        #sf.bt5.configure(state='normal')
        #sf.chrls8()
        sf.chrls2()
        d = datetime.now().strftime('%Y-%m-%d')
        chrls(sf.ls3, f'select * from vw_atvd where s = {getpls(sf.ls1, 1)} and dt = "{d}" or (s = {getpls(sf.ls1, 1)} and dtf = "-")')
        clrls(sf.ls4)
        clrls(sf.ls7)

    def prsls8(sf, ev):
        sf.bt1.configure(state='disable')
        sf.bt2.configure(state='disable')
        sf.bt3.configure(state='disable')
        #sf.bt4.configure(state='disable')
        #sf.bt5.configure(state='disable')
        sf.chrls1()
        clrls(sf.ls2)
        d = datetime.now().strftime('%Y-%m-%d')
        chrls(sf.ls3, f'select * from vw_atvd where s = {getpls(sf.ls1, 1)} and dt = "{d}"')
        clrls(sf.ls4)
        clrls(sf.ls7)

    def prsls2(sf, ev):
        if len(sf.ls2.selection()) > 0 and len(sf.ls3.selection()) > 0:
            if len(sf.ls2.selection()) > 0 and getpls(sf.ls3, 5) != '-' and getpls(sf.ls3, 7) == '-':
                sf.bt6.configure(state='normal')
            else:
                sf.bt6.configure(state='disable')

    def prsls3(sf, ev):
        if getpls(sf.ls3, 5) != '-' and getpls(sf.ls3, 7) == '-':
            sf.bt2.configure(state='normal')
        else:
            sf.bt2.configure(state='disable')
        """if getpls(sf.ls3, 5) != '-' and getpls(sf.ls3, 6) != '-' and getpls(sf.ls3, 7) != '-':
            sf.bt3.configure(state='normal')
        else:
            sf.bt3.configure(state='disable')"""
        sf.prsls2(1)
        chrls(sf.ls4, 'select * from vw_atvd_pessoal_equip where og = ' + getpls(sf.ls3, 0))
        chrls(sf.ls7, 'select * from vw_atvd_pessoal_equip_enc where og = ' + getpls(sf.ls3, 0))

    def dblls2(sf, ev):
        if len(sf.ls3.selection()) > 0:
            if getpls(sf.ls3, 5) != '-' and getpls(sf.ls3, 7) == '-':
                cnx.sqlcmd(cnx(), 'call prcCopAtvd(' + getpls(sf.ls3, 0) + ', ' + getpls(sf.ls2, 0) + ')')
                sf.chrls2()
                chrls(sf.ls4, 'select * from vw_atvd_pessoal_equip where og = ' + getpls(sf.ls3, 0))
                chrls(sf.ls7, 'select * from vw_atvd_pessoal_equip_enc where og = ' + getpls(sf.ls3, 0))
            else:
                msgb(3, 'Nova Atividade', 'É necessário selecionar uma atividade não finalizada!', sf.master)
        else:
            msgb(3, 'Nova Atividade', 'É necessário selecionar uma atividade!', sf.master)

    def prsbt1(sf, op): #op opção 1=inclusão de nova atividade, 2=insetir data de finalização e 3=continuar uma atividade fechada para um dia posterior
        v = False
        global f
        f = False
        if op == 1:
            t = 'Nova Atividade'
            if len(sf.ls1.selection()) > 0 and len(sf.ls2.selection()) > 0:
                col = getpls(sf.ls2, 1)
                v = True
            else:
                msgb(3, t, 'É necessário selecionar uma data aberta e um colaborador!', sf.master)
        elif op == 12:
            t = 'Incluir na Atividade'
            col = getpls(sf.ls2, 1)
            v = True
        elif op == 2:
            t = 'Finalizar Atividade'
            if len(sf.ls4.selection()) > 0:
                col = getpls(sf.ls4, 1)
                f = True
            else:
                col = getpls(sf.ls3, 3)
            v = True
        elif op == 3:
            t = 'Continuar Atividade'
            a = cnx.csql(cnx(), f'select * from vw_atvd_pessoal_ocupado where cd_pes = {getpls(sf.ls3, 2)} limit 1')
            if len(a) > 0:
                msgb(3, t, f'O colaborador {getpls(sf.ls3, 3)} possui uma atividade aberta em {a[0][1]} e não é permitido manter mais de uma atividade aberta por colaborador.', sf.master)
            else:
                col = getpls(sf.ls3, 3)
                v = True
        if v:
            sf.popup = Toplevel(sf.master)
            win(sf.popup, sf.master, 665, 192, t)
            sf.v1 = StringVar()
            sf.v2 = StringVar()
            sf.f = frm(sf.popup, 0, 0)
            sf.f1 = fr(sf.f, 0, 0)
            lb(sf.f1, 0, 0, 'Colaborador:')
            sf.e1 = en(sf.f1, 0, 1, 36)
            sf.e1.insert(0, col)
            sf.e1.configure(state='readonly')
            sf.f2 = fr(sf.f, 1, 0)
            lb(sf.f2, 0, 0, 'Data I:')
            sf.e2 = en(sf.f2, 0, 1, 10, justify=RIGHT)
            if op == 3:
                trat = datetime.strptime(getpls(sf.ls3, 8), '%Y-%m-%d') + timedelta(days=+1)
                insen(sf.e2, trat.strftime('%d/%m/%Y'))
            else:
                d = datetime.now().strftime('%d/%m/%Y')
                sf.e2.insert(0, d)
                sf.e2.configure(state='readonly')
            sf.b12 = bt(sf.f2, 0, 2, '+1', sf.prsb12, state='disable')
            lb(sf.f2, 0, 3, 'Hora I:')
            sf.e3 = en(sf.f2, 0, 4, 6, [('<FocusOut>', lambda ev, a=op: sf.oute3(ev, a))], justify=RIGHT)
            lb(sf.f2, 0, 5, 'Data F:')
            sf.e4 = en(sf.f2, 0, 6, 10, state='readonly', justify=RIGHT)
            lb(sf.f2, 0, 7, 'Hora F:')
            sf.e5 = en(sf.f2, 0, 8, 6, [('<FocusOut>', sf.oute5)], justify=RIGHT)
            sf.f3 = fr(sf.f, 2, 0)
            lb(sf.f3, 0, 0, 'Cliente:')
            sf.c1 = cb(sf.f3, 0, 1, 16)
            lb(sf.f3, 0, 2, 'Segmento:')
            sf.c2 = cb(sf.f3, 0, 3, 16, [('<<ComboboxSelected>>', sf.selc2)])
            lb(sf.f3, 0, 4, 'Tipo:')
            sf.c3 = cb(sf.f3, 0, 5, 16)
            if op == 1:
                sf.c1['values'] = cnx.qcb(cnx(), 'id', 'ds', 'gestao_clientes', 'id', 'id in (3, 4)')
                sf.c2['values'] = cnx.qcb(cnx(), 'id', 'ds', 'gestao_segmentos', 'id', 'id in (2, 3, 7)')
                sf.c3['values'] = cnx.qcb(cnx(), 'id', 'ds', 'atvd_tipo', 'id')
            sf.f4 = fr(sf.f, 3, 0)
            lb(sf.f4, 0, 0, 'Localidade:')
            sf.e6 = en(sf.f4, 0, 1, 6, [('<FocusOut>', sf.oute6)])
            sf.c4 = cb(sf.f4, 0, 2, 26)
            sf.f5 = fr(sf.f, 4, 0)
            lb(sf.f5, 0, 0, textvariable=sf.v1)
            sf.v1.set('BA/TA/Prot./Acion.:')
            sf.e7 = en(sf.f5, 0, 1, 16)
            lb(sf.f5, 0, 2, textvariable=sf.v2)
            sf.v2.set('Circuito/Estação:')
            sf.e8 = en(sf.f5, 0, 3, 16)
            sf.f6 = fr(sf.f, 5, 0, E)
            bt(sf.f6, 0, 0, 'Cancelar', sf.popup.destroy)
            sf.b11 = bt(sf.f6, 0, 1, 'Salvar', lambda a=op: sf.prsb11(a))
            if op > 1:
                if op == 2:
                    sf.e3.insert(0, getpls(sf.ls3, 6)[-5:])
                    sf.e3.configure(state='disable')
                if op == 12:
                    sf.e5.configure(state='disable')
                a = getpls(sf.ls3, 4)
                b = a.find('/')
                c = a[b+1:].find('/')
                d = a.rfind('/')
                sf.c1.set(cnx.qcb(cnx(), 'id', 'ds', 'gestao_clientes', 1, 'ds = "' + a[:b] + '"')[0])
                sf.c1.configure(state='disable')
                sf.c2.set(cnx.qcb(cnx(), 'id', 'ds', 'gestao_segmentos', 1, 'ds = "' + a[b+1:b+1+c] + '"')[0])
                sf.selc2(1)
                sf.c2.configure(state='disable')
                sf.c3.set(cnx.qcb(cnx(), 'id', 'ds', 'atvd_tipo', 1, 'ds = "' + a[d+1:] + '"')[0])
                sf.c3.configure(state='disable')
                a = getpls(sf.ls3, 5)
                b = a.find('/')
                c = a[b+1:].find('/')
                d = a.rfind('/')
                sf.c4.set(cnx.qcb(cnx(), 'id', 'nm', 'locs', 1, 'id = "' + a[:b] + '"')[0])
                sf.c4.configure(state='disable')
                sf.e6.configure(state='disable')
                sf.e7.insert(0, a[d+1:])
                sf.e7.configure(state='disable')
                sf.e8.insert(0, a[b+1:b+1+c])
                sf.e8.configure(state='disable')
            if op == 3:
                sf.b12.configure(state='normal')

    def prsb12(sf):
        trat = datetime.strptime(sf.e2.get(), '%d/%m/%Y') + timedelta(days=+1)
        insen(sf.e2, trat.strftime('%d/%m/%Y'))
        if len(sf.e3.get()) > 0:
            sf.e3.delete(0, END)

    def prsb11(sf, op):
        if op in (1, 3):
            if len(sf.e2.get()) > 0 and len(sf.e3.get()) > 0 and len(sf.c1.get()) > 0 and len(sf.c2.get()) > 0 and len(sf.c3.get()) > 0 and len(sf.c4.get()) > 0 and len(sf.e7.get()) > 0 and len(sf.e8.get()) > 0:
                if len(sf.e4.get()) > 0 and len(sf.e5.get()) > 0:
                    cnx.sqlcmd(cnx(), f'call prcInsAtvd({getpls(sf.ls2, 0)}, "{sf.e2.get()} {sf.e3.get()} ", "{sf.e4.get()} {sf.e5.get()}", {getpcb(sf.c1, 2)}, {getpcb(sf.c2, 2)}, {getpcb(sf.c3, 2)}, "{getpcb(sf.c4, 2)}", "{sf.e7.get()}", "{sf.e8.get()}")')
                else:
                    if op == 1:
                        a = getpls(sf.ls2, 0)
                    else:
                        a = sf.e1.get()
                        a = a[:a.find('-')]
                    cnx.sqlcmd(cnx(), f'call prcInsAtvd({a}, "{sf.e2.get()} {sf.e3.get()} ", NULL, {getpcb(sf.c1, 2)}, {getpcb(sf.c2, 2)}, {getpcb(sf.c3, 2)}, "{getpcb(sf.c4, 2)}", "{sf.e7.get()}", "{sf.e8.get()}", {str(vId)})')
                sf.popup.destroy()
                if op == 1:
                    sf.prsls1(1)
                else:
                    if len(sf.ls1.selection()) > 0:
                        sf.prsls1(1)
                    else:
                        sf.prsls8(1)
            else:
                msgb(1, 'Nova Atividade', 'Somente os campos Data F. e Hora F. podem estar vazios!', sf.popup)
        elif op == 12:
            if len(sf.e3.get()) > 0:
                cnx.sqlcmd(cnx(), f'call prcCopAtvd({getpls(sf.ls3, 0)}, {getpls(sf.ls2, 0)}, "{sf.e2.get()} {sf.e3.get()}", {str(vId)})')
                sf.popup.destroy()
                sf.chrls2()
                chrls(sf.ls4, f'select * from vw_atvd_pessoal_equip where og = {getpls(sf.ls3, 0)}')
                chrls(sf.ls7, f'select * from vw_atvd_pessoal_equip_enc where og = {getpls(sf.ls3, 0)}')
            else:
                msgb(1, 'Encerrar Atividade', 'O campo Hora I. não pode estar em branco!', sf.popup)
        elif op == 2:
            if len(sf.e3.get()) > 0 and len(sf.e4.get()) > 0:
                if f:
                    cnx.sqlcmd(cnx(), f'call prcFecAtvd({getpls(sf.ls4, 0)}, "{sf.e4.get()} {sf.e5.get()}", {str(vId)}, 1)')
                else:
                    cnx.sqlcmd(cnx(), f'call prcFecAtvd({getpls(sf.ls3, 0)}, "{sf.e4.get()} {sf.e5.get()}", {str(vId)}, 1)')
                    cnx.sqlcmd(cnx(), f'call prcFecAtvd({getpls(sf.ls3, 0)}, "{sf.e4.get()} {sf.e5.get()}", {str(vId)}, 2)')
                sf.popup.destroy()
                x = int(sf.ls3.selection()[0])
                sf.prsls1(1)
                selidls(sf.ls3, x)
            else:
                msgb(1, 'Encerrar Atividade', 'Os campos Data F. e Hora F. não podem estar em branco!', sf.popup)

    def selc2(sf, ev):
        a = getpcb(sf.c2)
        if a == 2:
            sf.v1.set('Protocolo:')
            sf.v2.set('Circuito:')
        elif a == 3:
            sf.v1.set('BA/TA:')
            sf.v2.set('Estação:')
        elif a == 7:
            sf.v1.set('Acionamento:')
            sf.v2.set('Circuito:')

    def oute3(sf, ev, op):
        if isdthr(2, sf.e3, sf.popup):
            if op in (1, 12):
                a = getpls(sf.ls2, 4)
                if len(a) == 19:
                    a = datetime.strptime(a, '%Y-%m-%d %H:%M:%S')
                    b = datetime.strptime(f'{sf.e2.get()} {sf.e3.get()}:00', '%d/%m/%Y %H:%M:%S')
                    c = a.strftime('%d/%m/%Y %H:%M')
                    if b <= a:
                        if op == 1:
                            t = 'Nova Atividade'
                        else:
                            t = 'Incluir na Atividade'
                        msgb(3, t, f'Não é possível criar atividade para o colaborador {sf.e1.get()} antes de {c}!', sf.popup)
                        sf.e3.focus_force()
                else:
                    if op == 12:
                        a = getpls(sf.ls3, 6)
                        if len(a) == 14:
                            a = datetime.strptime(f'{a}:00', '%d/%m/%y %H:%M:%S')
                            b = datetime.strptime(f'{sf.e2.get()} {sf.e3.get()}:00', '%d/%m/%Y %H:%M:%S')
                            c = a.strftime('%d/%m/%Y %H:%M')
                            if b < a:
                                msgb(3, 'Incluir na Atividade', f'Não é possível incluir nesta atividade horário antes de {c}!', sf.popup)
                                sf.e3.focus_force()
            elif op == 3:
                q1 = 'select count(id) from atvd where '
                q2 = f'ss = 4 and cd_pes = {getpls(sf.ls3, 2)} and date_format(dthri, "%d/%m/%Y") = "{sf.e2.get()}"'
                a = cnx.csql(cnx(), q1 + q2)
                if int(a[0][0]) > 0:
                    msgb(3, 'Continuar Atividade', f'Não é possível continuar a atividade para o colaborador {sf.e1.get()} no dia {sf.e2.get()} pois existe uma ausência registrada nesta data!', sf.popup)
                    sf.e3.focus_force()
                else:
                    q1 = 'select date_format(max(dthrf), "%H:%i") from atvd where '
                    q2 = f'ss = 2 and cd_pes = {getpls(sf.ls3, 2)} and date_format(dthri, "%d/%m/%Y") = "{sf.e2.get()}"'
                    a = cnx.csql(cnx(), q1 + q2)
                    if not a[0] == None and len(a) > 0:
                        if sf.e3.get() <= a[0][0]:
                            msgb(3, 'Continuar Atividade', f'Não é possível continuar a atividade para o colaborador {sf.e1.get()} no dia {sf.e2.get()} antes das {a[0][0]}!', sf.popup)
                            sf.e3.focus_force()
                        else:
                            pass

    def oute5(sf, ev):
        if len(sf.e5.get()) > 0:
            if isdthr(2, sf.e5, sf.popup):
                if sf.e3.get() < sf.e5.get():
                    insen(sf.e4, sf.e2.get())
                else:
                    trat = datetime.strptime(sf.e2.get(), '%d/%m/%Y') + timedelta(days=+1)
                    insen(sf.e4, trat.strftime('%d/%m/%Y'))
                a = datetime.strptime(f'{sf.e4.get()} {sf.e5.get()}', '%d/%m/%Y %H:%M')
                b = datetime.now()
                if a > b:
                    msgb(3, 'Encerrar Atividade', f'Não é possível encerrar a atividade com data superior à atual!', sf.popup)
                    sf.e5.focus_force()

    def oute6(sf, ev):
        sf.c4['values'] = ''
        sf.c4['values'] = cnx.qcb(cnx(), 'id', 'nm', 'locs', 1, f'concat(id, nm) like "%{sf.e6.get()}%"')

class gsco():
    def __init__(sf, master, root):
        sf.master = master
        win(master, root, 960, 660, 'Gestão Coordenação')
        sf.frm = frm(master, 0, 0)
        sf.fr1 = fr(sf.frm, 0, 0)
        sf.ls1 = ls(sf.fr1, 0, 0, 6, [('<<TreeviewSelect>>', sf.prsls1)], 'we')
        carrega_lista(1, 'vw_atvd_sup', sf.ls1)
        chrls(sf.ls1, f'select * from vw_atvd_sup where c = {str(vC)}')
        sf.fr2 = fr(sf.frm, 1, 0)
        sf.ls2 = ls(sf.fr2, 0, 0, 10, [], 'we')#indisponíveis
        carrega_lista(1, 'vw_atvd_ind', sf.ls2)
        sf.ls3 = ls(sf.fr2, 0, 1, 10, [], 'we')#sem atividade
        carrega_lista(1, 'vw_atvd_dis', sf.ls3)
        sf.ls4 = ls(sf.fr2, 0, 2, 10, [], 'we')#com atividade
        carrega_lista(1, 'vw_atvd_abe', sf.ls4)
    
    def prsls1(sf, e):
        d = datetime.now().strftime('%Y-%m-%d')
        chrls(sf.ls2, f'select concat(col, "/", at) from vw_atvd_flp where s = {getpls(sf.ls1, 3)} and cd_pes <> {getpls(sf.ls1, 0)} and "{d}" >= dt and "{d}" <= d')
        chrls(sf.ls3, f'select ds from vw_atvd_pessoal_livre where s = {getpls(sf.ls1, 3)} and cd <> {getpls(sf.ls1, 0)} and cd not in (select cd_pes from vw_atvd_flp where s = {getpls(sf.ls1, 3)} and cd_pes <> {getpls(sf.ls1, 0)} and "{d}" >= dt and "{d}" <= d)')
        chrls(sf.ls4, f'select concat(col, "/", at), dti from vw_atvd_abe where s = {getpls(sf.ls1, 3)} and cd_pes <> {getpls(sf.ls1, 0)} and "{getpls(sf.ls1, 1)}" >= dt')
