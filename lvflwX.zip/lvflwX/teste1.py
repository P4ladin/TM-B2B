"""
import requests

url = 'http://apoiogmghm.telemar/dados/producao_ins_mud/prod_ins_mud_excel.asp?c_R=F83241&IDS=1792&NIVEL=UF&LOCAL=MG&SEGMENTO=&SERVICO=TODOS&PRODEMGE=&CD=&RESPONSAVEL=TOTAL&TIPO=CAIXA'

r = requests.get(url)

with open('c:/Projects/testecx.xls', 'wb') as f:
    f.write(r.content)

from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import time

path = 'C:/Program Files/chromedriver.exe'

drv = webdriver.Chrome(path)

drv.get('https://www.instagram.com')
time.sleep(30)
drv.get('https://www.instagram.com/explore/tags/hamburguer/')

drv.find_element_by_xpath('//*[@id="react-root"]/section/main/article/div[1]/div/div/div[1]/div[1]/a/div[1]').click()
time.sleep(5)
qt = 1
while qt < 1000:
    drv.find_element_by_xpath('/html/body/div[4]/div[2]/div/article/div[3]/section[1]/span[1]/button/div/span').click()
    time.sleep(2)
    ActionChains(drv).send_keys(Keys.RIGHT)
    time.sleep(2)
    qt += 1

from cryptography.fernet import Fernet

k = 'UqFSyNZKimlsXaKNK2TaS-xRZjAW5CP4fS2D0dLRKc0='
k = k.encode()
f = Fernet(k)

c = 'gAAAAABfbza-t5w3EMY-tt2Zf8r9LEh9Rhr7D8UG0eATqDnMF3D29rs3Bri1-btrdV5JdZla8i2ict36Xux_I9sHD9rXCFM3qc7XlNaYWmaT_ZQEZpXcSns='

#a = f.encrypt('127.0.0.1'.encode()).decode()
b = f.decrypt(c.encode()).decode()
#print(a)
print(b)
"""

from modulos.janelas import *
import modulos.janelas

modulos.janelas.vNm_r = 'Gustavo Rocha'
modulos.janelas.vCd = 69469
modulos.janelas.vS = None
modulos.janelas.vC = 19
modulos.janelas.vPs = 93
modulos.janelas.vId = 2


app = Tk()
app1 = Toplevel(app)
gspo(app1, app)
app1.mainloop()






