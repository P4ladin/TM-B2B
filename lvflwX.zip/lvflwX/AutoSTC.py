from os import abort, replace
from unidecode import unidecode
import sys
import time
from py3270 import Emulator
from modulos.conexao import *

class cnt(Emulator):
    def __init__(sf, visible=False, host='10.31.9.100'):
        Emulator.__init__(sf, visible)
        sf.connect(host)
        sf.wait_for_field()
        
def gtf(ct, vU='F83241', vP='cruzeiro', vC='CA'):
    ff(ct, 3, 15, 'chr', 3, 2, 'App')
    ff(ct, 25, 23, vU, 25, 2, 'USUARIO', 0)
    ff(ct, 26, 23, vP, 26, 2, 'SENHA')
    if ct.string_get(13, 22, 6) != vU:
        a = input('entender o que aonteceu pra chegar aqui')
    else:
        while not ct.string_get(2, 73, 8) == 'MAN0PFT1':
            et(ct)
        ff(ct, 18, 29, '113', 2, 73, 'MAN0PFT1')
        while not ct.string_get(4, 72, 8) == 'CG00000A':
            et(ct)
        ff(ct, 24, 6, vC, 4, 72, 'CG00000A')

def ete(ct, a, b, c):
    if ct.string_found(a, b, c):
        ct.wait_for_field()
        ct.send_enter()
        ct.wait_for_field()
    else:
        print('TENTATIVA DE ENTER EM TELA DIFERENTE DA ESPERADA')
        time.sleep(60)

def et(ct):
    ct.wait_for_field()
    ct.send_enter()
    ct.wait_for_field()

def ff(ct, a, b, c, d, e, f, g=1, h=0):#g=1: enter sim, g=0: enter não / a,b,c posição de entrada de dados e enter / d,e,f garantir que está na tela certa / h=0 len, h=1 tamanho
    ct.wait_for_field()
    if ct.string_found(d, e, f):
        if h == 0:
            ct.wait_for_field()
            ct.fill_field(a, b, c, len(c))
        else:
            ct.wait_for_field()
            ct.fill_field(a, b, c, h)
        if g:
            et(ct)
    else:
        print(f'TENTATIVA DE ENTRADA/ENTER EM TELA DIFERENTE DA ESPERADA.\nESPERADO: {f} | ENCONTRADO: {ct.string_get(d, e, len(f))}')
        time.sleep(60)
    ct.wait_for_field()

def pf(ct, p):
    ct.wait_for_field()
    ct.send_pf(p)
    ct.wait_for_field()

def sf(ct, a, b, c):
    ct.wait_for_field()
    try:
        if ct.string_get(a, b, len(c)) == c:
            return True
        else:
            return False
    except:
        return False

def getli(qt):
    a = {0.12: 13, 0.25: 14, 0.38: 15, 0.5: 16, 0.62: 17, 0.75: 18, 0.88: 19, 0.0: 20}
    b = round(qt/8, 2)
    c = round(b - int(b), 2)
    if c == 0.0:
        d = int(b) - 1
    else:
        d = int(b)
    return (d, int(a[c]))

def getccir(ccir, ptcs):#busca circuitos à partir do circuito cbb
    try:
        ct = cnt(visible=True)
        gtf(ct, vC='cbb')
        ff(ct, 6, 21, 'BHE', 4, 72, 'CGCBB00A', 0)
        ff(ct, 6, 26, 'TNE', 4, 72, 'CGCBB00A', 0)
        for i in ccir:
            if i not in circok:
                if ct.string_found(3, 71, 'CGCBB00B'):
                    pf(ct, 3)
                if not ct.string_found(4, 72, 'CGCBB00A'):
                    ff(ct, 24, 6, 'cbb', 24, 2, 'Cmd')
                    ff(ct, 6, 21, 'BHE', 4, 72, 'CGCBB00A', 0)
                    ff(ct, 6, 26, 'TNE', 4, 72, 'CGCBB00A', 0)
                ff(ct, 16, 65, i[0], 4, 72, 'CGCBB00A', 0, 4)
                ff(ct, 16, 70, i[1], 4, 72, 'CGCBB00A', 1, 7)
                if ct.string_found(21, 62, 'CGSCT72A'):
                    ff(ct, 9, 9, 'x', 21, 62, 'CGSCT72A')
                if ct.string_found(3, 71, 'CGCBB00B'):
                    l = 7
                    while not ct.string_found(l, 5, ' '):
                        loc = ct.string_get(l, 7, 4).strip()
                        nr =  ct.string_get(l, 20, 7)
                        srv = ct.string_get(l, 29, 7).strip()
                        ff(ct, l, 3, 'c', 3, 71, 'CGCBB00B')
                        if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                            et(ct)
                        ptc = ct.string_get(4, 18, 22)
                        ptc = ptc[ptc.find('.') + 2:ptc.find('/') - 1]
                        if ((loc, nr)) in circs:
                            pta = 'B'
                        else:
                            pta = 'A'
                        if f'{ptc}{pta}' not in ptcs:
                            pf(ct, 3)
                            ff(ct, l, 3, 'f', 3, 71, 'CGCBB00B')
                            if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                                et(ct)
                            if ct.string_found(4, 72, 'CGSCT08A'):
                                cli = ct.string_get(7, 27, 53).strip()
                                est = ct.string_get(14, 32, 4).replace('_', '').replace(' ', '')
                            elif ct.string_found(4, 73, 'CGCCFAC1'):
                                est = ct.string_get(13, 20, 4).replace('_', '').replace(' ', '')
                                pf(ct, 3)
                                ff(ct, l, 3, 'g', 3, 71, 'CGCBB00B')
                                if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                                    et(ct)
                                cli = ct.string_get(7, 22, 53).strip()
                            elif ct.string_found(4, 72, 'CGSCT47A'):
                                est = ct.string_get(14, 32, 4).replace('_', '').replace(' ', '')
                                cli = ct.string_get(7, 21, 59).strip()
                            if len(est) == 0:
                                est = 'ERRO'
                            pf(ct, 3)
                            cnx.sqlcmd(cnx(), f'insert into b2b_base1(loc, cir, cli, est, ser, pro, pta) values("{loc}", "{nr}", "{cli}", "{est}", "{srv}", "{ptc}", "{pta}")')
                            circs.append((loc, nr))
                            ptcs.append(f'{ptc}{pta}')
                        else:
                            pf(ct, 3)
                        l += 2
                    pf(ct, 3)
                circok.append((i[0], i[1]))
        global vCcir
        vCcir = False
    except:
        if ct.is_connected:
            ct.terminate()

def getccir2(ccir, ptcs):#busca circuitos à partir do circuito cbc
    try:
        ct = cnt(visible=True)
        gtf(ct, vC='cbc')
        for i in ccir:
            if i not in circok:
                if ct.string_found(3, 72, 'CGCBC00B'):
                    pf(ct, 3)
                if not ct.string_found(4, 72, 'CGCBC00A'):
                    ff(ct, 24, 6, 'cbc', 24, 2, 'Cmd')
                ff(ct, 12, 42, i[0], 4, 72, 'CGCBC00A', 0, 4)
                ff(ct, 12, 47, i[1], 4, 72, 'CGCBC00A', 1, 7)
                if ct.string_found(21, 62, 'CGSCT72A'):
                    ff(ct, 9, 9, 'x', 21, 62, 'CGSCT72A')
                if ct.string_found(3, 72, 'CGCBC00B'):
                    l = 7
                    while not ct.string_found(l, 5, ' '):
                        loc = ct.string_get(l, 7, 4).strip()
                        nr =  ct.string_get(l, 20, 7)
                        srv = ct.string_get(l, 29, 7).strip()
                        ff(ct, l, 3, 'c', 3, 72, 'CGCBC00B')
                        if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                            et(ct)
                        ptc = ct.string_get(4, 18, 22)
                        ptc = ptc[ptc.find('.') + 2:ptc.find('/') - 1]
                        if ((loc, nr)) in circs:
                            pta = 'B'
                        else:
                            pta = 'A'
                        if f'{ptc}{pta}' not in ptcs:
                            pf(ct, 3)
                            et(ct)
                            ff(ct, l, 3, 'f', 3, 72, 'CGCBC00B')
                            if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                                et(ct)
                            if ct.string_found(4, 72, 'CGSCT08A'):
                                cli = ct.string_get(7, 27, 53).strip()
                                est = ct.string_get(14, 32, 4).replace('_', '').replace(' ', '')
                            elif ct.string_found(4, 73, 'CGCCFAC1'):
                                est = ct.string_get(13, 20, 4).replace('_', '').replace(' ', '')
                                pf(ct, 3)
                                ff(ct, l, 3, 'g', 3, 72, 'CGCBC00B')
                                if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                                    et(ct)
                                cli = ct.string_get(7, 22, 53).strip()
                            elif ct.string_found(4, 72, 'CGSCT47A'):
                                est = ct.string_get(14, 32, 4).replace('_', '').replace(' ', '')
                                cli = ct.string_get(7, 21, 59).strip()
                            if len(est) == 0:
                                est = 'ERRO'
                            pf(ct, 3)
                            cnx.sqlcmd(cnx(), f'insert into b2b_base1(loc, cir, cli, est, ser, pro, pta) values("{loc}", "{nr}", "{cli}", "{est}", "{srv}", "{ptc}", "{pta}")')
                            circs.append((loc, nr))
                            ptcs.append(f'{ptc}{pta}')
                        else:
                            pf(ct, 3)
                        l += 2
                    pf(ct, 3)
                circok.append((i[0], i[1]))
        global vCcir
        vCcir = False
    except:
        if ct.is_connected:
            ct.terminate()

def getctra1(ctra, pd):#busca tramitações à partir do circuito cbb
    try:
        ct = cnt(visible=False)
        gtf(ct, vC='cbb')
        ff(ct, 6, 21, 'BHE', 4, 72, 'CGCBB00A', 0)
        ff(ct, 6, 26, 'TNE', 4, 72, 'CGCBB00A', 0)
        for i in ctra:
            if i not in circok:
                print(i)
                if ct.string_found(3, 71, 'CGCBB00B'):
                    pf(ct, 3)
                if not ct.string_found(4, 72, 'CGCBB00A'):
                    ff(ct, 24, 6, 'cbb', 24, 2, 'Cmd')
                    ff(ct, 6, 21, 'BHE', 4, 72, 'CGCBB00A', 0)
                    ff(ct, 6, 26, 'TNE', 4, 72, 'CGCBB00A', 0)
                ff(ct, 16, 65, i[0], 4, 72, 'CGCBB00A', 0, 4)
                ff(ct, 16, 70, i[1], 4, 72, 'CGCBB00A', 1, 7)
                if ct.string_found(21, 62, 'CGSCT72A'):
                    ff(ct, 9, 9, 'x', 21, 62, 'CGSCT72A')
                if ct.string_found(3, 71, 'CGCBB00B'):
                    ser = ct.string_get(7, 29, 7).strip()
                    ff(ct, 7, 3, 't', 3, 71, 'CGCBB00B')
                    if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                        et(ct)
                    ptc = ct.string_get(4, 18, 22)
                    ptc = ptc[ptc.find('.') + 2:ptc.find('/') - 1]
                    li = 13
                    qt = 0
                    while not ct.string_found(li, 5, ' '):
                        qt += 1
                        pos = ct.string_get(li, 13, 5).strip()
                        pta = ct.string_get(li, 51, 1).replace(' ', 'A').replace('I', 'A')
                        ff(ct, li, 3, 'x', 4, 72, 'CGSCT13A')
                        ent = ct.string_get(9, 59, 10) + ' ' + ct.string_get(9, 71, 5)
                        sai = ct.string_get(10, 59, 10) + ' ' + ct.string_get(10, 71, 5)
                        pen = ct.string_get(17, 22, 4).replace('    ', '0')
                        sit = ct.string_get(19, 22, 5).strip()                            
                        tmi = '1' if ser[:3] == 'INS' and pen in pd else '0'
                        if f'{ptc}{pta}{str(qt)}' not in ciripd:
                            cnx.sqlcmd(cnx(), f'insert into b2b_base_t(pro, pen, pos, pta, e, s, sit, qt, t) values("{ptc}", "{pen}", "{pos}", "{pta}", str_to_date("{ent}","%d/%m/%Y %H:%i"), str_to_date("{sai}","%d/%m/%Y %H:%i"), "{sit}", {qt}, {tmi})')
                            ciripd.append(f'{ptc}{pta}{str(qt)}')
                        pf(ct, 3)
                        ct.fill_field(li, 3, '', 1)
                        li += 1
                        if li > 20:
                            li = 13
                            pf(ct, 8)
                            if ct.string_found(1, 2, 'ULTIMA TELA'):
                                break
                    pf(ct, 3)
                circok.append((i[0], i[1]))
        global vCcir
        vCcir = False
    except:
        if ct.is_connected:
            ct.terminate()

def getctra2(ctra, pd):#busca tramitações à partir do circuito cbc
    try:
        ct = cnt(visible=True)
        gtf(ct, vC='cbc')
        for i in ctra:
            if i not in circok:
                print(i)
                if ct.string_found(3, 71, 'CGCBB00B'):
                    pf(ct, 3)
                if not ct.string_found(4, 72, 'CGCBC00A'):
                    ff(ct, 24, 6, 'cbc', 24, 2, 'Cmd')
                ff(ct, 12, 42, i[0], 4, 72, 'CGCBC00A', 0, 4)
                ff(ct, 12, 47, i[1], 4, 72, 'CGCBC00A', 1, 7)
                if ct.string_found(21, 62, 'CGSCT72A'):
                    ff(ct, 9, 9, 'x', 21, 62, 'CGSCT72A')
                if ct.string_found(3, 71, 'CGCBB00B'):
                    ser = ct.string_get(7, 29, 7).strip()
                    ff(ct, 7, 3, 't', 3, 71, 'CGCBB00B')
                    if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                        et(ct)
                    ptc = ct.string_get(4, 18, 22)
                    ptc = ptc[ptc.find('.') + 2:ptc.find('/') - 1]
                    li = 13
                    qt = 0
                    while not ct.string_found(li, 5, ' '):
                        qt += 1
                        pos = ct.string_get(li, 13, 5).strip()
                        pta = ct.string_get(li, 51, 1).replace(' ', 'A').replace('I', 'A')
                        ff(ct, li, 3, 'x', 4, 72, 'CGSCT13A')
                        ent = ct.string_get(9, 59, 10) + ' ' + ct.string_get(9, 71, 5)
                        sai = ct.string_get(10, 59, 10) + ' ' + ct.string_get(10, 71, 5)
                        pen = ct.string_get(17, 22, 4).replace('    ', '0')
                        sit = ct.string_get(19, 22, 5).strip()                            
                        tmi = '1' if ser[:3] == 'INS' and pen in pd else '0'
                        if f'{ptc}{pta}{str(qt)}' not in ciripd:
                            cnx.sqlcmd(cnx(), f'insert into b2b_base_t(pro, pen, pos, pta, e, s, sit, qt, t) values("{ptc}", "{pen}", "{pos}", "{pta}", str_to_date("{ent}","%d/%m/%Y %H:%i"), str_to_date("{sai}","%d/%m/%Y %H:%i"), "{sit}", {qt}, {tmi})')
                            ciripd.append(f'{ptc}{pta}{str(qt)}')
                        pf(ct, 3)
                        ct.fill_field(li, 3, '', 1)
                        li += 1
                        if li > 20:
                            li = 13
                            pf(ct, 8)
                            if ct.string_found(1, 2, 'ULTIMA TELA'):
                                break
                    pf(ct, 3)
                circok.append((i[0], i[1]))
        global vCcir
        vCcir = False
    except:
        if ct.is_connected:
            ct.terminate()

def getcir(ct, cir):#busca pendencia atual dos circuitos ativos na base
    circs = []
    cnx.sqlcmd(cnx(), 'delete from b2b_base2')
    gtf(ct, vC='cbb')
    ct.fill_field(6, 21, 'BHE', 3)
    ct.fill_field(6, 26, 'TNE', 3)
    for i in cir:
        if not ct.string_found(4, 72, 'CGCBB00A'):
            ct.fill_field(24, 6, 'cbb', 3)
            ete(ct)
            ct.fill_field(6, 21, 'BHE', 3)
            ct.fill_field(6, 26, 'TNE', 3)
        ct.fill_field(16, 65, i[0], 4)
        ct.fill_field(16, 70, i[1], 7)
        et(ct)
        if ct.string_found(21, 62, 'CGSCT72A'):
            ff(ct, 9, 9, 'x', 21, 62, 'CGSCT72A')
        if ct.string_found(3, 71, 'CGCBB00B'):
            l = 7
            while not ct.string_found(l, 5, ' '):
                loc = ct.string_get(l, 7, 4).strip()
                nr =  ct.string_get(l, 20, 7)
                ff(ct, l, 3, 'c', 3, 70, 'CGCBB00B')
                if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                    et(ct)
                ptc = ct.string_get(4, 18, 22)
                ptc = ptc[ptc.find('.') + 2:ptc.find('/') - 1]
                pf(ct, 3)
                ff(ct, l, 3, 'x', 3, 70, 'CGCBB00B')
                if ct.string_found(15, 47, 'PORTABILIDADE NUMERICA'):
                    et(ct)
                pen = ct.string_get(16, 7, 4).strip()
                pf(ct, 3)
                if f'{loc}-{nr}' in circs:
                    pta = 'B'
                else:
                    pta = 'A'
                pro = ptc + pta
                cnx.sqlcmd(cnx(), f'insert into b2b_base2(loc, cir, pen, pro) values("{loc}", "{nr}", "{pen}", "{pro}")')
                l += 2
                circs.append(f'{loc}-{nr}')
            pf(ct, 3)

def getccto():#busca circuitos à partir do circuito ca
    try:
        ccir = cnx.csql(cnx(), 'select id, loc, cir from b2b_base0 where ss = 1')
        ptcs = cnx.sqllist1(cnx(), 'select distinct pro from b2b_base1')
        ct = cnt(visible=True)
        gtf(ct)
        for i in ccir:
            while not sf(ct, 20, 46, 'Situacao:'):
                pf(ct, 3)
            ff(ct, 5, 12, i[1], 4, 72, 'CGCA0WXA', 0, 4)
            ff(ct, 5, 17, i[2], 4, 72, 'CGCA0WXA', 1, 7)
            while not sf(ct, 20, 46, 'Situacao:'):
                pf(ct, 3)
            sit = ct.string_get(20, 56, 1).strip()
            ser = ct.string_get(21, 32, 1).strip()
            cli = ct.string_get(7, 19, 61).strip()
            pf(ct, 11)
            if sf(ct, 6, 29, 'CANCELAMENTO DE PROGRAMA'):
                cnx.sqlcmd(cnx(), f'update b2b_base0 set ss = 2 where id = {i[0]}')
                et(ct)
                ff(ct, 24, 6, 'ca', 24, 2, 'Cmd')
                continue
            if sf(ct, 1, 2, 'NAO HA ORDEM DE SERVICO PARA ESSE CIRCUITO'):
                pro = 'NA'
                srv = 'NA'
            else:
                pro = ct.string_get(8, 17, 15).strip()
            if pro not in ptcs or pro == 'NA':
                if not pro == 'NA':
                    ff(ct, 8, 13, 'd', 4, 72, 'CGSCA0HB')
                    if not sf(ct, 6, 29, 'CANCELAMENTO DE PROGRAMA'):
                        srv = ct.string_get(25, 59, 7).strip()
                        while not sf(ct, 20, 46, 'Situacao:'):
                            pf(ct, 3)
                    else:
                        cnx.sqlcmd(cnx(), f'update b2b_base0 set ss = 2 where id = {i[0]}')
                        et(ct)
                        ff(ct, 24, 6, 'ca', 24, 2, 'Cmd')
                        continue
                pf(ct, 9)
                pf(ct, 4)
                if ct.string_found(2, 18, 'Consulta Cadastral/Historico'):
                    pf(ct, 4)
                ff(ct, 13, 16, 'x', 13, 18, 'Caracteristicas')
                if sf(ct, 4, 73, 'CGCCCAR1'):
                    li, l = 8, 8
                    c = 3
                elif sf(ct, 4, 72, 'CGS1401A'):
                    li, l = 9, 9
                    c = 10
                p = 1
                v = True
                while not ct.string_found(l, c, 'VELOCIDADE'):
                    l += 1
                    if l == 21:
                        pf(ct, 8)
                        l = li
                        p += 1
                        if p == 3 or sf(ct, 1, 2, 'Ultima Tela'):
                            v = False
                            break
                if v:
                    vel = ct.string_get(l, 41, 16).strip()
                else:
                    vel = 'NE'
                pf(ct, 3)
                ff(ct, 15, 49, 'x', 15, 51, 'Facilidades')
                if sf(ct, 4, 73, 'CGCCFAC1'):
                    l = 13
                    c = 20
                if sf(ct, 4, 72, 'CGSCT47A'):
                    l = 14
                    c = 32                    
                est = ct.string_get(l, c, 4).replace('_', '').replace(' ', '')
                while not sf(ct, 20, 46, 'Situacao:'):
                    pf(ct, 3)
                cnx.sqlcmd(cnx(), f'insert into b2b_base1(loc, cir, cli, sit, srv, vel, est, ser, pro) values("{i[1]}", "{i[2]}", "{cli}", "{sit}", "{ser}", "{vel}", "{est}", "{srv}", "{pro}")')
                cnx.sqlcmd(cnx(), f'update b2b_base0 set ss = 3 where id = {i[0]}')
                ptcs.append(pro)
        global vCcir
        vCcir = False
    except:
        if ct.is_connected:
            ct.terminate()

def getctra(pd):#atualiza tramitações ca
    try:
        ccir = cnx.csql(cnx(), 'select id, loc, cir, pro, ser, t from b2b_base1 where ts = 1')
        ciripd = cnx.sqllist1(cnx(), 'select concat(pro, pta, qt) from b2b_base_t')
        ct = cnt(visible=True)
        gtf(ct)
        for i in ccir:
            while not sf(ct, 20, 46, 'Situacao:'):
                pf(ct, 3)
            ff(ct, 5, 12, i[1], 4, 72, 'CGCA0WXA', 0, 4)
            ff(ct, 5, 17, i[2], 4, 72, 'CGCA0WXA', 1, 7)
            while not sf(ct, 20, 46, 'Situacao:'):
                pf(ct, 3)
            pf(ct, 11)
            if sf(ct, 6, 29, 'CANCELAMENTO DE PROGRAMA'):
                cnx.sqlcmd(cnx(), f'update b2b_base1 set ts = 2 where id = {i[0]}')
                et(ct)
                ff(ct, 24, 6, 'ca', 24, 2, 'Cmd')
                continue
            if sf(ct, 1, 2, 'NAO HA ORDEM DE SERVICO PARA ESSE CIRCUITO'):
                st = ct.string_get(20, 56, 1).strip()
                sr = ct.string_get(21, 32, 1).strip()
                cnx.sqlcmd(cnx(), f'update b2b_base1 set sit = "{st}", srv = "{sr}", ts = 2 where id = {i[0]}')
                continue
            ff(ct, 8, 13, 'x', 4, 72, 'CGSCA0HB')
            if not sf(ct, 6, 29, 'CANCELAMENTO DE PROGRAMA'):
                if int(i[5]) == 0:
                    li = 13
                    qt = 0
                else:
                    fli = getli(int(i[5]))
                    li = fli[1]
                    qt = int(i[5])
                    if fli[0] > 0:
                        for j in range(fli[0]):
                            pf(ct, 8)
                    ff(ct, li, 3, 'x', 4, 72, 'CGSCT13A')
                    if not sf(ct, 19, 22, 'APD') and not sf(ct, 19, 30, 'ATIVIDADE EM EXECUCAO'):
                        sai = ct.string_get(10, 59, 10) + ' ' + ct.string_get(10, 71, 5)
                        sit = ct.string_get(19, 22, 5).strip()
                        cnx.sqlcmd(cnx(), f'update b2b_base_t set s = str_to_date("{sai}","%d/%m/%Y %H:%i"), sit = "{sit}" where pro = "{i[3]}" and qt = {str(qt)}')
                        pf(ct, 3)
                        ct.fill_field(li, 3, '', 1)
                        li += 1
                        if li > 20:
                            li = 13
                            pf(ct, 8)
                            if ct.string_found(1, 2, 'ULTIMA TELA'):
                                continue
                    else:
                        cnx.sqlcmd(cnx(), f'update b2b_base1 set ts = 3 where id = {i[0]}')
                        while not sf(ct, 20, 46, 'Situacao:'):
                            pf(ct, 3)
                        continue
                while not ct.string_found(li, 5, ' '):
                    qt += 1
                    pos = ct.string_get(li, 13, 5).strip()
                    pta = ct.string_get(li, 51, 1).replace(' ', 'A').replace('I', 'A')
                    ff(ct, li, 3, 'x', 4, 72, 'CGSCT13A')
                    ent = ct.string_get(9, 59, 10) + ' ' + ct.string_get(9, 71, 5)
                    sai = ct.string_get(10, 59, 10) + ' ' + ct.string_get(10, 71, 5)
                    pen = ct.string_get(17, 22, 4).replace('    ', '0')
                    sit = ct.string_get(19, 22, 5).strip()
                    tmi = '1' if i[3][:3] == 'INS' and pen in pd else '0'
                    if f'{i[3]}{pta}{str(qt)}' not in ciripd:
                        cnx.sqlcmd(cnx(), f'insert into b2b_base_t(pro, pen, pos, pta, e, s, sit, qt, t) values("{i[3]}", "{pen}", "{pos}", "{pta}", str_to_date("{ent}","%d/%m/%Y %H:%i"), str_to_date("{sai}","%d/%m/%Y %H:%i"), "{sit}", {qt}, {tmi})')
                        ciripd.append(f'{i[3]}{pta}{str(qt)}')
                    pf(ct, 3)
                    ct.fill_field(li, 3, '', 1)
                    li += 1
                    if li > 20:
                        li = 13
                        pf(ct, 8)
                        if ct.string_found(1, 2, 'ULTIMA TELA'):
                            break
                cnx.sqlcmd(cnx(), f'update b2b_base1 set ts = 3 where id = {i[0]}')
                while not sf(ct, 20, 46, 'Situacao:'):
                    pf(ct, 3)
            else:
                cnx.sqlcmd(cnx(), f'update b2b_base1 set ts = 2 where id = {i[0]}')
                et(ct)
                ff(ct, 24, 6, 'ca', 24, 2, 'Cmd')
                continue
        global vCcir
        vCcir = False
    except:
        if ct.is_connected:
            ct.terminate()

def getcpen():#busca circuitos à partir da pendência
    try:
        pd = ('3504', '3999', '3104', '3122', '3513')
        cir = cnx.sqllist1(cnx(), 'select concat(loc, cir, ser) from b2b_base0')
        ct = cnt(visible=True)
        gtf(ct, vC='cbb')
        ff(ct, 6, 21, 'BHE', 4, 72, 'CGCBB00A', 0)
        ff(ct, 6, 26, 'TNE', 4, 72, 'CGCBB00A', 0)
        ct.fill_field(14, 15, 'MG', 2)
        for i in pd:
            if not ct.string_found(4, 72, 'CGCBB00A'):
                ct.fill_field(24, 6, 'cbb', 3)
                et(ct)
                ff(ct, 6, 21, 'BHE', 4, 72, 'CGCBB00A', 0)
                ff(ct, 6, 26, 'TNE', 4, 72, 'CGCBB00A', 0)
                ct.fill_field(14, 15, 'MG', 2)
            ct.fill_field(14, 39, i, 4)
            ct.fill_field(14, 46, i, 4)
            et(ct)
            if ct.string_found(3, 71, 'CGCBB00B'):
                l = 7
                while not ct.string_found(l, 5, ' '):
                    loc = ct.string_get(l, 7, 4).strip()
                    nr =  ct.string_get(l, 20, 7)
                    ser = ct.string_get(l, 29, 7).strip()
                    if f'{loc}{nr}{ser}' not in cir:
                        cnx.sqlcmd(cnx(), f'insert into b2b_base0(loc, cir, ser) values("{loc}", "{nr}", "{ser}")')
                    l += 2
                    if l == 21:
                        l = 7
                        pf(ct, 8)
                        if ct.string_get(1, 1, 15).strip() == 'ULTIMA PAGINA':
                            break
        global vCcir
        vCcir = False
    except:
        if ct.is_connected:
            ct.terminate()

global vCcir, ccir, ptcs, circs, circok, ciripd
#ciripd = cnx.sqllist1(cnx(), 'select concat(pro, pta, qt) from b2b_base_t')
#circs = []
#circok = []
#ccir = cnx.csql(cnx(), 'select * from b2b_base0')
#ptcs = cnx.sqllist1(cnx(), 'select distinct pro from b2b_base1')
#cir = cnx.csql(cnx(), 'select distinct loc, cir from b2b_base1')
#ctra = cnx.csql(cnx(), 'select distinct loc, cir from b2b_base1')

#cnx.sqlcmd(cnx(), 'update b2b_base1 set ts = 1 where pd <> 1 or pd is null')

vCcir = True
while vCcir:
    getcpen()

vCcir = True
while vCcir:
    getccto()

vCcir = True
while vCcir:
    getctra(('3504', '3999', '3104', '3122', '3513', '8049', '3413', '8044'))

"""while vCcir:
    getctra2(ctra, ('3504', '3999', '3104', '3122', '3513', '8049', '3413', '8044'))"""

"""while vCcir:
    getccir2(ccir, ptcs)"""

"""while 1:
    ct = cnt(visible=True)
    getpd(ct, ('8018', '8050'), ptcs)
    break"""

"""while 1:
    ct = cnt(visible=True)
    getcir(ct, cir)
    break"""