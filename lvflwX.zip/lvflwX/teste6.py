"""
import requests

from lxml import html

link = 'https://www.google.com/maps/dir/Montes+Claros,+MG/Sabara,+MG/'
resp = requests.get(link)
filtro = html.fromstring(resp.text)
resp2 = filtro.xpath("/html/body/div[3]/div[9]/div[8]/div/div[1]/div/div/div[5]/div[1]/div/div[1]/div[1]/div[2]/div")
print(resp2)

import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
r = s.connect(('192.168.5.30', 8000))
s.close()
if r:
    print('ok')
else:
    print('nok')



import socket

arqs = ['icon.png', 'lvflwX.lnk', 'lvflwX.zip', 'lvw1.jason', 'verlvflwX.exe']
srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
srv.bind(('192.168.5.30', 8000))
srv.listen(10)
while 1:
    conn, addr = srv.accept()
    arq = conn.recv(1024).decode()
    if arq in arqs:
        with open(arq, 'rb') as file:
            for data in file.readlines():
                conn.send(data)
        print('Arquivo enviado ' + arq, addr)
    conn.close()
"""

"""import os
import subprocess

if not os.path.isdir('c:/Sistema/lvflwX/divs'):
    sp1 = subprocess.Popen('md c:\\Sistema\\lvflwX\\divs > null', shell=True)
    sp1.wait()

print('█')"""

from cryptography.fernet import Fernet
import os
import json

"""if os.path.isfile('./divs/lv.json'):
    arq='./divs/lvw1.json'
else:"""

arq = 'C:/Projects/lvflwX/divs/lvw1.json'


k = 'UqFSyNZKimlsXaKNK2TaS-xRZjAW5CP4fS2D0dLRKc0='
k = k.encode()
f = Fernet(k)

with open(arq) as j:
    jf = json.load(j)
vVersao = jf['system']['ver']
vHost1 = jf['system']['host']
vUser1 = jf['system']['user']
vPass1 = jf['system']['pass']
vData1 = jf['system']['data']
vHost = f.decrypt(vHost1.encode()).decode()
vUser = f.decrypt(vUser1.encode()).decode()
vPass = f.decrypt(vPass1.encode()).decode()
vData = f.decrypt(vData1.encode()).decode()
print(vUser)
print(vPass)
