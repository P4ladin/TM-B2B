import mysql.connector

def convertToBinaryData(filename):
    with open(filename, 'rb') as file:
        binaryData = file.read()
    return binaryData

def insertBLOB(nm, arq):
    print("Inserting BLOB into arquive table")
    try:
        connection = mysql.connector.connect(host='192.168.5.31',
                                             database='sistema',
                                             user='root',
                                             password='pnxeusmb@017')

        cursor = connection.cursor()

        file = convertToBinaryData(arq)

        # Convert data into tuple format
        result = cursor.execute('update arquives set arq = %s, dthr = now() where nm = %s', (file, nm))
        connection.commit()
        print("Image and file inserted successfully as a BLOB into arquive table")

    except mysql.connector.Error as error:
        print("Failed inserting BLOB data into MySQL table {}".format(error))

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

arq = ('verlvflwX.exe', ) #('lvflwX.zip', 'lvw.json')

for i in arq:
    insertBLOB(i, 'C:/Projects/lvflwXcomp/' + i)